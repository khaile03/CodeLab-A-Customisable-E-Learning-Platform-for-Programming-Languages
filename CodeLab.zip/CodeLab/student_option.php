<?php
session_start();
require_once "config/config.php";

// Get username from session
$username = $_SESSION['username'] ?? null;
if (!$username) {
    header("Location: login.php");
    exit();
}

// Single query to get student level data
$stmt = $conn->prepare("SELECT student_level FROM student_level WHERE student_username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$level_result = $stmt->get_result();
$level_data = $level_result->fetch_assoc();

// Single query to get all student preference data
$stmt = $conn->prepare("SELECT subject_interested FROM student_preference WHERE student_username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$preference_result = $stmt->get_result();
$preference_data = $preference_result->fetch_assoc();

// Determine survey completion status
$has_level_data = ($level_result->num_rows > 0);
$has_preferences_data = ($preference_result->num_rows > 0);

$has_level = $has_level_data && !empty($level_data['student_level']);
$has_subjects = $has_preferences_data && !empty($preference_data['subject_interested']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CodeLab - Student Option</title>
    <style>
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0,0,0,0.7);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-content {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 500px;
            width: 90%;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        .modal-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        .modal-button {
            padding: 10px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        .modal-button.accept {
            background-color: #1565c0;
            color: white;
        }
        .modal-button.decline {
            background-color: #f44336;
            color: white;
        }
        .modal-button:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div id="surveyConsentModal" class="modal-overlay">
        <div class="modal-content">
            <h2>Welcome to CodeLab!</h2>
            <?php if (!$has_level && !$has_subjects): ?>
                <!-- New user - no preferences at all -->
                <p>Would you like to complete a quick survey to help us personalize your learning experience?</p>
                <p>This will only take a moment.</p>
                <div class="modal-buttons">
                    <button class="modal-button accept" onclick="acceptSurvey()">Yes, I'll help</button>
                    <button class="modal-button decline" onclick="declineSurvey()">No thanks</button>
                </div>
            <?php elseif (!$has_level || !$has_subjects): ?>
                <!-- Returning user with incomplete survey -->
                <p>We noticed you haven't completed your profile setup yet.</p>
                <p>Would you like to continue where you left off?</p>
                <div class="modal-buttons">
                    <button class="modal-button accept" onclick="acceptSurvey()">Continue Setup</button>
                    <button class="modal-button decline" onclick="declineSurvey()">Skip for Now</button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
    function acceptSurvey() {
        <?php 
        if (!$has_level && !$has_subjects) {
            // New user - start with level selection
            echo "window.location.href = 'student_level.php';";
        } elseif (!$has_level) {
            // Has preferences but no level - go to level selection
            echo "window.location.href = 'student_level.php';";
        } elseif (!$has_subjects) {
            // Has level but no subjects - go to subject selection
            echo "window.location.href = 'student_survey.php';";
        } else {
            // Survey complete - go to dashboard
            echo "window.location.href = 'dashboard.php';";
        }
        ?>
    }

    function declineSurvey() {
        // Redirect to dashboard if they decline
        window.location.href = 'dashboard.php';
    }
    </script>
</body>
</html>