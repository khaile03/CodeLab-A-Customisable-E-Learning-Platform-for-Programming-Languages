<?php
include('config/config.php');
session_start();

if (!isset($_GET['id'])) {
    echo "No video selected.";
    exit();
}

$video_id = intval($_GET['id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve_video'])) {
        $stmt = $conn->prepare("UPDATE interactive_video SET status = 'approved', reason = NULL WHERE video_id = ?");
        $stmt->bind_param("i", $video_id);
        $stmt->execute();
    } elseif (isset($_POST['reject_video']) && isset($_POST['rejection_reason'])) {
        $reason = trim($_POST['rejection_reason']);
        $stmt = $conn->prepare("UPDATE interactive_video SET status = 'rejected', reason = ? WHERE video_id = ?");
        $stmt->bind_param("si", $reason, $video_id);
        $stmt->execute();
    }
    header("Location: ".$_SERVER['PHP_SELF']."?id=".$video_id);
    exit();
}

// Retrieve video details with joins
$sql = "SELECT iv.*, s.name AS subject_name, t.title AS topic_title
        FROM interactive_video iv
        JOIN subject s ON iv.subject_id = s.subject_id
        JOIN topic t ON iv.topic_id = t.topic_id
        WHERE iv.video_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $video_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result || $result->num_rows == 0) {
    echo "Video not found.";
    exit();
}

$video = $result->fetch_assoc();

function isYouTubeUrl($url) {
    return strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Video</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

            .header-left .logo {
                font-size: 40px;
                font-weight: bold;
                text-decoration: none;
                color: white;
            }

            .nav {
                display: flex;
                gap: 15px;
                align-items: center;
                justify-content: flex-start; /* Align breadcrumbs to the left */
                margin-right: auto; /* Ensures it sticks to the left */
                padding-left: 30px;
            }

            .nav a {
                color: white;
                text-decoration: none;
                font-size: 17px;
                font-weight: bold;
                padding: 8px 12px;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }

            .nav a:hover {
                background-color: #0d47a1;
            }
        
        .nav-buttons {
            display: flex;
            gap: 8px; /* Small space between buttons */
        }

        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a[href="create_quiz.php"] {
            background-color: #42a5f5; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a[href="create_lab.php"] {
            background-color: #0b3c91; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }

        #createLessonBtn {
            background-color: #3f51b5; 
            padding: 8px 15px;
            border-radius: 5px;
            color: white;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: opacity 0.3s ease;
        }

        #createLessonBtn:hover {
            opacity: 0.9;
        }

        .modal {
        display: none;
        position: fixed;
        z-index: 999;
        left: 0; top: 0;
        width: 100%; height: 100%;
        background-color: rgba(0,0,0,0.5);
        }

        /* Modal Content Box */
        .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 30px;
        border-radius: 12px;
        width: 400px;
        text-align: center;
        box-shadow: 0 0 20px rgba(0,0,0,0.3);
        }

        /* Modal Title */
        .modal-content h2 {
        margin-bottom: 20px;
        font-size: 20px;
        }

        /* Option Buttons */
        .lesson-options button {
        display: block;
        margin: 10px auto;
        padding: 12px 20px;
        font-size: 16px;
        width: 80%;
        border-radius: 8px;
        border: none;
        background-color: #2d89ef;
        color: white;
        transition: background-color 0.3s ease;
        cursor: pointer;
        }

        .lesson-options button:hover {
        background-color: #1b61c1;
        }

        /* Close Button */
        .close {
        color: #aaa;
        float: right;
        font-size: 24px;
        font-weight: bold;
        cursor: pointer;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
        .video-container {
            background-color: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            max-width: 800px;
            margin: auto;
            text-align: center;
            margin-top: 20px; 
            margin-bottom : 20px;
        }
        h1 {
            color: #2c3e50;
            text-align: center;
        }
        .meta {
            color: #555;
            margin-bottom: 12px;
        }
        .video-frame {
            width: 100%;
            height: 450px;
            border: none;
            border-radius: 10px;
            margin-top: 25px;
        }
        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive for tablets (landscape, <= 1024px) */
        @media (max-width: 1024px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px 30px;
            }

            .nav {
                flex-wrap: wrap;
                justify-content: flex-start;
                padding-left: 0;
                margin-top: 10px;
                gap: 10px;
            }

            .nav a {
                font-size: 15px;
                padding: 8px 10px;
            }

            .nav-buttons {
                align-self: flex-end;
                margin-top: 10px;
            }

            .nav-buttons a {
                font-size: 14px;
                padding: 6px 12px;
            }

            .container-title {
                font-size: 26px;
            }

            .small-title {
                font-size: 22px;
            }

            .content-box {
                width: 220px;
            }
        }

        /* Responsive for phones (portrait, <= 768px) */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: stretch;
                padding: 20px;
            }

            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-start;
                gap: 10px;
                padding-left: 0;
                margin-top: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 16px;
                font-size: 14px;
            }

            .nav-buttons {
                display: flex;
                justify-content: flex-end;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: auto;
                font-size: 14px;
                padding: 10px 14px;
            }

            .dropdown {
                width: auto;
            }

            .dropdown-content {
                min-width: 140px;
                left: auto;
                right: 0;
                transform: none;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            .hero-text {
                font-size: 28px;
                padding: 0 10px;
            }
        }
        .approval-buttons {
            margin-top: 30px;
            text-align: center;
        }
        .approve-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-right: 15px;
        }
        .reject-btn {
            background-color: #f44336;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .status-pending {
            background-color: #FFC107;
            color: #000;
        }
        .status-approved {
            background-color: #4CAF50;
            color: white;
        }
        .status-rejected {
            background-color: #F44336;
            color: white;
        }
        #rejectModal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        #rejectModal .modal-content {
            background-color: #fff;
            margin: 15% auto;
            padding: 25px;
            border-radius: 8px;
            width: 450px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        
        #rejectModal h2 {
            margin-top: 0;
            color: #d9534f;
            text-align: center;
            margin-bottom: 20px;
        }
        
        #rejectModal p {
            margin-bottom: 15px;
            text-align: center;
        }
        
        #rejectionReason {
            width: 100%;
            padding: 12px;
            margin: 0 auto 25px auto;
            border: 1px solid #ddd;
            border-radius: 4px;
            min-height: 120px;
            resize: vertical;
            font-family: Arial, sans-serif;
            display: block;
            box-sizing: border-box;
        }
        
        .modal-actions {
            display: flex;
            justify-content: center;
            gap: 15px;
        }
        
        .modal-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            min-width: 100px;
        }
        
        .modal-cancel {
            background-color: #6c757d;
            color: white;
        }
        
        .modal-submit {
            background-color: #d9534f;
            color: white;
        }
        
        .reason-display {
            margin-top: 15px;
            padding: 10px;
            background-color: #f8f9fa;
            border-left: 4px solid #d9534f;
        }
    </style>
</head>
<body>
<div class="header">
        <div class="header-left">
            <a>CodeLab</a>
        </div>
        <div class="nav">
            <a href="admin_dashboard.php">Homepage</a>
            <a href="user_management.php">User Management</a>
            <a href="material_approval.php">Learning Material Approval</a>
            <a href="quiz_approval.php">Quiz Approval</a>
            <a href="lab_approval.php">Lab Approval</a>
            <a href="troubleshooting.php">Troubleshooting</a>
        </div>
        <div class="nav-buttons">
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <a href="admin_profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Rejection Reason Modal -->
    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <h2>Reject Video</h2>
            <p>Please provide a reason for rejecting this video:</p>
            <form id="rejectForm" method="POST">
                <input type="hidden" name="video_id" value="<?php echo $video_id; ?>">
                <textarea id="rejectionReason" name="rejection_reason" required placeholder="Enter your reason here..."></textarea>
                <div class="modal-actions">
                    <button type="button" class="modal-btn modal-cancel" onclick="closeRejectModal()">Cancel</button>
                    <button type="submit" name="reject_video" class="modal-btn modal-submit">Submit Rejection</button>
                </div>
            </form>
        </div>
    </div>

<div class="video-container">
    <h1><?php echo htmlspecialchars($video['title']); ?></h1>
    
    <div class="status-badge status-<?php echo strtolower($video['status']); ?>">
        Status: <?php echo ucfirst($video['status']); ?>
    </div>
    
    <?php if ($video['status'] === 'rejected' && !empty($video['reason'])): ?>
        <div class="reason-display">
            <strong>Rejection Reason:</strong>
            <p><?php echo htmlspecialchars($video['reason']); ?></p>
        </div>
    <?php endif; ?>

    <p class="meta"><strong>Subject:</strong> <?php echo htmlspecialchars($video['subject_name']); ?></p>
    <p class="meta"><strong>Topic:</strong> <?php echo htmlspecialchars($video['topic_title']); ?></p>
    <p class="meta"><strong>Uploaded at:</strong> <?php echo htmlspecialchars($video['uploaded_at']); ?></p>
    <p><strong>Description:</strong><br><?php echo nl2br(htmlspecialchars($video['description'])); ?></p>

    <?php if (!empty($video['video_url'])): ?>
        <?php if (isYouTubeUrl($video['video_url'])): 
            $youtube_embed = preg_replace(
                "/(https:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)/",
                "https://www.youtube.com/embed/",
                $video['video_url']
            );
        ?>
            <iframe class="video-frame" src="<?php echo htmlspecialchars($youtube_embed); ?>" allowfullscreen></iframe>
        <?php else: ?>
            <video class="video-frame" controls>
                <source src="<?php echo htmlspecialchars($video['video_url']); ?>" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        <?php endif; ?>
    <?php else: ?>
        <p style="color:red;">No video URL provided.</p>
    <?php endif; ?>

    <div class="approval-buttons">
        <form method="POST" style="display: inline;">
            <button type="submit" name="approve_video" class="approve-btn" <?php echo ($video['status'] === 'approved') ? 'disabled' : ''; ?>>
                Approve
            </button>
        </form>
        <button type="button" class="reject-btn" onclick="openRejectModal()" <?php echo ($video['status'] === 'rejected') ? 'disabled' : ''; ?>>
            Reject
        </button>
    </div>
</div>

<div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. 
</div>

<script>

    // Rejection modal functions
    function openRejectModal() {
        document.getElementById('rejectModal').style.display = 'block';
    }
    
    function closeRejectModal() {
        document.getElementById('rejectModal').style.display = 'none';
    }
    
    // Close modal when clicking outside of it
    window.onclick = function(event) {
        if (event.target === document.getElementById('rejectModal')) {
            closeRejectModal();
        }
    }
    
    // Handle form submission
    document.getElementById('rejectForm').addEventListener('submit', function(e) {
        const reason = document.getElementById('rejectionReason').value.trim();
        if (!reason) {
            e.preventDefault();
            alert('Please enter a rejection reason');
        }
    });
</script>

</body>
</html>