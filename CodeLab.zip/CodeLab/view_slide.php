<?php
session_start();
include('config/config.php');


// Check if slide_id is passed
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "No slide ID specified.";
    exit();
}

$slide_id = $_GET['id'];

// Check if user is logged in and is a student
if (isset($_SESSION['username']) && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'student') {
    $student_username = $_SESSION['username'];

    // First verify the user exists in the users table
    $userCheckSql = "SELECT username FROM users WHERE username = ?";
    $userCheckStmt = $conn->prepare($userCheckSql);
    $userCheckStmt->bind_param("s", $student_username);
    $userCheckStmt->execute();
    $userResult = $userCheckStmt->get_result();

    // Record the view
    $viewSql = "INSERT INTO lesson_slide_view (slide_id, student_username, viewed_at) VALUES (?, ?, NOW())";
    $viewStmt = $conn->prepare($viewSql);
    $viewStmt->bind_param("is", $slide_id, $student_username);
    
    try {
        $viewStmt->execute();
    } catch (mysqli_sql_exception $e) {
        // Log the error but don't stop execution
        error_log("Failed to record video view: " . $e->getMessage());
    }
}

// Retrieve slide with subject and topic
$query = "SELECT 
            ls.slide_id, 
            ls.title, 
            ls.description, 
            ls.file_name, 
            ls.file_type, 
            ls.file_data,
            ls.status,
            ls.reason,
            s.name AS subject_name,
            t.title AS topic_title
          FROM lesson_slide ls
          JOIN subject s ON ls.subject_id = s.subject_id
          JOIN topic t ON ls.topic_id = t.topic_id
          WHERE ls.slide_id = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $slide_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo "Error: Slide not found or the file is missing.";
    exit();
}

// Add bindings for subject and topic too
$stmt->bind_result($slide_id, $title, $description, $fileName, $fileType, $fileData, $status, $reason, $subjectName, $topicTitle);
$stmt->fetch();

// Handle file download
if (isset($_GET['download'])) {
    header("Content-Type: " . $fileType);
    header("Content-Disposition: attachment; filename=\"" . basename($fileName) . "\"");
    header("Content-Length: " . strlen($fileData));
    echo $fileData;
    exit();
}

$defaultImage = 'icons/pdf-preview.png'; // Path to the default placeholder image
$previewImage = $defaultImage; // Use the default placeholder 

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Slide - CodeLab</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }

        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

            .header-left .logo {
                font-size: 40px;
                font-weight: bold;
                text-decoration: none;
                color: white;
                margin-right: 20px;
            }

            .nav {
                display: flex;
                gap: 5px;
                align-items: center;
                justify-content: flex-start; /* Align breadcrumbs to the left */
                margin-right: auto; /* Ensures it sticks to the left */
                white-space: nowrap;     
                padding: 8px 12px;      
                display: inline-block; 
            }

            .nav a {
                color: white;
                text-decoration: none;
                font-size: 17px;
                font-weight: bold;
                padding: 8px 12px;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }

            .nav a:hover {
                background-color: #0d47a1;
            }
        
        .nav-buttons {
            display: flex;
            gap: 8px; /* Small space between buttons */
        }

        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a[href="create_quiz.php"] {
            background-color: #42a5f5; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a[href="create_lab.php"] {
            background-color: #0b3c91; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }

        #createLessonBtn {
            background-color: #3f51b5; 
            padding: 8px 15px;
            border-radius: 5px;
            color: white;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: opacity 0.3s ease;
        }

        #createLessonBtn:hover {
            opacity: 0.9;
        }

        .modal {
        display: none;
        position: fixed;
        z-index: 999;
        left: 0; top: 0;
        width: 100%; height: 100%;
        background-color: rgba(0,0,0,0.5);
        }

        /* Modal Content Box */
        .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 30px;
        border-radius: 12px;
        width: 400px;
        text-align: center;
        box-shadow: 0 0 20px rgba(0,0,0,0.3);
        }

        /* Modal Title */
        .modal-content h2 {
        margin-bottom: 20px;
        font-size: 20px;
        }

        /* Option Buttons */
        .lesson-options button {
        display: block;
        margin: 10px auto;
        padding: 12px 20px;
        font-size: 16px;
        width: 80%;
        border-radius: 8px;
        border: none;
        background-color: #2d89ef;
        color: white;
        transition: background-color 0.3s ease;
        cursor: pointer;
        }

        .lesson-options button:hover {
        background-color: #1b61c1;
        }

        /* Close Button */
        .close {
        color: #aaa;
        float: right;
        font-size: 24px;
        font-weight: bold;
        cursor: pointer;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 40px 20px 20px 20px; /* Added top padding for space */
        }

        header {
            color: #2c3e50;
            padding: 10px;
            text-align: center;
        }

        h1 {
            font-size: 24px;
        }
        .status-label {
            display: inline-block;
            padding: 4px 10px;
            margin-top: 6px;
            border-radius: 12px;
            font-size: 0.85rem;
            font-weight: bold;
            color: white;
            text-transform: capitalize;
        }

        .status-label.pending {
            background-color: #f1c40f; /* Yellow */
            color: #000;
        }

        .status-label.approved {
            background-color: #2ecc71; /* Green */
        }

        .status-label.rejected {
            background-color: #e74c3c; /* Red */
        }

        .slide-details {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            width: 100%; /* Matches container width */
            margin-top: 20px; /* Adds space between container and slide details */
        }

        .slide-description {
            margin-bottom: 20px;
        }

        h2 {
            font-size: 18px;
            color: #333;
        }

        .download-section {
            background-color: white; /* Changed from blue to white */
            padding: 15px;
            text-align: center;
            border-radius: 8px;
            color: #333; /* Dark text for visibility on white background */
            box-shadow: 0 0 10px rgba(0,0,0,0.05); /* Optional light shadow */
        }

        .download-button {
            background-color: #28a745;
            padding: 10px 20px;
            color: white;
            border: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .download-button:hover {
            background-color: #218838;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive adjustments for tablets */
        @media (max-width: 1024px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }

        /* Responsive adjustments for phones */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: 100%;
                text-align: center;
                margin-left: 0;
            }

            .hero-text {
                font-size: 36px;
                padding: 0 10px;
            }

            .teacher-button-container {
                flex-direction: column;
                gap: 10px;
            }

            .teacher-button, .admin-button {
                width: 90%;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            /* Show all header buttons on small screens */
            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 20px;
            }

            /* Adjust the size of the create lab, quiz, and lesson buttons */
            .nav-buttons a {
                width: 93%;
                font-size: 16px; /* Ensures consistent button text size */
                padding: 12px 0; /* Adjusts the button padding for better alignment */
            }

            /* Center the dropdown menu */
            .dropdown {
                position: relative;
                width: 100%; /* Ensures dropdown menu takes full width */
                text-align: center;
            }

            .dropdown-content {
                left: 50%;
                transform: translateX(-50%);
            }
        }


        .slide-preview-section {
            display: flex;
            justify-content: center; 
            align-items: center; 
            margin-top: 20px;
            padding: 20px;
        }

        .slide-preview {
            width: 100%; 
            max-width: 180px;  
            height: auto;  
            background: transparent;  
        }
        .reason-display {
            margin-top: 15px;
            padding: 10px;
            background-color: #f8f9fa;
            border-left: 4px solid #d9534f;
        }
    </style>
</head>
<body>
<div class="header">
        <div class="header-left">   
            <a>CodeLab</a>
        </div>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="material.php">Learning Material</a>
            <a href="quiz.php">Quiz</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>
        <div class="nav-buttons">
            <?php if ($_SESSION['user_role'] == 'teacher'): ?>
                <a href="create_quiz.php">Create a Quiz</a>
                <a href="create_lab.php">Create a Lab</a>
                <button id="createLessonBtn" class="create-lesson-btn">Create a Lesson</button>
            <?php endif; ?>
            <?php if (isset($_SESSION['user_role']) && ($_SESSION['user_role'] == 'teacher' || $_SESSION['user_role'] == 'student')): ?>
                <div class="dropdown">
                    <a href="#">More &#9662;</a>
                    <div class="dropdown-content">
                        <?php if ($_SESSION['user_role'] == 'teacher'): ?>
                            <a href="view_report.php">Report</a>
                        <?php elseif ($_SESSION['user_role'] == 'student'): ?>
                            <a href="view_result.php">Results</a>
                        <?php endif; ?>
                        <a href="teacher_profile.php">My Profile</a>
                        <a href="troubleshoot_review.php">Troubleshooting Review</a>
                        <a href="logout.php">Logout</a>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>

    <!-- Lesson Type Modal -->
    <div id="lessonModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>What type of lesson would you like to create?</h2>
            <div class="lesson-options">
            <button onclick="window.location.href='create_slide.php'">Lesson Slides</button>
            <button onclick="window.location.href='create_video.php'">Interactive Videos</button>
            </div>
        </div>
    </div>

    <div class="container">
        <header>
            <h1>View Slide: <?php echo htmlspecialchars($title); ?></h1>
        </header>

        <section class="slide-details">
            <?php if ($_SESSION['user_role'] == 'teacher'): ?>
            <span class="status-label <?php echo strtolower($status); ?>">
                <?php echo ucfirst($status); ?>
            </span>
            <?php if ($status === 'rejected'): ?>
                <div class="reason-display">
                    <strong>Rejection Reason:</strong>
                    <p><?php echo htmlspecialchars($reason); ?></p>
                </div>
            <?php endif; ?>
            <?php endif; ?>
            <!-- Display Subject and Topic Above the Description -->
            <div class="slide-info">
                <h2>Subject: <?php echo htmlspecialchars($subjectName); ?></h2>
                <h3>Topic: <?php echo htmlspecialchars($topicTitle); ?></h3>
            </div>


            <!-- Display the Description -->
            <div class="slide-description">
                <h2>Description:</h2>
                <p><?php echo htmlspecialchars($description); ?></p>
            </div>

            <!-- Download Section with Image -->
            <div class="download-section">
                <h2>Download the Slide</h2>
                <p>Click to download the slide.</p>
                <a href="view_slide.php?id=<?php echo $slide_id; ?>&download=1" target="_blank">
                    <img src="<?php echo $defaultImage; ?>" alt="Slide Preview" class="slide-preview">
                </a>
                
                <p style="margin-top: 10px; font-weight: bold;"><?php echo htmlspecialchars($fileName); ?></p>
            </div>
            <div style="text-align: center; margin-top: 20px; margin-bottom: 20px">
            <?php if ($_SESSION['user_role'] == 'teacher'): ?>
                <a href="edit_slide.php?id=<?php echo $slide_id; ?>" style="background-color: #f0ad4e; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; margin-right: 10px;">Edit Slide</a>
                <a href="delete_slide.php?id=<?php echo $slide_id; ?>" onclick="return confirm('Are you sure you want to delete this slide?');" style="background-color: #d9534f; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none;">Delete Slide</a>
            <?php endif; ?>
        </div>
        </section>
    </div>


    <div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
    </div>

    <script>

        const modal = document.getElementById("lessonModal");
        const btn = document.getElementById("createLessonBtn");
        const closeBtn = document.getElementsByClassName("close")[0];

        btn.onclick = function () {
            modal.style.display = "block";
        }

        closeBtn.onclick = function () {
            modal.style.display = "none";
        }

        window.onclick = function (event) {
            if (event.target === modal) {
            modal.style.display = "none";
            }
        }
    </script>
</body>
</html>


