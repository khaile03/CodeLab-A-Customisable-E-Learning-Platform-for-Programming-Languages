<?php
session_start();
require_once "config/config.php";

// Initialize variables
$error = '';
$success = '';
$material_options = ['Interactive Video', 'Lesson Slides'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_material'])) {
    if (!isset($_POST['material'])) {
        $error = 'Please select a learning material preference.';
    } else {
        $username = $_SESSION['username'];
        $material_preference = $_POST['material'];

        try {
            // Insert preference into student_material table
            $stmt = $conn->prepare("INSERT INTO student_material (student_username, material_preferred, created_at) VALUES (?, ?, NOW())");
            $stmt->bind_param("ss", $username, $material_preference);
            $stmt->execute();

            $success = 'Your material preference has been saved!';
            header("Refresh: 2; url=dashboard.php");
        } catch (Exception $e) {
            $error = 'Error saving your preference: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CodeLab - Material Preference</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #e3f2fd;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #0d47a1;
        }

        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-left .logo {
            font-size: 40px;
            font-weight: bold;
            text-decoration: none;
            color: white;
            margin-right: 20px;
        }

        .survey-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .survey-title {
            font-size: 32px;
            margin-bottom: 30px;
            color: #1565c0;
        }

        .survey-section {
            margin-bottom: 30px;
            text-align: left;
        }

        .section-title {
            font-size: 24px;
            margin-bottom: 15px;
            color: #0d47a1;
            border-bottom: 2px solid #bbdefb;
            padding-bottom: 5px;
        }

        .material-options {
            display: flex;
            flex-direction: column;
            gap: 20px;
            margin-top: 15px;
        }

        .material-card {
            border: 2px solid #bbdefb;
            border-radius: 8px;
            padding: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 18px;
        }

        .material-card:hover {
            background-color: #e3f2fd;
            transform: translateY(-3px);
        }

        .material-card.selected {
            background-color: #bbdefb;
            border-color: #0d47a1;
        }

        .submit-btn {
            background-color: #1565c0;
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 20px;
        }

        .submit-btn:hover {
            background-color: #0d47a1;
            transform: translateY(-2px);
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <a>CodeLab</a>
        </div>
    </div>

    <div class="survey-container fade-in">
        <h1 class="survey-title">Tell Us How You Prefer to Learn</h1>

        <?php if ($error): ?>
            <div class="error-message" style="color: #d32f2f; margin-bottom: 20px;"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success-message" style="color: #388e3c; margin-bottom: 20px;"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="survey-section">
                <h2 class="section-title">2. Choose Your Preferred Material Format</h2>
                <p>Which method do you find more engaging for learning new topics?</p>

                <div class="material-options">
                    <?php foreach ($material_options as $option): ?>
                        <label class="material-card">
                            <input type="radio" name="material" value="<?php echo $option; ?>" style="display: none;">
                            <?php echo htmlspecialchars($option); ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <button type="submit" name="submit_material" class="submit-btn">Save Preference</button>
        </form>
    </div>

    <div class="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
    </div>

    <script>
        // Material selection functionality
        document.querySelectorAll('.material-card').forEach(card => {
            card.addEventListener('click', function () {
                document.querySelectorAll('.material-card').forEach(c => c.classList.remove('selected'));
                this.classList.add('selected');
                this.querySelector('input[type="radio"]').checked = true;
            });
        });

        // Scroll animation
        function revealOnScroll() {
            let elements = document.querySelectorAll(".fade-in");
            let windowHeight = window.innerHeight;

            elements.forEach(function (el) {
                let elementTop = el.getBoundingClientRect().top;
                if (elementTop < windowHeight - 100) {
                    el.classList.add("visible");
                }
            });
        }

        window.addEventListener("scroll", revealOnScroll);
        document.addEventListener("DOMContentLoaded", revealOnScroll);
    </script>
</body>
</html>
