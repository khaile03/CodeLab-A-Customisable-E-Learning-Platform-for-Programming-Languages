<?php
include("config/config.php");
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // First, check if the username exists
    $check_user_query = "SELECT * FROM users WHERE username = ?";
    $check_user_stmt = $conn->prepare($check_user_query);
    $check_user_stmt->bind_param("s", $username);
    $check_user_stmt->execute();
    $check_user_result = $check_user_stmt->get_result();

    if ($check_user_result->num_rows === 0) {
        // Username not found
        $error = "Username has not signed up, please sign up.";
    } else {
        // Username found, now check password
        $query = "SELECT * FROM users WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['username'] = $user['username'];
        $_SESSION['user_role'] = $user['role']; 

        // Redirect based on user role
        if ($user['role'] === 'admin') {
            header("Location: admin_dashboard.php");
        } else if ($user['role'] === 'teacher'){
            header("Location: dashboard.php");
        } else {
            $student_name = $_SESSION['username'];

            $level_stmt = $conn->prepare("SELECT * FROM student_level WHERE student_username = ? AND student_level != ''");
            $level_stmt->bind_param("s", $student_name);
            $level_stmt->execute();
            $level_result = $level_stmt->get_result();

            $preference_stmt = $conn->prepare("SELECT * FROM student_preference WHERE student_username = ? AND subject_interested != ''");
            $preference_stmt->bind_param("s", $student_name);
            $preference_stmt->execute();
            $preference_result = $preference_stmt->get_result();
                
            if ($level_result->num_rows > 0 && $preference_result->num_rows > 0) {
                header("Location: dashboard.php");
            } else {
                header('Location: student_option.php');
            }
        }
        exit();
    } else {
        $error = "Invalid username or password!";
    }
}
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CodeLab - User Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #e3f2fd;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #0d47a1;
        }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-left .logo {
            font-size: 40px;
            font-weight: bold;
            text-decoration: none;
            color: white;
            margin-right: 20px;
        }

        .nav {
            display: flex;
            gap: 15px;
            align-items: center;
            justify-content: flex-start; /* Align breadcrumbs to the left */
            margin-right: auto; /* Ensures it sticks to the left */
        }

        .nav a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
            padding: 10px 16px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .nav a:hover {
            background-color: #0d47a1;
        }

        .nav-buttons {
            display: flex;
            gap: 15px;
            align-items: center;
            justify-content: flex-start;
        }
        .nav-buttons a {
            background-color: white;
            color: #0d47a1;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-left: 10px;
            font-size: 18px;
            font-weight: bold;
        }
        .nav-buttons a:hover {
            background-color: #bbdefb;
        }
        .login-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 400px;
            margin: 90px auto;
            text-align: center;
        }
        .login-container h2 {
            margin-bottom: 50px;
            color: #1565c0;
        }
        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #bbdefb;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        .form-group .radio-group {
            display: flex;
            justify-content: space-around;
            margin-top: 10px;
        }

        .form-group .radio-options {
            display: flex;
            gap: 20px;
            margin-top: 8px;
        }

        .form-group .radio-label {
            font-weight: normal; 
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .login-button {
            background-color: #1565c0;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            transition: background-color 0.3s;
        }
        .login-button:hover {
            background-color: #0d47a1;
        }
        .error-message {
            background-color: #ffcdd2;
            color: #b71c1c;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .forgot-password {
            margin-top: 15px;
            display: block;
            color: #1565c0;
            text-decoration: none;
        }
        .forgot-password:hover {
            text-decoration: underline;
        }
        .register-link {
            margin-top: 20px;
            color: #0d47a1;
        }
        .register-link a {
            color: #1565c0;
            font-weight: bold;
            text-decoration: none;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive adjustments for tablets */
        @media (max-width: 1024px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }

        /* Responsive adjustments for phones */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: 100%;
                text-align: center;
                margin-left: 0;
            }

            .hero-text {
                font-size: 36px;
                padding: 0 10px;
            }

            .teacher-button-container {
                flex-direction: column;
                gap: 10px;
            }

            .teacher-button, .admin-button {
                width: 90%;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <a href="index.html" class="logo">CodeLab</a>
        </div>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="material.php">Learning Material</a>
            <a href="quiz.php">Quiz</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>
    </div>

    
    <div class="login-container">
        <h2>User Login</h2>

        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="" method="POST">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required placeholder="Enter your username">
        </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required placeholder="Enter your password">
            </div>
            <button type="submit" class="login-button">LOGIN</button>
        </form>
        <div class="register-link">
            Don't have an account? <a href="register.php">Register here</a>
        </div>
    </div>

    <div class="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
    </div>
</body>
</html>