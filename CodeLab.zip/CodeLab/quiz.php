<?php
session_start();
require_once "config/config.php";

$isLoggedIn = isset($_SESSION['user_role']);

// Get subject list
$subjectQuery = "SELECT * FROM subject";
$subjectResult = mysqli_query($conn, $subjectQuery);
$subjects = [];
while ($row = mysqli_fetch_assoc($subjectResult)) {
    $subjects[$row['subject_id']] = $row['name'];
}

// Fetch videos
$quiz = [];
$quizQuery = "SELECT q.quiz_id, q.title, q.description, q.subject_id, q.topic_id, q.teacher_username, q.created_at, q.status,
                    s.name AS subject_name, t.title AS topic_title, u.name AS teacher_name
            FROM quiz q
            JOIN subject s ON q.subject_id = s.subject_id
            JOIN topic t ON q.topic_id = t.topic_id
            JOIN users u ON q.teacher_username = u.username
            WHERE q.status = 'approved'";
$quizResult = mysqli_query($conn, $quizQuery);
while ($row = mysqli_fetch_assoc($quizResult)) {
    $row['type'] = 'Assessment Quiz';
    $quiz[] = $row;
}

// Fetch slides
$lab = [];
$labQuery = "SELECT l.lab_id, l.title, l.description, l.subject_id, l.topic_id, l.teacher_username, l.created_at, l.status,
                    s.name AS subject_name, t.title AS topic_title, u.name AS teacher_name
            FROM lab l
            JOIN subject s ON l.subject_id = s.subject_id
            JOIN topic t ON l.topic_id = t.topic_id
            JOIN users u ON l.teacher_username = u.username
            WHERE l.status = 'approved'";
$labResult = mysqli_query($conn, $labQuery);
while ($row = mysqli_fetch_assoc($labResult)) {
    $row['type'] = 'Lab Activity';
    $lab[] = $row;
}

// Combine all materials
$materials = array_merge($quiz, $lab);

// Group by subject
$groupedMaterials = [];
foreach ($materials as $item) {
    $subject = $item['subject_name'];
    if (!isset($groupedMaterials[$subject])) {
        $groupedMaterials[$subject] = [];
    }
    $groupedMaterials[$subject][] = $item;
}

// Get random image list
$image_folder = 'images/';
$image_files = array_values(array_filter(scandir($image_folder), function($file) use ($image_folder) {
    return is_file($image_folder . $file) && preg_match('/\.(jpg|jpeg|png|gif)$/i', $file);
}));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assessment Activities</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

            .header-left .logo {
                font-size: 40px;
                font-weight: bold;
                text-decoration: none;
                color: white;
                margin-right: 20px;
            }

            .nav {
                display: flex;
                gap: 5px;
                align-items: center;
                justify-content: flex-start; /* Align breadcrumbs to the left */
                margin-right: auto; /* Ensures it sticks to the left */
                white-space: nowrap;     
                padding: 8px 12px;      
                display: inline-block; 
            }

            .nav a {
                color: white;
                text-decoration: none;
                font-size: 17px;
                font-weight: bold;
                padding: 8px 12px;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }

            .nav a:hover {
                background-color: #0d47a1;
            }
        
        .nav-buttons {
            display: flex;
            gap: 8px; /* Small space between buttons */
        }

        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a[href="create_quiz.php"] {
            background-color: #42a5f5; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a[href="create_lab.php"] {
            background-color: #0b3c91; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }

        #createLessonBtn {
            background-color: #3f51b5; 
            padding: 8px 15px;
            border-radius: 5px;
            color: white;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: opacity 0.3s ease;
        }

        #createLessonBtn:hover {
            opacity: 0.9;
        }

        .modal {
        display: none;
        position: fixed;
        z-index: 999;
        left: 0; top: 0;
        width: 100%; height: 100%;
        background-color: rgba(0,0,0,0.5);
        }

        /* Modal Content Box */
        .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 30px;
        border-radius: 12px;
        width: 400px;
        text-align: center;
        box-shadow: 0 0 20px rgba(0,0,0,0.3);
        }

        /* Modal Title */
        .modal-content h2 {
        margin-bottom: 20px;
        font-size: 20px;
        }

        /* Option Buttons */
        .lesson-options button {
        display: block;
        margin: 10px auto;
        padding: 12px 20px;
        font-size: 16px;
        width: 80%;
        border-radius: 8px;
        border: none;
        background-color: #2d89ef;
        color: white;
        transition: background-color 0.3s ease;
        cursor: pointer;
        }

        .lesson-options button:hover {
        background-color: #1b61c1;
        }

        /* Close Button */
        .close {
        color: #aaa;
        float: right;
        font-size: 24px;
        font-weight: bold;
        cursor: pointer;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }

        h1 {
            text-align: center;
            margin-bottom: 10px;
        }
        .search-bar {
            max-width: 600px;
            margin: 0 auto 30px auto;
            display: flex;
        }
        .search-bar input {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            border: 2px solid #ccc;
            border-radius: 8px;
        }
        .subject-section {
            margin-bottom: 40px;
            margin: 0 40px 40px 40px; /* adds left and right margin */
        }
        .subject-section h2 {
            margin-bottom: 20px;
            border-bottom: 2px solid #ccc;
            padding-bottom: 5px;
            color: #333;
        }
        .material-container {
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin: 0 40px 40px 40px; /* adds left and right margin */
            display: flex;
            flex-wrap: nowrap;
            overflow-x: auto;
            scroll-behavior: smooth;
        }
        .material-container::-webkit-scrollbar {
            height: 10px;
        }

        .material-container::-webkit-scrollbar-thumb {
            background-color: #888;
            border-radius: 5px;
        }

        .material-container::-webkit-scrollbar-thumb:hover {
            background-color: #555;
        }
        .material-card {
            flex: 0 0 auto;
            width: 280px;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: 0.2s;
        }
        .material-card:hover {
            transform: scale(1.03);
        }
        .material-card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
        }
        .material-content {
            padding: 15px;
        }
        .material-content h3 {
            margin: 0;
            font-size: 1.2rem;
        }
        .material-content p {
            margin: 6px 0 0;
            font-size: 14px;
            color: #555;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 10;
            left: 0; top: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.6);
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background: #fff;
            padding: 25px;
            width: 90%;
            max-width: 600px;
            border-radius: 10px;
            position: relative;
        }
        .close-btn {
            position: absolute;
            top: 10px; right: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #666;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive adjustments for tablets */
        @media (max-width: 1024px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }

        /* Responsive adjustments for phones */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: 100%;
                text-align: center;
                margin-left: 0;
            }

            .hero-text {
                font-size: 36px;
                padding: 0 10px;
            }

            .teacher-button-container {
                flex-direction: column;
                gap: 10px;
            }

            .teacher-button, .admin-button {
                width: 90%;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }
        }

    </style>
</head>
<body>

<div class="header">
        <div class="header-left">
            <a>CodeLab</a>
        </div>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="material.php">Learning Material</a>
            <a href="quiz.php">Quiz</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div class="nav-buttons">
            <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'teacher'): ?>
                <a href="create_quiz.php">Create a Quiz</a>
                <a href="create_lab.php">Create a Lab</a>
                <button id="createLessonBtn" class="create-lesson-btn">Create a Lesson</button>
            <?php endif; ?>
            <?php if (isset($_SESSION['user_role']) && ($_SESSION['user_role'] == 'teacher' || $_SESSION['user_role'] == 'student')): ?>
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'teacher'): ?>
                        <a href="view_report.php">Report</a>
                        <a href="teacher_profile.php">My Profile</a>
                        <a href="troubleshoot_review.php">Troubleshooting Review</a>
                        <a href="logout.php">Logout</a>
                    <?php elseif (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'student'): ?>
                        <a href="view_result.php">Results</a>
                        <a href="teacher_profile.php">My Profile</a>
                        <a href="troubleshoot_review.php">Troubleshooting Review</a>
                        <a href="logout.php">Logout</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
</div>


<h1>All Assessment Activities</h1>

<div class="search-bar">
    <input type="text" id="searchInput" onkeyup="filterMaterials()" placeholder="Search by assessment activity title...">
</div>

<?php foreach ($groupedMaterials as $subject => $items): ?>
    <div class="subject-section">
        <h2><?php echo htmlspecialchars($subject); ?></h2>
        <div class="material-container">
            <?php foreach ($items as $material): 
                $randomImage = $image_files[array_rand($image_files)];
                $title = htmlspecialchars($material['title']);
            ?>
                <div class="material-card" onclick='showMaterialModal(<?php echo json_encode($material, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>)' data-title="<?php echo strtolower($title); ?>">
                    <img src="images/<?php echo $randomImage; ?>" alt="Material Image">
                    <div class="material-content">
                        <h3><?php echo $title; ?></h3>
                        <p>Type: <?php echo $material['type']; ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endforeach; ?>


<div class="modal" id="materialModal">
    <div class="modal-content">
        <span class="close-btn" onclick="closeModal()">&times;</span>
        <h2 id="modalTitle"></h2>
        <p><strong>Type:</strong> <span id="modalType"></span></p>
        <p><strong>Topic:</strong> <span id="modalTopic"></span></p>
        <p><strong>Created by:</strong> <span id="modalTeacher"></span></p>
        <p><strong>Description:</strong></p>
        <p id="modalDesc"></p>
    </div>
</div>

<div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
</div>


<script>
    function check_login() {
        <?php if (!$isLoggedIn): ?>
            alert("Please login before visiting your Dashboard!");
            window.location.replace("login.php");
        <?php endif; ?>
    }
    
    function filterMaterials() {
        const input = document.getElementById('searchInput').value.toLowerCase();
        const subjectSections = document.querySelectorAll('.subject-section');

        subjectSections.forEach(section => {
            const cards = section.querySelectorAll('.material-card');
            let matchFound = false;

            cards.forEach(card => {
                const title = card.getAttribute('data-title');
                if (title.includes(input)) {
                    card.style.display = 'block';
                    matchFound = true;
                } else {
                    card.style.display = 'none';
                }
            });

            section.style.display = matchFound ? 'block' : 'none';
        });
    }


    function showMaterialModal(data) {
        document.getElementById("modalTitle").textContent = data.title;
        document.getElementById("modalType").textContent = data.type;
        document.getElementById("modalDesc").textContent = data.description;
        document.getElementById("modalTopic").textContent = data.topic_title;
        document.getElementById("modalTeacher").textContent = data.teacher_name;

        document.getElementById("materialModal").style.display = "flex";    
    }

    function closeModal() {
        document.getElementById("materialModal").style.display = "none";
    }

    window.onclick = function(e) {
        if (e.target === document.getElementById("materialModal")) {
            closeModal();
        }
    }

    window.addEventListener("scroll", function () {
            var footer = document.getElementById("footer");
            if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
                footer.style.display = "block";
            } else {
                footer.style.display = "none";
            }
        });

        const modal = document.getElementById("lessonModal");
        const btn = document.getElementById("createLessonBtn");
        const closeBtn = document.getElementsByClassName("close")[0];

        btn.onclick = function () {
            modal.style.display = "block";
        }

        closeBtn.onclick = function () {
            modal.style.display = "none";
        }

        window.onclick = function (event) {
            if (event.target === modal) {
            modal.style.display = "none";
            }
    }
</script>

</body>
</html>