<?php
// Start the session
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the user is logged in as admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Include database config
include("config/config.php");

// Get the logged-in admin username from session
$adminUsername = $_SESSION['username'];

// Fetch admin details from the users table
$query = "SELECT * FROM users WHERE username = ? AND role = 'admin'";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $adminUsername);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $admin = $result->fetch_assoc();
    $adminName = $admin['name'];
} else {
    header("Location: login.php");
    exit();
}

// Fetch all quizzes
$quizStmt = $conn->prepare("SELECT * FROM quiz");
$quizStmt->execute();
$quizResult = $quizStmt->get_result();
$quizzes = $quizResult->fetch_all(MYSQLI_ASSOC);

// Fetch all lesson slides
$slideStmt = $conn->prepare("SELECT * FROM lesson_slide");
$slideStmt->execute();
$slideResult = $slideStmt->get_result();
$slides = $slideResult->fetch_all(MYSQLI_ASSOC);

// Fetch all interactive videos
$videoStmt = $conn->prepare("SELECT * FROM interactive_video");
$videoStmt->execute();
$videoResult = $videoStmt->get_result();
$videos = $videoResult->fetch_all(MYSQLI_ASSOC);

// Fetch all labs
$labStmt = $conn->prepare("SELECT * FROM lab");
$labStmt->execute();
$labResult = $labStmt->get_result();
$labs = $labResult->fetch_all(MYSQLI_ASSOC);

// Define images array
$images = ['pic1.jpg.avif', 'pic2.jpg', 'pic3.jpg.avif', 'pic4.jpg', 'pic5.jpg', 'pic6.jpg.avif'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }

        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-left .logo {
            font-size: 40px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav {
            display: flex;
            gap: 15px;
            align-items: center;
            justify-content: flex-start;
            margin-right: auto;
            padding-left: 30px;
        }
        .nav a {
            color: white;
            text-decoration: none;
            font-size: 17px;
            font-weight: bold;
            padding: 8px 12px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .nav a:hover {
            background-color: #0d47a1;
        }
        .nav-buttons {
            display: flex;
            gap: 8px;
        }

        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
        .container-title {
            font-size: 30px;
            margin: 30px 50px 10px;
            font-weight: bold;
        }
        .content-container {
            margin: 0 50px 40px;
            overflow-x: auto;
            white-space: nowrap;
        }
        .content-box {
            display: inline-block;
            width: 250px;
            background-color: white;
            margin-right: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .content-box img {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }
        .content-box .info {
            padding: 10px;
        }
        .content-box .info h4 {
            margin: 0;
            font-size: 18px;
        }
        .content-box .info p {
            margin: 5px 0 0;
            color: gray;
            font-size: 14px;
        }
        .small-title {
            font-size: 25px;
            margin: 30px 50px 10px;
        }
        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }

        /* Responsive for tablets (landscape, <= 1024px) */
        @media (max-width: 1024px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px 30px;
            }

            .nav {
                flex-wrap: wrap;
                justify-content: flex-start;
                padding-left: 0;
                margin-top: 10px;
                gap: 10px;
            }

            .nav a {
                font-size: 15px;
                padding: 8px 10px;
            }

            .nav-buttons {
                align-self: flex-end;
                margin-top: 10px;
            }

            .nav-buttons a {
                font-size: 14px;
                padding: 6px 12px;
            }

            .container-title {
                font-size: 26px;
            }

            .small-title {
                font-size: 22px;
            }

            .content-box {
                width: 220px;
            }
        }

        /* Responsive for phones (portrait, <= 768px) */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: stretch;
                padding: 20px;
            }

            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-start;
                gap: 10px;
                padding-left: 0;
                margin-top: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 16px;
                font-size: 14px;
            }

            .nav-buttons {
                display: flex;
                justify-content: flex-end;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: auto;
                font-size: 14px;
                padding: 10px 14px;
            }

            .dropdown {
                width: auto;
            }

            .dropdown-content {
                min-width: 140px;
                left: auto;
                right: 0;
                transform: none;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            .hero-text {
                font-size: 28px;
                padding: 0 10px;
            }
        }



    </style>
</head>
<body>
    <div class="header">
    <div class="header-left">CodeLab</div>
        <div class="nav">
            <a href="admin_dashboard.php">Homepage</a>
            <a href="user_management.php">User Management</a>
            <a href="material_approval.php">Learning Material Approval</a>
            <a href="quiz_approval.php">Quiz Approval</a>
            <a href="lab_approval.php">Lab Approval</a>
            <a href="troubleshooting.php">Troubleshooting</a>
        </div>
        <div class="nav-buttons">
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <a href="admin_profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <p style="margin-left:50px; font-size:24px; font-weight:bold; color:#1565c0;">
        Welcome, <?php echo htmlspecialchars($adminName); ?>!
    </p>

    <div class="container-title">Learning Material Approval</div>
    <div class="small-title">Lesson Slides</div>
    <div class="content-container">
        <?php if (empty($slides)): ?>
            <p>No slides found.</p>
        <?php else: ?>
            <?php foreach ($slides as $slide): ?>
                <a href="aview_slide.php?slide_id=<?php echo $slide['slide_id']; ?>" style="text-decoration: none; color: inherit;">
                    <div class="content-box">
                        <img src="images/<?php echo $images[array_rand($images)]; ?>" alt="Slide">
                        <div class="info">
                            <h4><?php echo htmlspecialchars($slide['title']); ?></h4>
                            <p><?php echo $slide['uploaded_at']; ?></p>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="small-title">Interactive Videos</div>
    <div class="content-container">
        <?php if (empty($videos)): ?>
            <p>No videos found.</p>
        <?php else: ?>
            <?php foreach ($videos as $video): ?>
                <a href="aview_video.php?id=<?php echo $video['video_id']; ?>" style="text-decoration: none; color: inherit;">
                    <div class="content-box">
                        <img src="images/<?php echo $images[array_rand($images)]; ?>" alt="Video">
                        <div class="info">
                            <h4><?php echo htmlspecialchars($video['title']); ?></h4>
                            <p><?php echo $video['uploaded_at']; ?></p>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="container-title">Quiz Approval</div>
    <div class="content-container">
        <?php if (empty($quizzes)): ?>
            <p>No quizzes found.</p>
        <?php else: ?>
            <?php foreach ($quizzes as $quiz): ?>
                <a href="aview_quiz.php?id=<?php echo $quiz['quiz_id']; ?>" style="text-decoration: none; color: inherit;">
                    <div class="content-box">
                        <img src="images/<?php echo $images[array_rand($images)]; ?>" alt="Quiz">
                        <div class="info">
                            <h4><?php echo htmlspecialchars($quiz['title']); ?></h4>
                            <p><?php echo $quiz['created_at']; ?></p>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="container-title">Lab Activities</div>
    <div class="content-container">
        <?php if (empty($labs)): ?>
            <p>No lab activities found.</p>
        <?php else: ?>
            <?php foreach ($labs as $lab): ?>
                <a href="aview_lab.php?id=<?php echo $lab['lab_id']; ?>" style="text-decoration: none; color: inherit;">
                    <div class="content-box">
                        <img src="images/<?php echo $images[array_rand($images)]; ?>" alt="Lab">
                        <div class="info">
                            <h4><?php echo htmlspecialchars($lab['title']); ?></h4>
                            <p><?php echo $lab['created_at']; ?></p>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. 
    </div>
</body>
</html>