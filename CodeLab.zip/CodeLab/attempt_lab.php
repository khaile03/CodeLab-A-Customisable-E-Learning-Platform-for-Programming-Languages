<?php
include 'config/config.php'; // Your DB connection file
session_start();

if (!isset($_GET['id'])) {
    echo "Lab ID is missing.";
    exit;
}

$labId = $_GET['id'];

// Check if user is logged in and is a student
if (isset($_SESSION['username'])) {
    $student_name = $_SESSION['username'];
}

// Retrieve lab info, subject name, and topic title
$sql = "SELECT l.*, s.name AS subject_name, t.title AS topic_title
        FROM lab l
        JOIN subject s ON l.subject_id = s.subject_id
        JOIN topic t ON l.topic_id = t.topic_id
        WHERE l.lab_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $labId);
$stmt->execute();
$labResult = $stmt->get_result();

if ($labResult->num_rows == 0) {
    echo "Lab not found.";
    exit;
}

$lab = $labResult->fetch_assoc();

// Retrieve lab questions
$questionSql = "SELECT * FROM lab_question WHERE lab_id = ?";
$questionStmt = $conn->prepare($questionSql);
$questionStmt->bind_param("i", $labId);
$questionStmt->execute();
$questions = $questionStmt->get_result();

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $score = 0;
    $totalQuestions = $questions->num_rows;
    
    // Reset pointer for questions result
    $questions->data_seek(0);
    
    // Calculate score
    while ($question = $questions->fetch_assoc()) {
        $submittedAnswer = strtolower(trim($_POST['question_'.$question['question_id']]));
        $correctAnswer = strtolower(trim($question['correct_answer']));
        
        if ($submittedAnswer === $correctAnswer) {
            $score++;
        }
    }
    $marks = $score / $totalQuestions * 100;
    
    // Check if passing grade exists and if student passed
    $passingGrade = $lab['grading'];
    $passed = $marks >= $passingGrade;
    
    // Record the attempt
    $attemptSql = "INSERT INTO lab_attempt (lab_id, student_username, score, attempted_at) VALUES (?, ?, ?, NOW())";
    $attemptStmt = $conn->prepare($attemptSql);
    $attemptStmt->bind_param("isi", $labId, $student_name, $score);
    
    try {
        $attemptStmt->execute();
    } catch (mysqli_sql_exception $e) {
        // Log error but don't stop execution
        error_log("Failed to record quiz attempt: " . $e->getMessage());
    }

    
    // Show results on the same page
    $showResults = true;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attempt Lab - <?php echo htmlspecialchars($lab['title']); ?></title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }

        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

            .header-left .logo {
                font-size: 40px;
                font-weight: bold;
                text-decoration: none;
                color: white;
                margin-right: 20px;
            }

            .nav {
                display: flex;
                gap: 5px;
                align-items: center;
                justify-content: flex-start; /* Align breadcrumbs to the left */
                margin-right: auto; /* Ensures it sticks to the left */
                white-space: nowrap;     
                padding: 8px 12px;      
                display: inline-block; 
            }

            .nav a {
                color: white;
                text-decoration: none;
                font-size: 18px;
                font-weight: bold;
                padding: 8px 12px;  
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }

            .nav a:hover {
                background-color: #0d47a1;
            }
        
        .nav-buttons {
            display: flex;
            gap: 8px; /* Small space between buttons */
        }

        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a[href="create_quiz.php"] {
            background-color: #42a5f5; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a[href="create_lab.php"] {
            background-color: #0b3c91; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }

        #createLessonBtn {
            background-color: #3f51b5; 
            border-radius: 5px;
            color: white;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: opacity 0.3s ease;
            white-space: nowrap;     
            padding: 8px 12px;      
            display: inline-block; 
        }

        #createLessonBtn:hover {
            opacity: 0.9;
        }

        .modal {
        display: none;
        position: fixed;
        z-index: 999;
        left: 0; top: 0;
        width: 100%; height: 100%;
        background-color: rgba(0,0,0,0.5);
        }

        /* Modal Content Box */
        .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 30px;
        border-radius: 12px;
        width: 400px;
        text-align: center;
        box-shadow: 0 0 20px rgba(0,0,0,0.3);
        }

        /* Modal Title */
        .modal-content h2 {
        margin-bottom: 20px;
        font-size: 20px;
        }

        /* Option Buttons */
        .lesson-options button {
        display: block;
        margin: 10px auto;
        padding: 12px 20px;
        font-size: 16px;
        width: 80%;
        border-radius: 8px;
        border: none;
        background-color: #2d89ef;
        color: white;
        transition: background-color 0.3s ease;
        cursor: pointer;
        }

        .lesson-options button:hover {
        background-color: #1b61c1;
        }

        /* Close Button */
        .close {
        color: #aaa;
        float: right;
        font-size: 24px;
        font-weight: bold;
        cursor: pointer;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }


        .lab-container {
            background: white;
            border-radius: 12px;
            padding: 30px 50px;
            max-width: 900px;
            margin: 20px auto;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .lab-header {
            text-align: center;
            margin-bottom: 30px;
            word-wrap: break-word;
            overflow-wrap: break-word;
            white-space: normal;
        }

        .lab-header h1 {
            color: #1565c0;
        }

        .lab-meta {
            text-align: center;
            color: #555;
            font-size: 16px;
            margin-top: 5px;
            word-wrap: break-word;
            overflow-wrap: break-word;
            white-space: normal;
        }

        .question-block {
            margin-bottom: 30px;
            padding: 20px;
            border-left: 5px solid #1565c0;
            background: #fdfdfd;
        }

        .question-text {
            font-weight: bold;
            margin-bottom: 10px;
            word-wrap: break-word;
            overflow-wrap: break-word;
            white-space: normal;
        }

        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            min-height: 100px;
            font-family: Arial, sans-serif;
            resize: vertical;
        }

        .hint {
            margin-top: 10px;
            font-style: italic;
            color: #888;
            word-wrap: break-word;
            overflow-wrap: break-word;
            white-space: normal;
        }

        .submit-btn {
            background-color: #1565c0;
            color: white;
            border: none;
            padding: 10px 20px; 
            border-radius: 5px; 
            text-decoration: none;
            display: inline-block;
            margin: 0;
            transition: background-color 0.3s;
        }

        .submit-btn:hover {
            background-color: #0d47a1;
        }

        .result-container {
            text-align: center;
            padding: 20px;
            background-color: #e8f5e9;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .result-score {
            font-size: 24px;
            font-weight: bold;
            color: #2e7d32;
            margin-bottom: 10px;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }

                /* Responsive adjustments for tablets */
                @media (max-width: 1024px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }

        /* Responsive adjustments for phones */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: 100%;
                text-align: center;
                margin-left: 0;
            }

            .hero-text {
                font-size: 36px;
                padding: 0 10px;
            }

            .teacher-button-container {
                flex-direction: column;
                gap: 10px;
            }

            .teacher-button, .admin-button {
                width: 90%;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            /* Show all header buttons on small screens */
            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 20px;
            }

            /* Adjust the size of the create lab, quiz, and lesson buttons */
            .nav-buttons a {
                width: 93%;
                font-size: 16px; /* Ensures consistent button text size */
                padding: 12px 0; /* Adjusts the button padding for better alignment */
            }

            /* Center the dropdown menu */
            .dropdown {
                position: relative;
                width: 100%; /* Ensures dropdown menu takes full width */
                text-align: center;
            }

            .dropdown-content {
                left: 50%;
                transform: translateX(-50%);
            }
        }
    </style>
</head>
<body>
    <div class="header">
    <div class="header-left">CodeLab</div>
        <div class="nav">
            <?php if (isset($_SESSION['user_role'])): ?>
                <a href="dashboard.php">Dashboard</a>
            <?php endif; ?>
            <a href="material.php">Learning Material</a>
            <a href="quiz.php">Quiz</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div class="nav-buttons">
            <?php if (isset($_SESSION['user_role'])): ?>
                <div class="dropdown">
                    <a href="#">More &#9662;</a>
                    <div class="dropdown-content">
                        <?php if ($_SESSION['user_role'] == 'teacher'): ?>
                            <a href="view_report.php">Report</a>
                        <?php elseif ($_SESSION['user_role'] == 'student'): ?>
                            <a href="view_result.php">Results</a>
                        <?php endif; ?>
                        <a href="profile.php">My Profile</a>
                        <a href="troubleshoot_review.php">Troubleshoot Review</a>
                        <a href="logout.php">Logout</a>
                    </div>
                </div>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Sign Up</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="lab-container">
        <?php if (isset($showResults) && $showResults): ?>
            <div class="result-container">
                <h2>Lab Results</h2>
                <div class="result-score">
                    You got <?php echo $score; ?> out of <?php echo $totalQuestions; ?> questions correct
                </div>
                <p>Score: <?php echo round($marks); ?>%</p>
                
                <?php if (!$passed): ?>
                    <div class="result-message" style="color: #c62828; font-weight: bold; margin: 15px 0;">
                        ❌ You did not pass this lab activity (Passing grade: <?php echo $passingGrade; ?>%)
                    </div>
                    <p style="margin-bottom: 15px;">We recommend reviewing the material and trying again.</p>
                <?php else: ?>
                    <div class="result-message" style="color: #2e7d32; font-weight: bold; margin: 15px 0; padding: 10px; background-color: #e8f5e9; border-radius: 5px;">
                        ✔️ Congratulations! You passed this lab activity!
                    </div>
                <?php endif; ?>

                <?php if (isset($_SESSION['username'])): ?>
                    <a href="dashboard.php" class="submit-btn">Back to Dashboard</a>
                <?php else: ?>
                    <a href="index.html" class="submit-btn">Back to Homepage</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <form method="post" action="attempt_lab.php?id=<?php echo $labId; ?>">
                <div class="lab-header">
                    <h1><?php echo htmlspecialchars($lab['title']); ?></h1>
                    <div class="lab-meta">
                        <p><strong>Subject:</strong> <?php echo htmlspecialchars($lab['subject_name']); ?></p>
                        <p><strong>Topic:</strong> <?php echo htmlspecialchars($lab['topic_title']); ?></p>
                        <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($lab['description'])); ?></p>
                    </div>
                </div>

                <?php
                $index = 1;
                $questions->data_seek(0); // Reset pointer
                while ($question = $questions->fetch_assoc()) {
                    echo '<div class="question-block">';
                    echo '<div class="question-text">Question ' . $index++ . '. ' . htmlspecialchars($question['question']) . '</div>';
                    
                    echo '<textarea name="question_'.$question['question_id'].'" placeholder="Your answer here..." required></textarea>';
                    
                    if (!empty($question['hint'])) {
                        echo '<div class="hint">💡 Hint: ' . htmlspecialchars($question['hint']) . '</div>';
                    }

                    echo '</div>';
                }
                ?>
                
                <button type="submit" class="submit-btn">Submit Lab</button>
            </form>
        <?php endif; ?>
    </div>

    <div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
    </div>

</body>
</html>