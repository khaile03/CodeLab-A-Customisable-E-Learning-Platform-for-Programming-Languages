<?php
include 'config/config.php';

if (!isset($_GET['id'])) {
    echo "Video ID is missing.";
    exit;
}

$videoId = $_GET['id'];


// Delete the quiz
$deleteVideoSql = "DELETE FROM interactive_video WHERE video_id = ?";
$videoStmt = $conn->prepare($deleteVideoSql);
$videoStmt->bind_param("i", $videoId);

if ($videoStmt->execute()) {
    echo "<script>alert('Video deleted successfully.'); window.location.href='dashboard.php';</script>";
} else {
    echo "Failed to delete video.";
}
?>