<?php
include("config/config.php");
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['lab_id'])) {
    $labId = intval($_GET['lab_id']);

    // Check if this lab has any question
    $stmt = $conn->prepare("SELECT COUNT(*) FROM lab_question WHERE lab_id = ?");
    $stmt->bind_param("i", $labId);
    $stmt->execute();
    $stmt->bind_result($questionCount);
    $stmt->fetch();
    $stmt->close();

    // If no questions exist, delete the lab
    if ($questionCount == 0) {
        $stmt = $conn->prepare("DELETE FROM lab WHERE lab_id = ?");
        $stmt->bind_param("i", $labId);
        $stmt->execute();
        $stmt->close();
    }

    $_SESSION['message'] = "Lab activity creation was cancelled.";
    header("Location: dashboard.php");
    exit();
} else {
    header("Location: dashboard.php");
    exit();
}
?>