<?php
// Include database connection
include("config/config.php");
session_start();

// Verify if the teacher username is available in the session
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Get quiz_id from the URL
$quizId = isset($_GET['quiz_id']) ? $_GET['quiz_id'] : null;
if (!$quizId) {
    header("Location: create_quiz.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Start a database transaction
    $conn->begin_transaction();

    try {
        // Process each question
        if (isset($_POST['questions']) && is_array($_POST['questions'])) {
            foreach ($_POST['questions'] as $questionData) {
                $question = $questionData['question'] ?? '';
                $optionA = $questionData['option_a'] ?? '';
                $optionB = $questionData['option_b'] ?? '';
                $optionC = $questionData['option_c'] ?? '';
                $optionD = $questionData['option_d'] ?? '';
                $correctOption = $questionData['correct_option'] ?? '';
                $hint = $questionData['hint'] ?? '';

                // Insert into the question table
                $stmt = $conn->prepare("INSERT INTO quiz_question (quiz_id, question, option_a, option_b, option_c, option_d, correct_option, hint) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("isssssss", $quizId, $question, $optionA, $optionB, $optionC, $optionD, $correctOption, $hint);
                $stmt->execute();
            }
        }

        // Commit the transaction
        $conn->commit();

        // Redirect with success message
        $_SESSION['success_message'] = "Quiz successfully published!";
        header("Location: dashboard.php");
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
}

// Close the connection
$conn->close();
?>

