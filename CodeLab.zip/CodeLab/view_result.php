<?php
include('config/config.php');
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['username']) || $_SESSION['user_role'] !== 'student') {
    echo "Unauthorized access.";
    exit();
}

$username = $_SESSION['username'];
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$type_filter = isset($_GET['type']) ? $_GET['type'] : 'all';

// Prepare queries for all content types
$results = [];

// Get quiz attempts
$quizQuery = "SELECT 
            q.title AS content_title,
            q.quiz_id AS content_id,
            'quiz' AS content_type,
            s.name AS subject_name,
            t.title AS topic_title,
            a.attempted_at,
            a.score,
            q.grading AS passing_score
          FROM quiz_attempt a
          JOIN quiz q ON a.quiz_id = q.quiz_id
          JOIN subject s ON q.subject_id = s.subject_id
          JOIN topic t ON q.topic_id = t.topic_id
          WHERE a.student_username = '$username'";

if ($filter === 'passed') {
    $quizQuery .= " AND a.score >= q.grading";
} elseif ($filter === 'failed') {
    $quizQuery .= " AND a.score < q.grading";
}

// Get lab attempts
$labQuery = "SELECT 
            l.title AS content_title,
            l.lab_id AS content_id,
            'lab' AS content_type,
            s.name AS subject_name,
            t.title AS topic_title,
            a.attempted_at,
            a.score,
            l.grading AS passing_score
          FROM lab_attempt a
          JOIN lab l ON a.lab_id = l.lab_id
          JOIN subject s ON l.subject_id = s.subject_id
          JOIN topic t ON l.topic_id = t.topic_id
          WHERE a.student_username = '$username'";

if ($filter === 'passed') {
    $labQuery .= " AND a.score >= l.grading";
} elseif ($filter === 'failed') {
    $labQuery .= " AND a.score < l.grading";
}

// Get slide views
$slideQuery = "SELECT 
            ls.title AS content_title,
            ls.slide_id AS content_id,
            'slide' AS content_type,
            s.name AS subject_name,
            t.title AS topic_title,
            sv.viewed_at AS attempted_at,
            100 AS score,  /* Assuming viewing counts as 100% */
            0 AS passing_score  /* No passing score for views */
          FROM lesson_slide_view sv
          JOIN lesson_slide ls ON sv.slide_id = ls.slide_id
          JOIN subject s ON ls.subject_id = s.subject_id
          JOIN topic t ON ls.topic_id = t.topic_id
          WHERE sv.student_username = '$username'";

// Get video views
$videoQuery = "SELECT 
            iv.title AS content_title,
            iv.video_id AS content_id,
            'video' AS content_type,
            s.name AS subject_name,
            t.title AS topic_title,
            ivv.viewed_at AS attempted_at,
            100 AS score,  /* Assuming viewing counts as 100% */
            0 AS passing_score  /* No passing score for views */
          FROM interactive_video_view ivv
          JOIN interactive_video iv ON ivv.video_id = iv.video_id
          JOIN subject s ON iv.subject_id = s.subject_id
          JOIN topic t ON iv.topic_id = t.topic_id
          WHERE ivv.student_username = '$username'";

// Combine all queries with UNION
$combinedQuery = "($quizQuery) UNION ($labQuery) UNION ($slideQuery) UNION ($videoQuery) ORDER BY attempted_at DESC";

$result = mysqli_query($conn, $combinedQuery);
while ($row = mysqli_fetch_assoc($result)) {
    // Get total questions/tasks count for each content
    if ($row['content_type'] === 'quiz') {
        $countQuery = "SELECT COUNT(*) AS total_questions FROM quiz_question WHERE quiz_id = {$row['content_id']}";
    } elseif ($row['content_type'] === 'lab') {
        $countQuery = "SELECT COUNT(*) AS total_questions FROM lab_question WHERE lab_id = {$row['content_id']}";
    } else {
        // For slides and videos, we'll use 1 as they don't have questions
        $row['total_questions'] = 1;
        $results[] = $row;
        continue;
    }
    
    $countResult = mysqli_query($conn, $countQuery);
    $countRow = mysqli_fetch_assoc($countResult);
    
    $row['total_questions'] = $countRow['total_questions'];
    $results[] = $row;
}

// Apply type filter after getting all results
if ($type_filter !== 'all') {
    $results = array_filter($results, function($item) use ($type_filter) {
        return $item['content_type'] === $type_filter;
    });
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Quiz Results</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-left .logo {
            font-size: 40px;
            font-weight: bold;
            text-decoration: none;
            color: white;
            margin-right: 20px;
        }

        .nav {
            display: flex;
            gap: 5px;
            align-items: center;
            justify-content: flex-start;
            margin-right: auto;
        }

        .nav a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
            padding: 10px 16px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .nav-buttons {
            display: flex;
            gap: 8px;
        }
        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }



        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }

        
        .container {
            max-width: 960px;
            margin: auto;
            background-color: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-top: 20px;
            margin-bottom: 20px;
        }
        
        .quiz-badge {
            background-color: #17a2b8;
            color: white;
            padding: 3px 8px;
            border-radius: 10px;
            font-size: 12px;
        }
        
        .lab-badge {
            background-color: #6f42c1;
            color: white;
            padding: 3px 8px;
            border-radius: 10px;
            font-size: 12px;
        }
        
        .slide-badge {
            background-color: #28a745;
            color: white;
            padding: 3px 8px;
            border-radius: 10px;
            font-size: 12px;
        }
        
        .video-badge {
            background-color: #dc3545;
            color: white;
            padding: 3px 8px;
            border-radius: 10px;
            font-size: 12px;
        }
        
        h2 {
            color: #2c3e50;
        }
        select {
            padding: 8px 12px;
            border-radius: 6px;
            border: 1px solid #ccc;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table th, table td {
            padding: 14px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        table th {
            background-color: #f9f9f9;
            color: #333;
        }
        tr:hover {
            background-color: #f0f8ff;
            cursor: pointer;
        }
        .passed {
            color: #28a745;
            font-weight: bold;
        }
        .failed {
            color: #dc3545;
            font-weight: bold;
        }
        .completed {
            color: #17a2b8;
            font-weight: bold;
        }


        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }

                /* Responsive adjustments for tablets */
                @media (max-width: 1024px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }

        /* Responsive styles */
        @media screen and (max-width: 1200px) {
            .container {
                width: 90%;
                margin: 20px auto;
            }
        }
        
        @media screen and (max-width: 992px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }
        
        @media screen and (max-width: 768px) {
        .header {
            flex-direction: column;
            align-items: flex-start;
            padding: 20px;
        }

        .nav-buttons {
            flex-direction: column;
            align-items: stretch;
            width: 100%;
            margin-top: 10px;
        }

        .nav-buttons a {
            width: 100%;
            text-align: center;
            margin-left: 0;
        }

        .hero-text {
            font-size: 36px;
            padding: 0 10px;
        }

        .teacher-button-container {
            flex-direction: column;
            gap: 10px;
        }

        .teacher-button, .admin-button {
            width: 90%;
        }

        .footer {
            font-size: 16px;
            text-align: center;
        }

        .nav {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
        }

        .nav a {
            width: auto;
            padding: 10px 20px;
        }

        .nav-buttons a {
            width: 93%;
            font-size: 16px;
            padding: 12px 0;
        }

        .dropdown {
            position: relative;
            width: 100%;
            text-align: center;
        }

        .dropdown-content {
            left: 0;
            right: 0;
            width: 100%;
            text-align: center;
        }

        /* ✅ Wrap the table in a scrollable container */
        .table-container {
            overflow-x: auto;
            width: 100%;
        }

        table {
            min-width: 600px; /* Force horizontal scroll if needed */
        }
    }

        
        @media screen and (max-width: 576px) {
            .header-left .logo {
                font-size: 28px;
            }
            
            .nav a {
                font-size: 14px;
                padding: 6px 10px;
            }
            
            .container {
                padding: 15px;
                border-radius: 8px;
            }
            
            h2 {
                font-size: 20px;
            }
        }
        
        /* Fix for dropdown on mobile */
        @media screen and (max-width: 768px) {
            .dropdown-content {
                left: 0;
                right: 0;
                width: 100%;
                text-align: center;
            }
            
            .dropdown {
                position: static;
                display: block;
                margin: 10px auto;
            }
            
            .dropdown-content {
                position: absolute;
                left: 0;
                right: 0;
                width: 100%;
                max-width: 250px;
                margin: 0 auto;
            }
        }

        
    </style>
    <script>
        function applyTypeFilter() {
            const type = document.getElementById('typeSelect').value;
            window.location.href = `view_result.php?type=${type}`;
        }
        
        function redirectToPage(type, id) {
            const urls = {
                'quiz': 'view_quiz.php',
                'lab': 'view_lab.php',
                'slide': 'view_slide.php',
                'video': 'view_video.php'
            };
            
            if (urls[type]) {
                window.location.href = `${urls[type]}?id=${id}`;
            }
        }
    </script>
</head>
<body>
    <div class="header">
        <div class="header-left">   
            <a>CodeLab</a>
        </div>
        <div class="nav">
            <?php if (isset($_SESSION['user_role'])): ?>
                <a href="dashboard.php">Dashboard</a>
            <?php endif; ?>
            <a href="material.php">Learning Material</a>
            <a href="quiz.php">Quiz</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div class="nav-buttons">
            <?php if (isset($_SESSION['user_role'])): ?>
                <div class="dropdown">
                    <a id="moreBtn" href="#">More &#9662;</a>
                    <div class="dropdown-content">
                        <?php if ($_SESSION['user_role'] == 'teacher'): ?>
                            <a href="view_report.php">Report</a>
                        <?php elseif ($_SESSION['user_role'] == 'student'): ?>
                            <a href="view_result.php">Results</a>
                        <?php endif; ?>
                        <a href="teacher_profile.php">My Profile</a>
                        <a href="troubleshoot_review.php">Troubleshoot Review</a>
                        <a href="logout.php">Logout</a>
                    </div>
                </div>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Sign Up</a>
            <?php endif; ?>
        </div>
    </div>

<div class="container">
    <h2>My Learning Results</h2>

    <label for="typeSelect">Filter by Type:</label>
    <select id="typeSelect" onchange="applyTypeFilter()">
        <option value="all" <?= $type_filter === 'all' ? 'selected' : '' ?>>All Types</option>
        <option value="quiz" <?= $type_filter === 'quiz' ? 'selected' : '' ?>>Quizzes</option>
        <option value="lab" <?= $type_filter === 'lab' ? 'selected' : '' ?>>Labs</option>
        <option value="slide" <?= $type_filter === 'slide' ? 'selected' : '' ?>>Slides</option>
        <option value="video" <?= $type_filter === 'video' ? 'selected' : '' ?>>Videos</option>
    </select>

    <div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Type</th>
                <th>Title</th>
                <th>Subject</th>
                <th>Topic</th>
                <th>Date</th>
                <th>Result</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php if (count($results) > 0): ?>
            <?php foreach ($results as $attempt): ?>
                <tr onclick="redirectToPage('<?= $attempt['content_type'] ?>', '<?= $attempt['content_id'] ?>')">
                    <td>
                        <?php 
                        $badge_class = [
                            'quiz' => 'quiz-badge',
                            'lab' => 'lab-badge',
                            'slide' => 'slide-badge',
                            'video' => 'video-badge'
                        ][$attempt['content_type']];
                        ?>
                        <span class="<?= $badge_class ?>">
                            <?= ucfirst($attempt['content_type']) ?>
                        </span>
                    </td>
                    <td><?= htmlspecialchars($attempt['content_title']) ?></td>
                    <td><?= htmlspecialchars($attempt['subject_name']) ?></td>
                    <td><?= htmlspecialchars($attempt['topic_title']) ?></td>
                    <td><?= htmlspecialchars($attempt['attempted_at']) ?></td>
                    <td>
                        <?php if (in_array($attempt['content_type'], ['quiz', 'lab'])): ?>
                            <?= htmlspecialchars($attempt['score']) ?>/<?= htmlspecialchars($attempt['total_questions']) ?>
                        <?php else: ?>
                            Viewed
                        <?php endif; ?>
                    </td>
                    <?php if (in_array($attempt['content_type'], ['quiz', 'lab'])): ?>
                    <?php
                        $score = (int)$attempt['score'];
                        $passing_score = (int)$attempt['passing_score'];
                        $total_questions = (int)$attempt['total_questions'];

                        $percentage = $total_questions > 0 ? ($score / $total_questions) * 100 : 0;

                        if ($percentage >= $passing_score) {
                            $status_class = 'passed';
                            $status_text = 'Passed';
                        } else {
                            $status_class = 'failed';
                            $status_text = 'Failed';
                        }
                    ?>
                    <td class="<?= $status_class ?>"><?= $status_text ?></td>
                    <?php else: ?>
                        <td>Completed</td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="7">No results found for this filter.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div> </div>

<div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
</div>


</body>
</html>