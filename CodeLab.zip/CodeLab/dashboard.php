<?php
// Start the session
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$isLoggedIn = isset($_SESSION['user_role']);


// Check if user is logged in
if (!isset($_SESSION['user_role'])) {
    echo "<script>alert('❌ You must log in first to access the dashboard.'); window.location.href = 'index.html';</script>";
    exit();
}

// Include database config
include("config/config.php");

// Get the logged-in user username from session
$username = $_SESSION['username'];

if ($_SESSION['user_role'] == 'teacher') {
    // Fetch teacher details from the users table
    $query = "SELECT * FROM users WHERE username = ? AND role = 'teacher'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $teacher = $result->fetch_assoc();
        $teacherName = $teacher['username'];
    }

    // Fetch teacher's quizzes
    $quizStmt = $conn->prepare("SELECT * FROM quiz WHERE teacher_username = ?");
    $quizStmt->bind_param("s", $teacherName);
    $quizStmt->execute();
    $quizResult = $quizStmt->get_result();
    $quizzes = $quizResult->fetch_all(MYSQLI_ASSOC);

    // Fetch teacher's slides
    $slideStmt = $conn->prepare("SELECT * FROM lesson_slide WHERE teacher_username = ?");
    $slideStmt->bind_param("s", $teacherName);
    $slideStmt->execute();
    $slideResult = $slideStmt->get_result();
    $slides = $slideResult->fetch_all(MYSQLI_ASSOC);

    // Fetch teacher's videos
    $videoStmt = $conn->prepare("SELECT * FROM interactive_video WHERE teacher_username = ?");
    $videoStmt->bind_param("s", $teacherName);
    $videoStmt->execute();
    $videoResult = $videoStmt->get_result();
    $videos = $videoResult->fetch_all(MYSQLI_ASSOC);

    // Fetch teacher's lab
    $labStmt = $conn->prepare("SELECT * FROM lab WHERE teacher_username = ?");
    $labStmt->bind_param("s", $teacherName);
    $labStmt->execute();
    $labResult = $labStmt->get_result();
    $labs = $labResult->fetch_all(MYSQLI_ASSOC);

} else if ($_SESSION['user_role'] == 'student') {
    // Fetch student details 
    $query = "SELECT * FROM student_level WHERE student_username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $level_result = $stmt->get_result();

    $query = "SELECT subject_interested FROM student_preference WHERE student_username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $preference_result = $stmt->get_result();

    $query = "SELECT material_preferred FROM student_material WHERE student_username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $material_result = $stmt->get_result();

    // Get view count count
    $video_view_count = 0;
    $count_query = "SELECT COUNT(*) as views_count FROM interactive_video_view WHERE student_username = ?";
    $count_stmt = $conn->prepare($count_query);
    $count_stmt->bind_param("s", $username);
    $count_stmt->execute();
    $video_view_count_result = $count_stmt->get_result();
    if ($video_view_count_result->num_rows > 0) {
        $count_data = $video_view_count_result->fetch_assoc();
        $video_view_count = $count_data['views_count'];
    }

    $slide_view_count = 0;
    $count_query = "SELECT COUNT(*) as views_count FROM lesson_slide_view WHERE student_username = ?";
    $count_stmt = $conn->prepare($count_query);
    $count_stmt->bind_param("s", $username);
    $count_stmt->execute();
    $slide_view_count_result = $count_stmt->get_result();
    if ($slide_view_count_result->num_rows > 0) {
        $count_data = $slide_view_count_result->fetch_assoc();
        $slide_view_count = $count_data['views_count'];
    }

    // Initialize variables
    $studentName = $_SESSION['username'];
    $level = 'Intermediate'; // Default if not found
    $quizzes = [];
    $slides = [];
    $videos = [];
    $labs = [];

    // Get student level if exists
    if ($level_result->num_rows > 0) {
        $level_data = $level_result->fetch_assoc();
        $level = $level_data['student_level'];
    }

    $material_preferred = '';

    if ($material_result->num_rows > 0) {
        $material_row = $material_result->fetch_assoc();
        $material_preferred = $material_row['material_preferred'];
    }

    // Process preferences if any exist
    if ($preference_result->num_rows > 0) {
        // Get all preferred subjects
        $preferred_subjects = [];
        while ($row = $preference_result->fetch_assoc()) {
            $preferred_subjects[] = $row['subject_interested'];
        }
        

        // Get subject IDs for preferred subjects
        if (!empty($preferred_subjects)) {
            // Create placeholders for prepared statement
            $placeholders = implode(',', array_fill(0, count($preferred_subjects), '?'));
            $types = str_repeat('s', count($preferred_subjects));
            
            // Get subject IDs
            $subjectQuery = "SELECT subject_id FROM subject WHERE name IN ($placeholders)";
            $subjectStmt = $conn->prepare($subjectQuery);
            $subjectStmt->bind_param($types, ...$preferred_subjects);
            $subjectStmt->execute();
            $subjectResult = $subjectStmt->get_result();
            
            $subject_ids = [];
            while ($row = $subjectResult->fetch_assoc()) {
                $subject_ids[] = $row['subject_id'];
            }

            // Fetch content for these subjects if we found any
            if (!empty($subject_ids)) {
                $content_placeholders = implode(',', array_fill(0, count($subject_ids), '?'));
                $content_types = str_repeat('s', count($subject_ids));
                
                // Fetch quizzes
                $quizStmt = $conn->prepare("SELECT * FROM quiz WHERE subject_id IN ($content_placeholders) AND status = 'approved'");
                $quizStmt->bind_param($content_types, ...$subject_ids);
                $quizStmt->execute();
                $quizResult = $quizStmt->get_result();
                $quizzes = $quizResult->fetch_all(MYSQLI_ASSOC);
                
                // Fetch slides
                $slideStmt = $conn->prepare("SELECT * FROM lesson_slide WHERE subject_id IN ($content_placeholders) AND status = 'approved'");
                $slideStmt->bind_param($content_types, ...$subject_ids);
                $slideStmt->execute();
                $slideResult = $slideStmt->get_result();
                $slides = $slideResult->fetch_all(MYSQLI_ASSOC);
                
                // Fetch videos
                $videoStmt = $conn->prepare("SELECT * FROM interactive_video WHERE subject_id IN ($content_placeholders) AND status = 'approved'");
                $videoStmt->bind_param($content_types, ...$subject_ids);
                $videoStmt->execute();
                $videoResult = $videoStmt->get_result();
                $videos = $videoResult->fetch_all(MYSQLI_ASSOC);

                // Fetch labs
                $labStmt = $conn->prepare("SELECT * FROM lab WHERE subject_id IN ($content_placeholders) AND status = 'approved'");
                $labStmt->bind_param($content_types, ...$subject_ids);
                $labStmt->execute();
                $labResult = $labStmt->get_result();
                $labs = $labResult->fetch_all(MYSQLI_ASSOC);
            }
        }
    }
} else {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
        .beginner-modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0,0,0,0.7);
            z-index: 1000;
            display: none;
            justify-content: center;
            align-items: center;
        }

        .beginner-modal-content {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            width: 450px;
            max-width: 90%;
            text-align: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.3);
            position: relative;
            margin: auto;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .beginner-modal h2 {
            color: #1565c0;
            margin-bottom: 20px;
        }
        
        .beginner-modal p {
            margin-bottom: 25px;
            font-size: 16px;
            line-height: 1.5;
        }
        
        .beginner-modal-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
        }
        
        .beginner-modal-btn {
            padding: 12px 25px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .beginner-modal-btn.primary {
            background-color: #1565c0;
            color: white;
        }
        
        .beginner-modal-btn.secondary {
            background-color: #f0f2f5;
            color: #333;
        }
        
        .beginner-modal-btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }

        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

            .header-left .logo {
                font-size: 40px;
                font-weight: bold;
                text-decoration: none;
                color: white;
                margin-right: 20px;
            }

            .nav {
                display: flex;
                gap: 5px;
                align-items: center;
                justify-content: flex-start; /* Align breadcrumbs to the left */
                margin-right: auto; /* Ensures it sticks to the left */
                white-space: nowrap;     
                padding: 8px 12px;      
                display: inline-block; 
            }

            .nav a {
                color: white;
                text-decoration: none;
                font-size: 18px;
                font-weight: bold;
                padding: 8px 12px;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }

            .nav a:hover {
                background-color: #0d47a1;
            }
            
        <?php if ($_SESSION['user_role'] == 'teacher'): ?>
            .nav-buttons {
                display: flex;
                gap: 8px; /* Small space between buttons */
            }

            .nav-buttons a {
                display: flex;/* Flex for centering */
                align-items: center;/* Vertical centering */
                justify-content: center;/* Horizontal centering */
                color: white;
                text-decoration: none;
                font-size: 14px;
                padding: 4px 10px;
                border-radius: 5px;
                min-width: 90px; /* ensures consistent button width */
                height: 32px;  /* ensures consistent height */
            }

            .nav-buttons a[href="create_quiz.php"] {
                background-color: #42a5f5; 
                padding: 8px 15px;
                border-radius: 5px;
            }

            .nav-buttons a[href="create_lab.php"] {
                background-color: #0b3c91; 
                padding: 8px 15px;
                border-radius: 5px;
            }

            .nav-buttons a:hover {
                opacity: 0.9;
            }

            #createLessonBtn {
                    background-color: #3f51b5; 
                    padding: 8px 12px;
                    border-radius: 5px;
                    color: white;
                    font-size: 14px;
                    border: none;
                    cursor: pointer;
                    transition: opacity 0.3s ease;
                }

                #createLessonBtn:hover {
                    opacity: 0.9;
                }

                .modal {
                display: none;
                position: fixed;
                z-index: 999;
                left: 0; top: 0;
                width: 100%; height: 100%;
                background-color: rgba(0,0,0,0.5);
                }

                /* Modal Content Box */
                .modal-content {
                background-color: #fff;
                margin: 10% auto;
                padding: 30px;
                border-radius: 12px;
                width: 400px;
                text-align: center;
                box-shadow: 0 0 20px rgba(0,0,0,0.3);
                }

                /* Modal Title */
                .modal-content h2 {
                margin-bottom: 20px;
                font-size: 20px;
                }

                /* Option Buttons */
                .lesson-options button {
                display: block;
                margin: 10px auto;
                padding: 12px 20px;
                font-size: 16px;
                width: 80%;
                border-radius: 8px;
                border: none;
                background-color: #2d89ef;
                color: white;
                transition: background-color 0.3s ease;
                cursor: pointer;
                }

                .lesson-options button:hover {
                background-color: #1b61c1;
                }

                /* Close Button */
                .close {
                color: #aaa;
                float: right;
                font-size: 24px;
                font-weight: bold;
                cursor: pointer;
                }

        <?php else: ?>
            .nav-buttons {
                display: flex;
                gap: 8px; /* Small space between buttons */
            }

            .nav-buttons a {
                display: flex;/* Flex for centering */
                align-items: center;/* Vertical centering */
                justify-content: center;/* Horizontal centering */
                color: white;
                text-decoration: none;
                font-size: 14px;
                padding: 4px 10px;
                border-radius: 5px;
                min-width: 90px; /* ensures consistent button width */
                height: 32px;  /* ensures consistent height */
            }


                /* Option Buttons */
                .lesson-options button {
                display: block;
                margin: 10px auto;
                padding: 12px 20px;
                font-size: 16px;
                width: 80%;
                border-radius: 8px;
                border: none;
                background-color: #2d89ef;
                color: white;
                transition: background-color 0.3s ease;
                cursor: pointer;
                }

                .lesson-options button:hover {
                background-color: #1b61c1;
                }

                /* Close Button */
                .close {
                color: #aaa;
                float: right;
                font-size: 24px;
                font-weight: bold;
                cursor: pointer;
                }
        <?php endif; ?>

        

        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding-top: 20px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }

        .container-title {
            font-size: 30px;
            margin: 30px 50px 10px;
            font-weight: bold;
        }

        .content-container {
            margin: 0 50px 40px;
            overflow-x: auto;
            white-space: nowrap;
        }
        .content-box {
            display: inline-block;
            width: 250px;
            background-color: white;
            margin-right: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .content-box img {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }
        .content-box .info {
            padding: 10px;
        }
        .content-box .info h4 {
            margin: 0;
            font-size: 18px;
        }
        .content-box .info p {
            margin: 5px 0 0;
            color: gray;
            font-size: 14px;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive adjustments for tablets */
        @media (max-width: 1024px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }

        /* Responsive adjustments for phones */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: 100%;
                text-align: center;
                margin-left: 0;
            }

            .hero-text {
                font-size: 36px;
                padding: 0 10px;
            }

            .teacher-button-container {
                flex-direction: column;
                gap: 10px;
            }

            .teacher-button, .admin-button {
                width: 90%;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            /* Show all header buttons on small screens */
            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 20px;
            }

            /* Adjust the size of the create lab, quiz, and lesson buttons */
            .nav-buttons a {
                width: 93%;
                font-size: 16px; /* Ensures consistent button text size */
                padding: 12px 0; /* Adjusts the button padding for better alignment */
            }

            /* Center the dropdown menu */
            .dropdown {
                position: relative;
                width: 100%; /* Ensures dropdown menu takes full width */
                text-align: center;
            }

            .dropdown-content {
                left: 50%;
                transform: translateX(-50%);
            }
        }

    </style>
</head>
<body>
    <?php if (isset($level) && $level == 'Beginner' && ($video_view_count < 1 || $slide_view_count < 1)): ?>
        <div id="beginnerModal" class="beginner-modal" style="display: flex;">
            <div class="beginner-modal-content">
                <h2>Welcome Beginner Student!</h2>
                <p>We recommend starting with our beginner learning materials to build a strong foundation before exploring other content.</p>
                <div class="beginner-modal-buttons">
                    <button class="beginner-modal-btn primary" onclick="window.location.href='material.php'">
                        Go to Learning Materials
                    </button>
                    <button class="beginner-modal-btn secondary" onclick="closeBeginnerModal()">
                        Continue to Dashboard
                    </button>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="header">
    <div class="header-left">CodeLab</div>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="material.php">Learning Material</a>
            <a href="quiz.php">Quiz</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>
        <div class="nav-buttons">
            <?php if ($_SESSION['user_role'] == 'teacher'): ?>
                <a href="create_quiz.php">Create a Quiz</a>
                <a href="create_lab.php">Create a Lab</a>
                <button id="createLessonBtn" class="create-lesson-btn">Create a Lesson</button>
            <?php endif; ?>
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <?php if ($_SESSION['user_role'] == 'teacher'): ?>
                        <a href="view_report.php">Report</a>
                    <?php elseif ($_SESSION['user_role'] == 'student'): ?>
                        <a href="view_result.php">Results</a>
                    <?php endif; ?>
                    <a href="teacher_profile.php">My Profile</a>
                    <a href="troubleshoot_review.php">Troubleshoot Review</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <?php if ($_SESSION['user_role'] == 'teacher'): ?>
    <!-- Lesson Type Modal -->
    <div id="lessonModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>What type of lesson would you like to create?</h2>
            <div class="lesson-options">
            <button onclick="window.location.href='create_slide.php'">Lesson Slides</button>
            <button onclick="window.location.href='create_video.php'">Interactive Videos</button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <p style="margin-left:50px; font-size:24px; font-weight:bold; color:#1565c0;">
        Welcome, <?php echo htmlspecialchars($username); ?>!
    </p>

    <div class="container-title">Assessment Quiz</div>
    <div class="content-container">
        <?php
        $images = ['pic1.jpg.avif', 'pic2.jpg', 'pic3.jpg.avif', 'pic4.jpg', 'pic5.jpg', 'pic6.jpg.avif'];
        if (empty($quizzes)) {
            echo "<p>No quizzes found.</p>";
        }
        foreach ($quizzes as $quiz) {
        ?>
            <a href="view_quiz.php?id=<?php echo $quiz['quiz_id']; ?>" style="text-decoration: none; color: inherit;">
                <div class="content-box">
                    <img src="images/<?php echo $images[array_rand($images)]; ?>" alt="Quiz">
                    <div class="info">
                        <h4><?php echo htmlspecialchars($quiz['title']); ?></h4>
                        <p><?php echo $quiz['created_at']; ?></p>
                    </div>
                </div>
            </a>
        <?php } ?>        
    </div>

    <div class="container-title">Lab Activities</div>
    <div class="content-container">
        <?php
        if (empty($labs)) {
            echo "<p>No lab activities found.</p>";
        }
        foreach ($labs as $lab) {
        ?>
            <a href="view_lab.php?id=<?php echo $lab['lab_id']; ?>" style="text-decoration: none; color: inherit;">
                <div class="content-box">
                    <img src="images/<?php echo $images[array_rand($images)]; ?>" alt="Lab">
                    <div class="info">
                        <h4><?php echo htmlspecialchars($lab['title']); ?></h4>
                        <p><?php echo $lab['created_at']; ?></p>
                    </div>
                </div>
            </a>
        <?php } ?>
    </div>

    <!-- Check if the logged-in user is a student and if they have a preferred learning material -->
    <?php if ($_SESSION['user_role'] == 'student'): ?>
        <?php if ($material_preferred == 'Lesson Slides'): ?>
            <div class="container-title">Lesson Slides</div>
            <div class="content-container">
                <?php
                if (empty($slides)) {
                    echo "<p>No slides found.</p>";
                }
                foreach ($slides as $slide) {
                ?>
                    <a href="view_slide.php?id=<?php echo $slide['slide_id']; ?>" style="text-decoration: none; color: inherit;">
                        <div class="content-box">
                            <img src="images/<?php echo $images[array_rand($images)]; ?>" alt="Slide">
                            <div class="info">
                                <h4><?php echo htmlspecialchars($slide['title']); ?></h4>
                                <p><?php echo $slide['uploaded_at']; ?></p>
                            </div>
                        </div>
                    </a>
                <?php } ?>        
            </div>
        <?php elseif ($material_preferred == 'Interactive Video'): ?>
            <div class="container-title">Interactive Videos</div>
            <div class="content-container">
                <?php
                if (empty($videos)) {
                    echo "<p>No videos found.</p>";
                }
                foreach ($videos as $video) {
                ?>
                    <a href="view_video.php?id=<?php echo $video['video_id']; ?>" style="text-decoration: none; color: inherit;">
                        <div class="content-box">
                            <img src="images/<?php echo $images[array_rand($images)]; ?>" alt="Video">
                            <div class="info">
                                <h4><?php echo htmlspecialchars($video['title']); ?></h4>
                                <p><?php echo $video['uploaded_at']; ?></p>
                            </div>
                        </div>
                    </a>
                <?php } ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <!-- For Teacher, show both materials -->
        <div class="container-title">Lesson Slides</div>
        <div class="content-container">
            <?php
            if (empty($slides)) {
                echo "<p>No slides found.</p>";
            }
            foreach ($slides as $slide) {
            ?>
                <a href="view_slide.php?id=<?php echo $slide['slide_id']; ?>" style="text-decoration: none; color: inherit;">
                    <div class="content-box">
                        <img src="images/<?php echo $images[array_rand($images)]; ?>" alt="Slide">
                        <div class="info">
                            <h4><?php echo htmlspecialchars($slide['title']); ?></h4>
                            <p><?php echo $slide['uploaded_at']; ?></p>
                        </div>
                    </div>
                </a>
            <?php } ?>        
        </div>

        <div class="container-title">Interactive Videos</div>
        <div class="content-container">
            <?php
            if (empty($videos)) {
                echo "<p>No videos found.</p>";
            }
            foreach ($videos as $video) {
            ?>
                <a href="view_video.php?id=<?php echo $video['video_id']; ?>" style="text-decoration: none; color: inherit;">
                    <div class="content-box">
                        <img src="images/<?php echo $images[array_rand($images)]; ?>" alt="Video">
                        <div class="info">
                            <h4><?php echo htmlspecialchars($video['title']); ?></h4>
                            <p><?php echo $video['uploaded_at']; ?></p>
                        </div>
                    </div>
                </a>
            <?php } ?>
        </div>
    <?php endif; ?>

    <div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
    </div>

    <script>
        <?php if ($_SESSION['user_role'] == 'teacher'): ?>
            document.addEventListener("DOMContentLoaded", function () {
            const modal = document.getElementById("lessonModal");
            const btn = document.getElementById("createLessonBtn");
            const closeBtn = document.getElementsByClassName("close")[0];

            if (btn) {
                btn.onclick = function () {
                    modal.style.display = "block";
                }
            }

            if (closeBtn) {
                closeBtn.onclick = function () {
                    modal.style.display = "none";
                }
            }

            window.onclick = function (event) {
                if (event.target === modal) {
                    modal.style.display = "none";
                }
            }
        });

        <?php elseif ($_SESSION['user_role'] == 'student'): ?>
            window.onload = function() {
                <?php if ($level == 'Beginner'): ?>
                    document.getElementById('beginnerModal').style.display = 'flex';
                <?php endif; ?>
            };
            
            function closeBeginnerModal() {
                document.getElementById('beginnerModal').style.display = 'none';
            }

        <?php endif; ?>

    </script>
</body>
</html>