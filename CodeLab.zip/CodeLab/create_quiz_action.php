<?php
session_start();
include('config/config.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $quizTitle = $_POST['quiz_title'];
    $subjectId = $_POST['subject'];
    $topicId = $_POST['topic'];
    $quizDescription = $_POST['description'];
    $quizGrading = $_POST['grading'];
    $teacherUsername = $_SESSION['username'];

    if (empty($subjectId) || empty($topicId)) {
        echo "Error: Subject or Topic is missing.";
        exit();
    }

    $status = 'pending';

    $stmt = $conn->prepare("INSERT INTO quiz (teacher_username, title, subject_id, topic_id, description, grading, created_at, status) VALUES (?, ?, ?, ?, ?, ?, NOW(), ?)");
    $stmt->bind_param("ssiisss", $teacherUsername, $quizTitle, $subjectId, $topicId, $quizDescription, $quizGrading, $status);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $quiz_id = $stmt->insert_id;
        header("Location: create_quiz_question.php?quiz_id=" . $quiz_id);
        echo "Quiz ID generated: " . $quiz_id;
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

