<?php
session_start();
include('config/config.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $slideTitle = $_POST['slide_title'];
    $subjectId = $_POST['subject'];
    $topicId = $_POST['topic'];
    $slideDescription = $_POST['description'];
    $teacherUsername = $_SESSION['username'];

    if (empty($subjectId) || empty($topicId)) {
        echo "Error: Subject or Topic is missing.";
        exit();
    }

    // File Upload
    $file = $_FILES['file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        echo "Upload error: " . $file['error'];
        exit;
    }

        // Check file size (limit: 1000 KB)
        if ($file['size'] > 1024000) {
            echo "<script>
                    alert('Error: File size exceeds 1000 KB limit.');
                    window.location.href = 'create_slide.php';
                </script>";
            exit;
        }

    $fileTmpPath = $file['tmp_name'];
    $fileName = basename($file['name']);
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));


    $fileContent = file_get_contents($fileTmpPath);

    $status = 'pending';

    // Prepare SQL and bind parameters
    $stmt = $conn->prepare("INSERT INTO lesson_slide (teacher_username, title, subject_id, topic_id, description, file_name, file_type, file_data, uploaded_at, status) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)");

    // Use 'ssiisssb' and a placeholder for file data
    $null = NULL; // placeholder for file_data
    $stmt->bind_param("ssiisssbs", $teacherUsername, $slideTitle, $subjectId, $topicId, $slideDescription, $fileName, $fileType, $null, $status);

    // Now send the actual binary data for the BLOB
    $stmt->send_long_data(7, $fileContent);  // 7 = index of 'file_data' (0-based)

    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>





