<?php
include("config/config.php");
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['quiz_id'])) {
    $quizId = intval($_GET['quiz_id']);

    // Check if this quiz has any questions
    $stmt = $conn->prepare("SELECT COUNT(*) FROM quiz_question WHERE quiz_id = ?");
    $stmt->bind_param("i", $quizId);
    $stmt->execute();
    $stmt->bind_result($questionCount);
    $stmt->fetch();
    $stmt->close();

    // If no questions exist, delete the quiz
    if ($questionCount == 0) {
        $stmt = $conn->prepare("DELETE FROM quiz WHERE quiz_id = ?");
        $stmt->bind_param("i", $quizId);
        $stmt->execute();
        $stmt->close();
    }

    $_SESSION['message'] = "Quiz creation was cancelled.";
    header("Location: dashboard.php");
    exit();
} else {
    header("Location: dashboard.php");
    exit();
}
?>
