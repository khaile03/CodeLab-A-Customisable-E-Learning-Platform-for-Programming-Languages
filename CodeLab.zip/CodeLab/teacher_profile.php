<?php
include('config/config.php');
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['username'])) {
    echo "Unauthorized access.";
    exit();
}

$username = $_SESSION['username'];
$message = "";

// Fetch current teacher profile
$query = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($conn, $query);
$teacher = mysqli_fetch_assoc($result);

// Update name and email
if (isset($_POST['update_profile'])) {
    $newName = mysqli_real_escape_string($conn, $_POST['name']);
    $newEmail = mysqli_real_escape_string($conn, $_POST['email']);

    // Check if the new email is already used by another user
    $checkEmailQuery = "SELECT * FROM users WHERE email = '$newEmail' AND username != '$username'";
    $checkResult = mysqli_query($conn, $checkEmailQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        $message = "Email is already in use by another account.";
    } else {
        $updateQuery = "UPDATE users SET name='$newName', email='$newEmail' WHERE username='$username'";
        if (mysqli_query($conn, $updateQuery)) {
            $message = "Profile updated successfully.";
            // Refresh teacher data
            $result = mysqli_query($conn, $query);
            $teacher = mysqli_fetch_assoc($result);
        } else {
            $message = "Failed to update profile.";
        }
    }
}

// Change password logic
if (isset($_POST['change_password'])) {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    if ($new !== $confirm) {
        $message = "New password and confirmation do not match.";
    } else {
        // Check current password
        if ($current !== $teacher['password']) {
            $message = "Current password is incorrect.";
        } else {
            $updatePasswordQuery = "UPDATE users SET password='$new' WHERE username='$username'";
            if (mysqli_query($conn, $updatePasswordQuery)) {
                $message = "Password changed successfully.";
            } else {
                $message = "Failed to change password.";
            }
        }
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Teacher Profile</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

            .header-left .logo {
                font-size: 40px;
                font-weight: bold;
                text-decoration: none;
                color: white;
                margin-right: 20px;
            }

            .nav {
                display: flex;
                gap: 5px;
                align-items: center;
                justify-content: flex-start; /* Align breadcrumbs to the left */
                margin-right: auto; /* Ensures it sticks to the left */
                white-space: nowrap;     
                padding: 8px 12px;      
                display: inline-block; 
            }

            .nav a {
                color: white;
                text-decoration: none;
                font-size: 18px;
                font-weight: bold;
                padding: 8px 12px;  
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }

            .nav a:hover {
                background-color: #0d47a1;
            }
        
        .nav-buttons {
            display: flex;
            gap: 8px; /* Small space between buttons */
        }

        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a[href="create_quiz.php"] {
            background-color: #42a5f5; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a[href="create_lab.php"] {
            background-color: #0b3c91; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }

        #createLessonBtn {
            background-color: #3f51b5; 
            border-radius: 5px;
            color: white;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: opacity 0.3s ease;
            white-space: nowrap;     
            padding: 8px 12px;      
            display: inline-block; 
        }

        #createLessonBtn:hover {
            opacity: 0.9;
        }

        .modal {
        display: none;
        position: fixed;
        z-index: 999;
        left: 0; top: 0;
        width: 100%; height: 100%;
        background-color: rgba(0,0,0,0.5);
        }

        /* Modal Content Box */
        .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 30px;
        border-radius: 12px;
        width: 400px;
        text-align: center;
        box-shadow: 0 0 20px rgba(0,0,0,0.3);
        }

        /* Modal Title */
        .modal-content h2 {
        margin-bottom: 20px;
        font-size: 20px;
        }

        /* Option Buttons */
        .lesson-options button {
        display: block;
        margin: 10px auto;
        padding: 12px 20px;
        font-size: 16px;
        width: 80%;
        border-radius: 8px;
        border: none;
        background-color: #2d89ef;
        color: white;
        transition: background-color 0.3s ease;
        cursor: pointer;
        }

        .lesson-options button:hover {
        background-color: #1b61c1;
        }

        /* Close Button */
        .close {
        color: #aaa;
        float: right;
        font-size: 24px;
        font-weight: bold;
        cursor: pointer;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            margin-top: 80px;
            margin-bottom: 80px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        img.profile {
            width: 80px;
            display: block;
            margin: 0 auto 20px;
        }
        label {
            display: block;
            margin-top: 12px;
            color: #444;
        }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            margin-top: 5px;
        }
        input[readonly] {
            background-color: #f2f2f2;
        }
        .btn {
            margin-top: 20px;
            padding: 12px 24px;
            background: #007BFF;
            border: none;
            color: white;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background: #0056b3;
        }
        .message {
            color: green;
            margin-top: 15px;
        }
        .error {
            color: red;
        }
        .password-link {
            color: #007BFF;
            cursor: pointer;
            margin-top: 10px;
            display: inline-block;
            margin-right: 20px;
        }
        #passwordModal {
            display: none;
            position: fixed;
            z-index: 999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.6);
        }
        .modal-content {
            background-color: white;
            padding: 20px;
            margin: 10% auto;
            border-radius: 10px;
            width: 400px;
            position: relative;
        }
        .modal-content input[type="password"] {
            width: 90%;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            margin-top: 8px;
        }
        .close {
            position: absolute;
            right: 15px;
            top: 10px;
            font-size: 22px;
            color: #aaa;
            cursor: pointer;
        }
        .close:hover {
            color: #000;
        }
        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive adjustments for tablets */
        @media (max-width: 1024px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }

        /* Responsive adjustments for phones */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: 100%;
                text-align: center;
                margin-left: 0;
            }

            .hero-text {
                font-size: 36px;
                padding: 0 10px;
            }

            .teacher-button-container {
                flex-direction: column;
                gap: 10px;
            }

            .teacher-button, .admin-button {
                width: 90%;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            /* Show all header buttons on small screens */
            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 20px;
            }

            /* Adjust the size of the create lab, quiz, and lesson buttons */
            .nav-buttons a {
                width: 93%;
                font-size: 16px; /* Ensures consistent button text size */
                padding: 12px 0; /* Adjusts the button padding for better alignment */
            }

            /* Center the dropdown menu */
            .dropdown {
                position: relative;
                width: 100%; /* Ensures dropdown menu takes full width */
                text-align: center;
            }

            .dropdown-content {
                left: 50%;
                transform: translateX(-50%);
            }
        }

    </style>
</head>
<body>

<div class="header">
        <div class="header-left">   
            <a>CodeLab</a>
        </div>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="material.php">Learning Material</a>
            <a href="quiz.php">Quiz</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>
        <div class="nav-buttons">
            <?php if ($_SESSION['user_role'] == 'teacher'): ?>
                <a href="create_quiz.php">Create a Quiz</a>
                <a href="create_lab.php">Create a Lab</a>
                <button id="createLessonBtn" class="create-lesson-btn">Create a Lesson</button>
            <?php endif; ?>
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <?php if ($_SESSION['user_role'] == 'teacher'): ?>
                        <a href="view_report.php">Report</a>
                    <?php elseif ($_SESSION['user_role'] == 'student'): ?>
                        <a href="view_result.php">Results</a>
                    <?php endif; ?>
                    <a href="teacher_profile.php">My Profile</a>
                    <a href="troubleshoot_review.php">Troubleshoot Review</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Lesson Type Modal -->
    <div id="lessonModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>What type of lesson would you like to create?</h2>
            <div class="lesson-options">
            <button onclick="window.location.href='create_slide.php'">Lesson Slides</button>
            <button onclick="window.location.href='create_video.php'">Interactive Videos</button>
            </div>
        </div>
    </div>

<div class="container">
    <h2>My Profile</h2>
    <img src="https://cdn-icons-png.flaticon.com/512/9815/9815472.png" class="profile" alt="Profile Picture">

    <?php if ($message != ""): ?>
        <p class="<?php echo strpos($message, 'successfully') !== false ? 'message' : 'error'; ?>"><?php echo $message; ?></p>
    <?php endif; ?>

    <form method="POST">
        <label>Username:</label>
        <input type="text" name="username" value="<?php echo $teacher['username']; ?>" readonly>

        <label>Full Name:</label>
        <input type="text" name="name" value="<?php echo $teacher['name']; ?>" required>

        <label>Email Address:</label>
        <input type="email" name="email" value="<?php echo $teacher['email']; ?>" required>

        <label class="password-link" onclick="document.getElementById('passwordModal').style.display='block'">Change Password</label>

        <button type="submit" name="update_profile" class="btn">Update Profile</button>
    </form>
</div>

<!-- Password Modal -->
<div id="passwordModal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('passwordModal').style.display='none'">&times;</span>
        <h3>Change Password</h3>
        <form method="POST">
            <label>Current Password:</label>
            <input type="password" name="current_password" required>

            <label>New Password:</label>
            <input type="password" name="new_password" required>

            <label>Confirm New Password:</label>
            <input type="password" name="confirm_password" required>

            <button type="submit" name="change_password" class="btn" style="margin-top: 15px;">Change Password</button>
        </form>
    </div>
</div>

<div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
</div>


<script>
        window.addEventListener("scroll", function () {
            var footer = document.getElementById("footer");
            if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
                footer.style.display = "block";
            } else {
                footer.style.display = "none";
            }
        });

        const modal = document.getElementById("lessonModal");
        const btn = document.getElementById("createLessonBtn");
        const closeBtn = document.getElementsByClassName("close")[0];

        btn.onclick = function () {
            modal.style.display = "block";
        }

        closeBtn.onclick = function () {
            modal.style.display = "none";
        }

        window.onclick = function (event) {
            if (event.target === modal) {
            modal.style.display = "none";
            }
        }

        // Close modal if user clicks outside of it
        window.onclick = function(event) {
            var modal = document.getElementById('passwordModal');
            if (event.target === modal) {
                modal.style.display = "none";
            }
        }
    </script>

</body>
</html>

