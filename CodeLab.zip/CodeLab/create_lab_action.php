<?php
session_start();
include('config/config.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $labTitle = $_POST['lab_title'];
    $subjectId = $_POST['subject'];
    $topicId = $_POST['topic'];
    $labDescription = $_POST['description'];
    $labGrading = $_POST ['grading'];
    $teacherUsername = $_SESSION['username'];

    if (empty($subjectId) || empty($topicId)) {
        echo "Error: Subject or Topic is missing.";
        exit();
    }

    $status = 'pending';

    $stmt = $conn->prepare("INSERT INTO lab (teacher_username, title, subject_id, topic_id, description, grading, created_at, status) VALUES (?, ?, ?, ?, ?, ?, NOW(), ?)");
    $stmt->bind_param("ssiisss", $teacherUsername, $labTitle, $subjectId, $topicId, $labDescription, $labGrading, $status);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $lab_id = $stmt->insert_id;
        header("Location: add_lab_question.php?lab_id=" . $lab_id);
        echo "Quiz ID generated: " . $lab_id;
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>