<?php
session_start();
require_once "config/config.php";

// Initialize variables
$error = '';
$success = '';
$subjects = [];
$preferences = [];

// Fetch available subjects from database
$subject_query = "SELECT subject_id, name FROM subject";
$subject_result = $conn->query($subject_query);
while ($row = $subject_result->fetch_assoc()) {
    $subjects[$row['subject_id']] = $row['name'];
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_survey'])) {
    if (!isset($_POST['subjects'])) {
        $error = 'Please select at least one subject';
    } else {
        $username = $_SESSION['username'];
        
        // Get both IDs and names of selected subjects
        $selected_subjects = [];
        foreach ($_POST['subjects'] as $subject_id) {
            if (isset($subjects[$subject_id])) {
                $selected_subjects[$subject_id] = $subjects[$subject_id];
            }
        }
        
        try {
            // Begin transaction
            $conn->begin_transaction();

            // Insert new preferences (one row per selected subject)
            $insert_stmt = $conn->prepare("INSERT INTO student_preference (student_username, subject_interested, created_at) VALUES (?, ?, NOW())");
            foreach ($selected_subjects as $subject_id => $subject_name) {
                $insert_stmt->bind_param("ss", $username, $subject_name);
                $insert_stmt->execute();
            }
            
            // Commit transaction
            $conn->commit();
            
            $success = 'Your preferences have been saved successfully!';
            header("Refresh: 2; url=student_material.php");
        } catch (Exception $e) {
            $conn->rollback();
            $error = 'Error saving your preferences: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CodeLab - Student Preferences</title>
    <style>
        /* Inherit all styles from landing_page.php */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #e3f2fd;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #0d47a1;
        }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-left .logo {
            font-size: 40px;
            font-weight: bold;
            text-decoration: none;
            color: white;
            margin-right: 20px;
        }
        
        /* Survey-specific styles */
        .survey-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .survey-title {
            font-size: 32px;
            margin-bottom: 30px;
            color: #1565c0;
        }
        
        .survey-section {
            margin-bottom: 30px;
            text-align: left;
        }
        
        .section-title {
            font-size: 24px;
            margin-bottom: 15px;
            color: #0d47a1;
            border-bottom: 2px solid #bbdefb;
            padding-bottom: 5px;
        }
        
        .subject-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .subject-card {
            border: 2px solid #bbdefb;
            border-radius: 8px;
            padding: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .subject-card:hover {
            background-color: #e3f2fd;
            transform: translateY(-3px);
        }
        
        .subject-card.selected {
            background-color: #bbdefb;
            border-color: #0d47a1;
        }
        
        .submit-btn {
            background-color: #1565c0;
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 20px;
        }
        
        .submit-btn:hover {
            background-color: #0d47a1;
            transform: translateY(-2px);
        }
        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            box-sizing: border-box;
        }
        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <a>CodeLab</a>
        </div>
    </div>

    <div class="survey-container fade-in">
        <h1 class="survey-title">Personalize Your Learning Experience</h1>
        
        <?php if ($error): ?>
            <div class="error-message" style="color: #d32f2f; margin-bottom: 20px;"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success-message" style="color: #388e3c; margin-bottom: 20px;"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <!-- Subject Interests Section -->
            <div class="survey-section">
                <h2 class="section-title">1. Select Your Subjects of Interest</h2>
                <p>Choose all subjects you're interested in learning:</p>
                
                <div class="subject-grid">
                    <?php foreach ($subjects as $id => $name): ?>
                        <label class="subject-card">
                            <input type="checkbox" name="subjects[]" value="<?php echo $id; ?>" style="display: none;">
                            <?php echo htmlspecialchars($name); ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <button type="submit" name="submit_survey" class="submit-btn">Save Preferences</button>
        </form>
    </div>

    <!-- Reuse footer from landing page -->
    <div class="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
    </div>

    <script>
        // Subject selection functionality
        document.querySelectorAll('.subject-card').forEach(card => {
            card.addEventListener('click', function() {
                const checkbox = this.querySelector('input[type="checkbox"]');
                checkbox.checked = !checkbox.checked;
                this.classList.toggle('selected', checkbox.checked);
            });
        });
        
        // Scroll reveal animation (same as landing page)
        function revealOnScroll() {
            let elements = document.querySelectorAll(".fade-in");
            let windowHeight = window.innerHeight;
            
            elements.forEach(function(el) {
                let elementTop = el.getBoundingClientRect().top;
                if (elementTop < windowHeight - 100) {
                    el.classList.add("visible");
                }
            });
        }
        
        window.addEventListener("scroll", revealOnScroll);
        document.addEventListener("DOMContentLoaded", revealOnScroll);
    </script>
</body>
</html>