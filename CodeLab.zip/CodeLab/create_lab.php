<?php
session_start();

// Connect to the database
include("config/config.php");

$teacherUsername = $_SESSION['username'];

// Handle AJAX topic request
if (isset($_POST['subject_id'])) {
    $subject_id = $_POST['subject_id'];
    $stmt = $conn->prepare("SELECT topic_id, title FROM topic WHERE subject_id = ?");
    $stmt->bind_param("i", $subject_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $topics = array();
    while ($row = $result->fetch_assoc()) {
        $topics[] = $row;
    }
    echo json_encode($topics);
    exit;
}

// Get subjects
$subjects = $conn->query("SELECT subject_id, name FROM subject");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Lab</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            font-size: 20px;
        }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .nav-buttons a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
            font-size: 18px;
        }
        .nav-buttons a[href="create_quiz.php"] {
            background-color: #1e88e5;
            padding: 8px 15px;
            border-radius: 5px;
        }
        .nav-buttons a[href="create_lesson.php"] {
            background-color: #0d47a1;
            padding: 8px 15px;
            border-radius: 5px;
        }
        .dropdown { position: relative; display: inline-block; }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content { display: block; }
        .container {
            max-width: 900px;
            margin: 50px auto;
            background: white;
            padding: 50px;
            border-radius: 12px;
            box-shadow: 0px 3px 8px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; color: #1565c0; font-size: 32px; }
        label { display: block; margin-top: 25px; font-weight: bold; font-size: 22px;}
        input[type="text"], select, textarea {
            width: 100%;
            padding: 16px;
            margin-top: 10px;
            font-size: 20px;
            border-radius: 8px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        input::placeholder, textarea::placeholder {
            color: #aaa;
            font-size: 18px;
        }

        textarea {
            resize: vertical;
            min-height: 150px;
        }

        .button-group {
            margin-top: 35px;
            text-align: center;
        }
        .button-group button {
            padding: 16px 30px;
            font-size: 20px;
            border: none;
            border-radius: 10px;
            margin: 0 20px;
            cursor: pointer;
        }
        .create-btn { background-color: #27ae60; color: white; }
        .cancel-btn { background-color: #e74c3c; color: white; }

        .popup {
            display: none;
            position: fixed;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -30%);
            background: white;
            border: 2px solid #1565c0;
            padding: 20px;
            z-index: 99;
            box-shadow: 0px 5px 15px rgba(0,0,0,0.3);
            text-align: center;
        }
        .popup .close {
            float: right;
            font-size: 22px;
            cursor: pointer;
            color: red;
        }
        .popup button {
            margin-top: 15px;
            padding: 10px 20px;
            background-color: #1565c0;
            color: white;
            border: none;
            border-radius: 5px;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="header">CodeLab</div>

<div class="container">
    <h2>Create a New Lab Activity</h2>
    <form action="create_lab_action.php" method="POST">
        <label for="lab_title">Lab Title</label>
        <input type="text" name="lab_title" placeholder="e.g. Lab Activity about Data Types" required>

        <label for="subject">Subject</label>
        <select name="subject" id="subject" required>
            <option value="">-- Select Subject --</option>
            <?php while ($row = $subjects->fetch_assoc()) {
                echo "<option value='{$row['subject_id']}'>{$row['name']}</option>";
            } ?>
        </select>

        <label for="topic">Topic</label>
        <select name="topic" id="topic" required>
            <option value="">-- Select Topic --</option>
        </select>

        <label for="grading">Grading</label>
        <select name="grading" id="grading" required>
            <option value="">-- Select Grading --</option>
            <option value="10">10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="40">40</option>
            <option value="50">50</option>
            <option value="60">60</option>
            <option value="70">70</option>
            <option value="80">80</option>
            <option value="90">90</option>
            <option value="100">100</option>
        </select>
        <small>How much should student score to pass this assessment?</small>

        <label for="description">Description</label>
        <textarea name="description" rows="5" placeholder="Write a short description of the quiz..." required></textarea>

        <div class="button-group">
            <button type="submit" name="create_lab" class="create-btn">Create</button>
            <button type="button" class="cancel-btn" onclick="document.getElementById('cancelPopup').style.display='block'">Cancel</button>
        </div>
    </form>
</div>

<div class="popup" id="cancelPopup">
    <span class="close" onclick="document.getElementById('cancelPopup').style.display='none'">&times;</span>
    <p>Do you want to cancel and stop creating the lab activity?</p>
    <button onclick="window.location.href='dashboard.php'">OK</button>
</div>

<div class="footer" id="footer">
    &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
</div>

<script>
    function showPopup() {
        document.getElementById("popup").style.display = "block";
    }
    function hidePopup() {
        document.getElementById("popup").style.display = "none";
    }

    document.getElementById('subject').addEventListener('change', function() {
        var subject_id = this.value;
        var topicSelect = document.getElementById('topic');
        topicSelect.innerHTML = '<option value="">Loading...</option>';

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'create_lab.php', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.onload = function () {
            var data = JSON.parse(this.responseText);
            topicSelect.innerHTML = '<option value="">-- Select Topic --</option>';
            data.forEach(function(item) {
                var opt = document.createElement("option");
                opt.value = item.topic_id;
                opt.innerHTML = item.title;
                topicSelect.appendChild(opt);
            });
        };
        xhr.send('subject_id=' + subject_id);
    });

</script>

</body>
</html>