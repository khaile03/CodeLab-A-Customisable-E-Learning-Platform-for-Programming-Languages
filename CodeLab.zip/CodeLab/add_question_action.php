<?php
// Include database connection
include("config/config.php");
session_start();

// Verify if the teacher username is available in the session
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Get lab_id from the URL
$labId = isset($_GET['lab_id']) ? $_GET['lab_id'] : null;
if (!$labId) {
    header("Location: create_lab.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Start a database transaction
    $conn->begin_transaction();

    try {
        // Process each question
        if (isset($_POST['questions']) && is_array($_POST['questions'])) {
            foreach ($_POST['questions'] as $questionData) {
                $question = $questionData['question'] ?? '';
                $answer = trim($questionData['answer'] ?? '');
                $hint = $questionData['hint'] ?? '';

                // Insert into the lab_question table
                $stmt = $conn->prepare("INSERT INTO lab_question (lab_id, question, correct_answer, hint) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("isss", $labId, $question, $answer, $hint);
                $stmt->execute();
            }
        }

        // Commit the transaction
        $conn->commit();

        // Redirect with success message
        $_SESSION['success_message'] = "Lab activity successfully published!";
        header("Location: dashboard.php");
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
}

// Close the connection
$conn->close();
?>