<?php
include 'config/config.php';

if (!isset($_GET['id'])) {
    echo "Quiz ID is missing.";
    exit;
}

$quizId = $_GET['id'];

// Delete quiz questions first (to maintain referential integrity)
$deleteQuestionsSql = "DELETE FROM quiz_question WHERE quiz_id = ?";
$questionStmt = $conn->prepare($deleteQuestionsSql);
$questionStmt->bind_param("i", $quizId);
$questionStmt->execute();

// Delete the quiz
$deleteQuizSql = "DELETE FROM quiz WHERE quiz_id = ?";
$labStmt = $conn->prepare($deleteQuizSql);
$labStmt->bind_param("i", $quizId);

if ($labStmt->execute()) {
    echo "<script>alert('Quiz deleted successfully.'); window.location.href='dashboard.php';</script>";
} else {
    echo "Failed to delete quiz.";
}
?>