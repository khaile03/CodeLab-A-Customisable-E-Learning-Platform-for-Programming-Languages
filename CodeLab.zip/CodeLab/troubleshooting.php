<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check admin login
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include("config/config.php");

// Handle ticket reply
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_ticket'])) {
    $ticketId = $_POST['ticket_id'];
    $reply = $_POST['reply'];
    
    // Automatically set status to "resolved" when replying
    $status = 'Resolved';
    
    $stmt = $conn->prepare("UPDATE tickets SET reply = ?, status = ? WHERE ticket_id = ?");
    $stmt->bind_param("sss", $reply, $status, $ticketId);
    $stmt->execute();
    
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}
    
// Fetch all tickets
$ticketStmt = $conn->prepare("SELECT * FROM tickets ORDER BY status");
$ticketStmt->execute();
$ticketResult = $ticketStmt->get_result();
$tickets = $ticketResult->fetch_all(MYSQLI_ASSOC);

// Function to get ticket text for modal
function getTicketText($conn, $ticketId) {
    $stmt = $conn->prepare("SELECT text FROM tickets WHERE ticket_id = ?");
    $stmt->bind_param("s", $ticketId);
    $stmt->execute();
    $result = $stmt->get_result();
    $ticket = $result->fetch_assoc();
    return $ticket['text'] ?? '';
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Troubleshooting Tickets</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-left .logo {
            font-size: 40px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav {
            display: flex;
            gap: 15px;
            align-items: center;
            justify-content: flex-start;
            margin-right: auto;
            padding-left: 30px;
        }
        .nav a {
            color: white;
            text-decoration: none;
            font-size: 17px;
            font-weight: bold;
            padding: 8px 12px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .nav a:hover {
            background-color: #0d47a1;
        }
        .nav-buttons {
            display: flex;
            gap: 8px;
        }

        .nav-buttons a {
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px;
            height: 32px;
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }
        
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
        
        /* Table styles */
        .table-container {
            padding: 20px;
            margin: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #1565c0;
            color: white;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .action-btns {
            display: flex;
            gap: 5px;
        }
        .reply-btn {
            background-color: #2196F3;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        .status-pending {
            color: #FF9800;
            font-weight: bold;
        }
        .status-resolved {
            color: #4CAF50;
            font-weight: bold;
        }
        .status-rejected {
            color: #f44336;
            font-weight: bold;
        }
        .description {
            max-width: 200px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        .modal-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 60%;
            border-radius: 8px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: black;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            min-height: 100px;
        }
        .submit-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        .submit-btn:hover {
            background-color: #45a049;
        }
        .ticket-text {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            border-left: 4px solid #1565c0;
        }
        .ticket-text-label {
            font-weight: bold;
            margin-bottom: 5px;
            color: #1565c0;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive for tablets (landscape, <= 1024px) */
         @media (max-width: 1024px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px 30px;
            }

            .nav {
                flex-wrap: wrap;
                justify-content: flex-start;
                padding-left: 0;
                margin-top: 10px;
                gap: 10px;
            }

            .nav a {
                font-size: 15px;
                padding: 8px 10px;
            }

            .nav-buttons {
                align-self: flex-end;
                margin-top: 10px;
            }

            .nav-buttons a {
                font-size: 14px;
                padding: 6px 12px;
            }

            .container-title {
                font-size: 26px;
            }

            .small-title {
                font-size: 22px;
            }

            .content-box {
                width: 220px;
            }
        }

        /* Responsive for phones (portrait, <= 768px) */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: stretch;
                padding: 20px;
            }

            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-start;
                gap: 10px;
                padding-left: 0;
                margin-top: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 16px;
                font-size: 14px;
            }

            .nav-buttons {
                display: flex;
                justify-content: flex-end;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: auto;
                font-size: 14px;
                padding: 10px 14px;
            }

            .dropdown {
                width: auto;
            }

            .dropdown-content {
                min-width: 140px;
                left: auto;
                right: 0;
                transform: none;
            }

            .table-container {
                padding: 10px;
                margin: 10px;
                overflow-x: auto;
                width: 95%;
            }

            table {
                min-width: 600px; /* Minimum width to enable horizontal scrolling */
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            .hero-text {
                font-size: 28px;
                padding: 0 10px;
            }
        }
        
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <a>CodeLab</a>
        </div>
        <div class="nav">
            <a href="admin_dashboard.php">Homepage</a>
            <a href="user_management.php">User Management</a>
            <a href="material_approval.php">Learning Material Approval</a>
            <a href="quiz_approval.php">Quiz Approval</a>
            <a href="lab_approval.php">Lab Approval</a>
            <a href="troubleshooting.php">Troubleshooting</a>
        </div>
        <div class="nav-buttons">
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <a href="admin_profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="table-container">
        <h2>Troubleshooting Tickets</h2>
        
        <table>
            <thead>
                <tr>
                    <th>Ticket ID</th>
                    <th>Username</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($tickets)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center;">No tickets found</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($tickets as $ticket): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($ticket['ticket_id']); ?></td>
                            <td><?php echo htmlspecialchars($ticket['username']); ?></td>
                            <td class="description" title="<?php echo htmlspecialchars($ticket['description']); ?>">
                                <?php echo htmlspecialchars($ticket['description']); ?>
                            </td>
                            <td class="status-<?php echo strtolower($ticket['status'] ?? 'pending'); ?>">
                                <?php echo ucfirst($ticket['status'] ?? 'pending'); ?>
                            </td>
                            <td class="action-btns">
                                <?php if (strtolower($ticket['status']) === 'pending'): ?>
                                    <button onclick="openReplyModal('<?php echo $ticket['ticket_id']; ?>', '<?php echo htmlspecialchars($ticket['text']); ?>')" class="reply-btn">Reply</button>
                                <?php else: ?>
                                    <button class="reply-btn" disabled>Replied</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div id="replyModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h3>Reply to Ticket</h3>
            <div id="ticketTextDisplay" class="ticket-text">
                <div class="ticket-text-label">Text: </div>
                <div id="ticketTextContent"></div>
            </div>
            <form method="POST" action="troubleshooting.php">
                <input type="hidden" id="modal_ticket_id" name="ticket_id">
                <div class="form-group">
                    <label for="reply">Your Reply:</label>
                    <textarea id="reply" name="reply" required></textarea>
                </div>
                <button type="submit" name="reply_ticket" class="submit-btn">Submit Reply</button>
            </form>
        </div>
    </div>

    <div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. 
    </div>

    <script>
        // Modal functions
        function openReplyModal(ticketId, ticketText) {
            document.getElementById('modal_ticket_id').value = ticketId;
            document.getElementById('ticketTextContent').textContent = ticketText;
            document.getElementById('replyModal').style.display = 'block';
        }
        
        function closeModal() {
            document.getElementById('replyModal').style.display = 'none';
        }
        
        // Close modal when clicking outside of it
        window.onclick = function(event) {
            const modal = document.getElementById('replyModal');
            if (event.target === modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>