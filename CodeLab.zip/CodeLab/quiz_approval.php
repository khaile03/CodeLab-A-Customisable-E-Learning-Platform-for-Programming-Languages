<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check admin login
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include("config/config.php");

// Handle approve/reject actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve_quiz'])) {
        $quizId = $_POST['quiz_id'];
        $stmt = $conn->prepare("UPDATE quiz SET status = 'approved' WHERE quiz_id = ?");
        $stmt->bind_param("i", $quizId);
        $stmt->execute();
    } elseif (isset($_POST['reject_quiz'])) {
        $quizId = $_POST['quiz_id'];
        $stmt = $conn->prepare("UPDATE quiz SET status = 'rejected' WHERE quiz_id = ?");
        $stmt->bind_param("i", $quizId);
        $stmt->execute();
    }
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Fetch all quizzes with teacher names
$quizStmt = $conn->prepare("SELECT q.*, u.name AS teacher_name FROM quiz q JOIN users u ON q.teacher_username = u.username");
$quizStmt->execute();
$quizResult = $quizStmt->get_result();
$quizzes = $quizResult->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Approval</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-left .logo {
            font-size: 40px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav {
            display: flex;
            gap: 15px;
            align-items: center;
            justify-content: flex-start;
            margin-right: auto;
            padding-left: 30px;
        }
        .nav a {
            color: white;
            text-decoration: none;
            font-size: 17px;
            font-weight: bold;
            padding: 8px 12px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .nav a:hover {
            background-color: #0d47a1;
        }
        .nav-buttons {
            display: flex;
            gap: 8px;
        }

        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }
        
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
        
        /* Table styles */
        .table-container {
            padding: 20px;
            margin: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #1565c0;
            color: white;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .action-btns {
            display: flex;
            gap: 5px;
        }
        .approve-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        .reject-btn {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        .view-btn {
            background-color: #2196F3;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .status-pending {
            color: #FF9800;
            font-weight: bold;
        }
        .status-approved {
            color: #4CAF50;
            font-weight: bold;
        }
        .status-rejected {
            color: #f44336;
            font-weight: bold;
        }
        .description {
            max-width: 200px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .select-all {
            text-align: center;
        }
        .bulk-actions {
            margin-top: 15px;
            display: flex;
            gap: 10px;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive for tablets (landscape, <= 1024px) */
         @media (max-width: 1024px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px 30px;
            }

            .nav {
                flex-wrap: wrap;
                justify-content: flex-start;
                padding-left: 0;
                margin-top: 10px;
                gap: 10px;
            }

            .nav a {
                font-size: 15px;
                padding: 8px 10px;
            }

            .nav-buttons {
                align-self: flex-end;
                margin-top: 10px;
            }

            .nav-buttons a {
                font-size: 14px;
                padding: 6px 12px;
            }

            .container-title {
                font-size: 26px;
            }

            .small-title {
                font-size: 22px;
            }

            .content-box {
                width: 220px;
            }
        }

        /* Responsive for phones (portrait, <= 768px) */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: stretch;
                padding: 20px;
            }

            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-start;
                gap: 10px;
                padding-left: 0;
                margin-top: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 16px;
                font-size: 14px;
            }

            .nav-buttons {
                display: flex;
                justify-content: flex-end;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: auto;
                font-size: 14px;
                padding: 10px 14px;
            }

            .dropdown {
                width: auto;
            }

            .dropdown-content {
                min-width: 140px;
                left: auto;
                right: 0;
                transform: none;
            }

            .table-container {
                padding: 10px;
                margin: 10px;
                overflow-x: auto;
                width: 95%;
            }

            table {
                min-width: 600px; /* Minimum width to enable horizontal scrolling */
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            .hero-text {
                font-size: 28px;
                padding: 0 10px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <a>CodeLab</a>
        </div>
        <div class="nav">
            <a href="admin_dashboard.php">Homepage</a>
            <a href="user_management.php">User Management</a>
            <a href="material_approval.php">Learning Material Approval</a>
            <a href="quiz_approval.php">Quiz Approval</a>
            <a href="lab_approval.php">Lab Approval</a>
            <a href="troubleshooting.php">Troubleshooting</a>
        </div>
        <div class="nav-buttons">
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <a href="admin_profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="table-container">
        <h2>Quiz Approval Management</h2>
        
        <table>
            <thead>
                <tr>
                    <th>Quiz ID</th>
                    <th>Teacher</th>
                    <th>Title</th>
                    <th>Created At</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($quizzes)): ?>
                    <tr>
                        <td colspan="10" style="text-align: center;">No quizzes found</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($quizzes as $quiz): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($quiz['quiz_id']); ?></td>
                            <td><?php echo htmlspecialchars($quiz['teacher_name']); ?></td>
                            <td><?php echo htmlspecialchars($quiz['title']); ?></td>
                            <td><?php echo htmlspecialchars($quiz['created_at']); ?></td>
                            <td class="status-<?php echo strtolower($quiz['status']); ?>">
                                <?php echo ucfirst($quiz['status']); ?>
                            </td>

                            <td class="action-btns">
                                <form method="POST" style="display: inline;">
                                    <a href="aview_quiz.php?id=<?php echo $quiz['quiz_id']; ?>" class="view-btn">View</a>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. 
</div>

</body>
</html>