-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 05, 2025 at 04:38 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codelab`
--

-- --------------------------------------------------------

--
-- Table structure for table `interactive_video`
--

CREATE TABLE `interactive_video` (
  `video_id` int(11) NOT NULL,
  `teacher_username` varchar(50) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL,
  `reason` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `interactive_video`
--

INSERT INTO `interactive_video` (`video_id`, `teacher_username`, `subject_id`, `topic_id`, `title`, `description`, `video_url`, `uploaded_at`, `status`, `reason`) VALUES
(2, 'JiaYi', 2, 10, 'SQL Essentials: Mastering the SELECT Statement', 'Learn how to retrieve data from databases using the SQL SELECT statement—the foundation of data querying. This interactive video lesson guides you through selecting specific columns, filtering results with WHERE, sorting data with ORDER BY, and using functions like COUNT(), AVG(), and SUM() to analyze information. Whether you\'re a beginner or refreshing your skills, this lesson provides hands-on examples and interactive exercises to help you confidently extract and manipulate data using SQL.', 'https://www.youtube.com/watch?v=yuYKEx6VDPE', '2025-05-01 13:09:14', 'Approved', NULL),
(3, 'JiaYi', 3, 21, 'Exploring Python Lists', 'This lesson introduces Python’s list data structure, which allows storing multiple items in a single variable. Students will learn how to create, access, modify, and manipulate lists using indexing, slicing, and built-in list methods.', 'https://www.youtube.com/watch?v=9OeznAkyQz4', '2025-05-01 14:06:52', 'approved', NULL),
(4, 'JiaYi', 4, 27, 'Understanding Arrays in Java', 'This lesson covers Java arrays, focusing on how to declare, initialize, and access elements. Learners will explore how arrays store fixed-size sequences of data and how they can be iterated and manipulated using loops and utility methods.\r\n\r\n', 'https://www.youtube.com/watch?v=ei_4Nt7XWOw', '2025-05-01 14:07:44', 'Approved', NULL),
(5, 'JiaYi', 5, 35, 'Writing and Running PHP in VS Code', 'This session guides students through setting up and using Visual Studio Code to write and execute PHP scripts. Learners will become familiar with VS Code extensions, syntax highlighting, and running PHP code in a local environment.', 'https://www.youtube.com/watch?v=Mip_RuSEoso', '2025-05-01 14:08:50', 'pending', NULL),
(6, 'JiaYi', 5, 32, 'Styling Web Pages with CSS in VS Code', 'This lesson focuses on writing CSS (Cascading Style Sheets) using Visual Studio Code. Students will learn how to link CSS to HTML, apply styles, and use developer tools to inspect and tweak design elements efficiently.', 'https://www.youtube.com/watch?v=mL1IcxIUd5Y', '2025-05-01 14:09:47', 'Approved', NULL),
(7, 'JiaYi', 3, 23, 'Data Processing and Exception Handling in Python', 'Students will learn how to process input and handle runtime errors in Python using try-except blocks. This topic emphasizes writing robust programs that can handle unexpected input or system errors gracefully.', 'https://www.youtube.com/watch?v=NIWwJbo-9_8', '2025-05-01 14:10:35', 'pending', NULL),
(8, 'JiaYi', 3, 22, 'Managing Data Collections in Python', 'This topic introduces data collection types in Python such as lists, tuples, sets, and dictionaries. Learners will explore how to store, access, and manipulate groups of related data efficiently using these built-in collection types.', 'https://www.youtube.com/watch?v=gOMW_n2-2Mw', '2025-05-01 14:12:16', 'Approved', NULL),
(9, 'JiaYi', 2, 9, 'Deleting Data in SQL Using DELETE Statement', 'This lesson teaches how to remove records from a database table using the SQL DELETE statement. Students will practice writing DELETE queries with and without WHERE conditions, and understand how to manage data removal safely.', 'https://www.youtube.com/watch?v=s7ehCYyEmVw', '2025-05-01 14:14:49', 'pending', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `interactive_video_view`
--

CREATE TABLE `interactive_video_view` (
  `video_view_id` int(11) NOT NULL,
  `video_id` int(11) NOT NULL,
  `student_username` varchar(50) NOT NULL,
  `viewed_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `interactive_video_view`
--

INSERT INTO `interactive_video_view` (`video_view_id`, `video_id`, `student_username`, `viewed_at`) VALUES
(1, 2, 'KhaiLe', '2025-05-03 19:20:08'),
(2, 4, 'KhaiLe', '2025-05-03 19:20:18'),
(3, 4, 'KhaiLe', '2025-05-04 02:32:46'),
(4, 2, 'KhaiLe', '2025-05-04 02:32:53'),
(5, 2, 'Emjay', '2025-05-04 16:34:27'),
(6, 2, 'Emjay', '2025-05-04 16:36:52'),
(7, 2, 'YuHong', '2025-05-05 14:11:31');

-- --------------------------------------------------------

--
-- Table structure for table `lab`
--

CREATE TABLE `lab` (
  `lab_id` int(11) NOT NULL,
  `teacher_username` varchar(50) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `grading` int(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL,
  `reason` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lab`
--

INSERT INTO `lab` (`lab_id`, `teacher_username`, `subject_id`, `topic_id`, `title`, `description`, `grading`, `created_at`, `status`, `reason`) VALUES
(9, 'JiaYi', 4, 25, 'Lab Activity: Java – Conditional Constructs', 'This lab introduces students to conditional constructs in Java, focusing on how to control the flow of a program using if, if-else, else-if, and switch statements. By the end of this lab, students will be able to write decision-making code to solve simple real-world problems based on user input or variable values.', 80, '2025-05-01 13:10:51', 'approved', NULL),
(10, 'JiaYi', 3, 19, 'Lab Activity: Python – Functions', 'This lab introduces students to functions in Python, which allow for code reuse and modularity. Functions in Python are defined using the def keyword and can accept parameters, return values, and help organize code in a more efficient and readable way. Through this lab, students will learn how to define and call functions, pass arguments, and return values.', 60, '2025-05-01 13:12:10', 'rejected', 'The answer for question 1 is incorrect'),
(11, 'JiaYi', 2, 13, 'Lab Activity: SQL – Modify Function', 'In this lab, students will learn how to modify data in a database using SQL\'s UPDATE statement. The UPDATE statement allows users to change existing records in a table. By the end of this activity, students will understand how to use UPDATE to change individual column values, apply conditions using the WHERE clause, and work with multiple rows of data.', 50, '2025-05-01 13:13:44', 'Approved', NULL),
(12, 'JiaYi', 3, 22, 'Lab Activity: Python – Data Collection', 'In this lab, students will learn about different data collection techniques in Python, focusing on various data structures such as lists, tuples, sets, and dictionaries. Students will learn how to collect, store, and manipulate data in these structures. This lab will cover how to create, access, modify, and iterate over data collections in Python to solve real-world problems.', 90, '2025-05-01 13:16:11', 'Approved', NULL),
(13, 'JiaYi', 4, 30, 'Lab Activity: Java – Java API and Class Libraries', 'This lab introduces students to the Java API (Application Programming Interface) and the use of class libraries that provide pre-built methods for common programming tasks. Students will explore how to use classes from Java’s standard libraries—such as java.util, java.lang, and java.time—to simplify their code, perform operations like data manipulation, random number generation, and date/time handling.', 70, '2025-05-01 13:57:27', 'Approved', NULL),
(14, 'JiaYi', 4, 27, 'Java Lab Activity: Working with Arrays', 'Arrays fjeskxk', 50, '2025-05-03 16:32:24', 'Approved', NULL),
(16, 'JiaYi', 4, 27, 'Java Lab Activity: Working with Arrays', 'By completing this activity, students will develop a solid understanding of how arrays work and how they can be effectively used to store and manage collections of data in Java programming.', 50, '2025-05-04 10:08:14', 'pending', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `lab_attempt`
--

CREATE TABLE `lab_attempt` (
  `lab_attempt_id` int(11) NOT NULL,
  `lab_id` int(11) NOT NULL,
  `student_username` varchar(50) NOT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lab_attempt`
--

INSERT INTO `lab_attempt` (`lab_attempt_id`, `lab_id`, `student_username`, `attempted_at`, `score`) VALUES
(1, 11, 'Emjay', '2025-05-04 16:28:41', 0),
(2, 11, 'YuHong', '2025-05-05 14:10:37', 2);

-- --------------------------------------------------------

--
-- Table structure for table `lab_question`
--

CREATE TABLE `lab_question` (
  `question_id` int(11) NOT NULL,
  `lab_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `correct_answer` text NOT NULL,
  `hint` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lab_question`
--

INSERT INTO `lab_question` (`question_id`, `lab_id`, `question`, `correct_answer`, `hint`) VALUES
(8, 9, 'Question 1: Grade Evaluator\r\nWrite a Java program that takes a student\'s mark (0–100) as input and prints out the grade based on the following conditions:\r\n\r\n90 and above: Grade A\r\n\r\n80–89: Grade B\r\n\r\n70–79: Grade C\r\n\r\n60–69: Grade D\r\n\r\nBelow 60: Grade F', 'Enter your mark: 85  \r\nYour grade is: B', ''),
(9, 9, 'Question 2: Simple Calculator using Switch\r\nWrite a Java program that takes two numbers and a character representing an arithmetic operation (+, -, *, /) and displays the result. Use a switch statement to determine the operation.', 'Enter first number: 10  \r\nEnter second number: 5  \r\nEnter an operator (+, -, *, /): *  \r\nResult: 50', ''),
(10, 10, 'Question 1: Function to Calculate the Area of a Rectangle\r\nWrite a Python function calculate_area(length, width) that takes the length and width of a rectangle as parameters and returns the area of the rectangle. The main part of the program should ask the user to input the length and width, then display the area.', 'Enter the length of the rectangle: 5  \r\nEnter the width of the rectangle: 3  \r\nThe area of the rectangle is: 15', ''),
(11, 10, 'Question 2: Function to Check if a Number is Prime\r\nWrite a Python function is_prime(n) that checks if a number n is prime. The function should return True if the number is prime and False otherwise. The program should ask the user to input a number and then print whether the number is prime.', 'Enter a number: 11  \r\nThe number 11 is prime.', ''),
(12, 11, 'Question 1: Update Student Information\r\nConsider a database table students with the following columns:\r\n\r\nstudent_id (INTEGER)\r\n\r\nstudent_name (VARCHAR)\r\n\r\ngrade (CHAR)\r\n\r\nage (INTEGER)\r\n\r\nWrite an SQL query to update the grade of a student with student_id = 3 to \'A\'.', 'UPDATE students\r\nSET grade = \'A\'\r\nWHERE student_id = 3;', ''),
(13, 11, 'Question 2: Modify Multiple Records\r\nNow, update the students table so that all students who are older than 20 receive a 10% increase in their age (i.e., add 1 to their current age).', 'UPDATE students\r\nSET age = age + 1\r\nWHERE age > 20;', ''),
(14, 12, 'Question 1: Creating and Manipulating Lists\r\nWrite a Python program to create a list containing five different fruits. Then, perform the following operations:\r\n\r\nAdd two more fruits to the list.\r\n\r\nRemove one fruit from the list.\r\n\r\nPrint the updated list.\r\n\r\nSort the list alphabetically and print it again.', 'Original list: [\'Apple\', \'Banana\', \'Cherry\', \'Grapes\', \'Mango\']\r\nUpdated list after adding fruits: [\'Apple\', \'Banana\', \'Cherry\', \'Grapes\', \'Mango\', \'Orange\', \'Peach\']\r\nUpdated list after removal: [\'Apple\', \'Banana\', \'Grapes\', \'Mango\', \'Orange\', \'Peach\']\r\nSorted list: [\'Apple\', \'Banana\', \'Grapes\', \'Mango\', \'Orange\', \'Peach\']', ''),
(15, 12, 'Question 2: Using a Dictionary to Store Student Information\r\nWrite a Python program that stores the name, age, and grade of a student using a dictionary. Then, perform the following tasks:\r\n\r\nPrint the dictionary with all student information.\r\n\r\nUpdate the student\'s grade.\r\n\r\nAdd a new field to store the student\'s city.\r\n\r\nPrint the updated dictionary.', 'Original student information: {\'name\': \'John\', \'age\': 16, \'grade\': \'B\'}\r\nUpdated student information: {\'name\': \'John\', \'age\': 16, \'grade\': \'A\', \'city\': \'New York\'}', ''),
(16, 13, 'Question 1: Using the Random Class from java.util\r\nWrite a Java program that uses the Random class to generate and display five random integers between 1 and 100.', 'Random numbers: 17 92 34 56 73', 'Import java.util.Random and use nextInt(100) + 1.'),
(17, 13, 'Question 2: Working with Dates Using java.time.LocalDate\r\nWrite a Java program that does the following:\r\n\r\nDisplays the current date.\r\n\r\nAdds 10 days to the current date and displays the new date.\r\n\r\nDisplays the day of the week for the new date.', 'Current date: 2025-05-01  \r\nDate after 10 days: 2025-05-11  \r\nDay of the week: Sunday', 'Import java.time.LocalDate and use plusDays() and getDayOfWeek().'),
(18, 14, 'Declare an array of 5 integers.\r\n\r\nAssign values to each element.\r\n\r\nPrint all the values using a loop.\r\n\r\njava\r\nCopy\r\nEdit\r\n', 'int[] numbers = new int[5];\r\nnumbers[0] = 10;\r\nnumbers[1] = 20;\r\n// ... initialize others\r\nfor (int i = 0; i < numbers.length; i++) {\r\n    System.out.println(numbers[i]);\r\n}', '');

-- --------------------------------------------------------

--
-- Table structure for table `lesson_slide`
--

CREATE TABLE `lesson_slide` (
  `slide_id` int(11) NOT NULL,
  `teacher_username` varchar(50) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_data` longblob NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL,
  `reason` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lesson_slide_view`
--

CREATE TABLE `lesson_slide_view` (
  `slide_view_id` int(11) NOT NULL,
  `slide_id` int(11) NOT NULL,
  `student_username` varchar(50) NOT NULL,
  `viewed_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `quiz_id` int(11) NOT NULL,
  `teacher_username` varchar(50) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `grading` int(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL,
  `reason` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`quiz_id`, `teacher_username`, `subject_id`, `topic_id`, `title`, `description`, `grading`, `created_at`, `status`, `reason`) VALUES
(18, 'JiaYi', 1, 2, 'Mastering Control Structures in Snap!', 'This quiz will assess your understanding of control structures in Snap!, including conditionals like if and if-else, loops such as repeat, forever, and repeat until, and how they control the flow of a Snap! program.', 60, '2025-05-01 07:31:49', 'Approved', NULL),
(19, 'JiaYi', 3, 21, 'Understanding Lists in Python', 'This quiz is designed to assess your understanding of Python lists — one of the most important and versatile data structures in Python. You will explore concepts such as list creation, indexing, slicing, list methods, and common list operations.', 50, '2025-05-01 07:37:18', 'Approved', NULL),
(20, 'JiaYi', 2, 6, 'Mastering SQL CREATE Statements', 'This quiz is designed to evaluate your knowledge of the SQL CREATE function, including how to define new databases, tables, and indexes. You will be tested on the syntax and purpose of different CREATE statements commonly used in database development and management.', 60, '2025-05-01 09:10:50', 'Approved', NULL),
(21, 'JiaYi', 5, 31, 'Getting Started with HTML in VS Code', 'This quiz evaluates your understanding of writing HTML code using Visual Studio Code. It covers basic HTML structure, key tags, common shortcuts in VS Code, and tips for improving productivity when developing web pages using HTML in this editor.\r\n\r\n', 60, '2025-05-01 09:18:32', 'approved', NULL),
(22, 'JiaYi', 4, 28, 'Working with Java Input and Output I/O Streams', 'This quiz assesses your understanding of Java\'s input and output stream mechanisms. It covers the usage of InputStream, OutputStream, Reader, Writer, and common classes like FileInputStream, BufferedReader, and PrintWriter used for handling data from various sources such as files, consoles, and byte arrays.\r\n\r\n', 70, '2025-05-01 09:26:13', 'approved', NULL),
(24, 'JiaYi', 2, 7, 'Introduction to SQL: Understanding the INSERT Function', 'This topic introduces students to Structured Query Language (SQL) with a focus on the INSERT statement, which is used to add new records to a database table. Students will learn the syntax of the INSERT function, understand how to insert single and multiple rows, and apply it in real database scenarios.', 60, '2025-05-01 17:03:15', 'pending', NULL),
(25, 'JiaYi', 2, 12, 'Introduction to SQL: Understanding the INSERT Function', 'grjeskd', 50, '2025-05-04 09:57:43', 'pending', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_attempt`
--

CREATE TABLE `quiz_attempt` (
  `quiz_attempt_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `student_username` varchar(50) NOT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_attempt`
--

INSERT INTO `quiz_attempt` (`quiz_attempt_id`, `quiz_id`, `student_username`, `attempted_at`, `score`) VALUES
(6, 20, 'YuHong', '2025-05-05 14:09:33', 6);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_question`
--

CREATE TABLE `quiz_question` (
  `question_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `option_a` text NOT NULL,
  `option_b` text NOT NULL,
  `option_c` text NOT NULL,
  `option_d` text NOT NULL,
  `correct_option` enum('A','B','C','D') NOT NULL,
  `hint` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_question`
--

INSERT INTO `quiz_question` (`question_id`, `quiz_id`, `question`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `hint`) VALUES
(21, 18, 'What is the purpose of a control structure in Snap!?', 'To store data', 'To control the sprite’s size', 'To manage the flow of the program', 'To change the background', 'C', ''),
(22, 18, 'Which Snap! block is used to repeat a set of commands a fixed number of times?', 'forever', 'repeat until < >', 'if < > then', 'repeat [10]', 'D', ''),
(23, 18, 'What is the difference between if and if-else blocks?', 'if checks condition but does nothing; if-else repeats a block', 'if checks condition and runs one block if true; if-else runs one block if true and another if false', 'if always runs; if-else never runs', 'There is no difference', 'B', ''),
(24, 18, 'What does the forever block do in Snap!?', 'Repeats the blocks inside it a set number of times', 'Repeats blocks forever until the program is closed or stopped', 'Repeats blocks based on user input', 'Runs once and then stops', 'B', ''),
(25, 18, 'Which control structure is best to use when you want to stop repeating after a certain condition is true?', 'repeat', 'forever', 'repeat until < >', 'if-else', 'C', ''),
(26, 18, 'What will happen if you use a repeat until <mouse down?> block?', 'The loop runs forever', 'The loop runs until the mouse is clicked', 'The program will crash', 'It repeats when the mouse is not clicked', 'B', ''),
(27, 18, 'Which of the following is not a control block in Snap!?', 'if < > then', 'repeat [ ]', 'change [score v] by [1]', 'repeat until < >', 'C', ''),
(28, 18, 'How can you stop a forever loop in Snap!?', 'Use a stop [all] block inside the loop', 'It stops automatically after 10 iterations', 'Use wait block', 'You cannot stop it once it starts', 'A', ''),
(29, 19, 'Which of the following creates a list in Python?', 'list = 1, 2, 3', 'list = [1, 2, 3]', 'list = (1, 2, 3)', 'list = {1, 2, 3}', 'B', ''),
(30, 19, 'What is the index of the first element in a Python list?', '0', '1', '-1', 'It depends on the list', 'A', ''),
(31, 19, 'What will be the output of my_list = [10, 20, 30]; print(my_list[1])?', '10', '20', '30', '1', 'B', ''),
(32, 19, 'How can you add an item to the end of a list my_list?', 'my_list.add(4)', 'my_list.push(4)', 'my_list.append(4)', 'my_list.insert_end(4)', 'C', ''),
(33, 19, 'What does the len() function return when used on a list?', 'The last element', 'The number of items in the list', 'The index of the last element', 'The type of the list', 'B', ''),
(34, 19, 'What is the result of my_list = [1, 2, 3]; print(my_list[-1])?', '1', '-1', '2', '3', 'D', ''),
(35, 19, 'Which method removes all items from a list?', 'delete()', 'clear()', 'remove()', 'popall()', 'B', ''),
(36, 20, 'What is the purpose of the CREATE statement in SQL?', 'To retrieve data from a table', 'To delete a table from a database', 'To create a new database object', 'To update values in a table', 'C', ''),
(37, 20, 'Which of the following is the correct syntax to create a new database in SQL?', 'MAKE DATABASE school;', 'CREATE school DATABASE;', 'CREATE DATABASE school;', 'DATABASE CREATE school;', 'C', ''),
(38, 20, 'CREATE TABLE students (id INT, name VARCHAR(50));', 'Creates a new database called \"students\"  ', 'Adds new records to the \"students\" table  ', 'Creates a new table called \"students\" with two columns  ', 'Updates the table \"students\"', 'C', ''),
(39, 20, 'Which of the following data types is used to store a large amount of text in SQL?**  ', '`INT` ', '`VARCHAR(255)`  ', '`TEXT`  ', '`CHAR(10)`  ', 'C', ''),
(40, 20, 'What does the `PRIMARY KEY` keyword do in a `CREATE TABLE` statement?** ', 'Prevents duplicate values in a column  ', 'Links two tables together  ', 'Creates a backup of the table  ', 'Sorts the data in ascending order  ', 'A', ''),
(41, 20, 'Which of the following commands creates a new index on the `last_name` column in the `employees` table?**  ', '`CREATE INDEX idx_lastname FROM employees(last_name);', '`MAKE INDEX ON employees(last_name);`', '`CREATE INDEX idx_lastname ON employees(last_name);`  ', '`INDEX employees.last_name = idx_lastname;`  ', 'C', ''),
(42, 20, 'What does this SQL statement do?  \r\n```sql\r\nCREATE TABLE orders (\r\n  order_id INT PRIMARY KEY,\r\n  order_date DATE,\r\n  amount DECIMAL(10,2)\r\n);\r\n```**  ', 'Creates a table called `orders` with three columns, and `order_id` is the primary key  ', ' Adds an order to the `orders` table  ', 'Updates an existing order  ', 'Deletes the `orders` table  ', 'A', ''),
(43, 20, 'Which of the following is TRUE about using `CREATE TABLE` with constraints?**  ', 'Constraints must be added only after the table is created', 'Constraints like `NOT NULL` or `UNIQUE` can be defined inside the `CREATE TABLE` statement  ', 'Constraints are optional and never needed  ', 'Constraints can only be added by the database administrator  ', 'B', ''),
(44, 21, 'What does the <!DOCTYPE html> declaration do in an HTML document?', 'Adds a CSS stylesheet', 'Declares the document type and HTML version', 'Starts a JavaScript block', 'Creates a table', 'B', ''),
(45, 21, 'What is the correct structure of a basic HTML document?', 'html > body > head', 'body > html > head', '<!DOCTYPE html> <html> <head> <body>', 'html > head > body > doctype', 'C', ''),
(46, 21, 'In VS Code, what shortcut can you use to quickly generate the basic HTML structure?', 'Ctrl + B', ' Type html5 and press Enter', 'Type <!DOCTYPE> and press Esc', 'Type html>head+body and press Backspace', 'B', 'This works when Emmet is enabled — usually by default.)'),
(47, 21, 'What HTML tag is used to create a hyperlink?', '<p>', '<link>', '<a>', '<href>', 'C', ''),
(48, 21, 'In VS Code, what feature highlights matching tags and shows indentation levels?', ' IntelliSense', 'Git Integration', 'Bracket Pair Colorization', 'Debug Console', 'C', ''),
(49, 21, 'Which tag is used to display a heading in HTML?', '<head>', '<title>', '<h1> to <h6>', '<heading>', 'C', ''),
(50, 21, 'How do you comment out a block of HTML code in VS Code?', '<!-- This is a comment -->', '// This is a comment', '/* This is a comment */', '# This is a comment', 'A', ''),
(51, 21, 'What VS Code extension helps with live preview of HTML files in a browser?\r\n\r\n', 'Python', 'GitLens', ' Live Server', 'IntelliCode', 'C', ''),
(52, 22, 'Which Java package contains the classes for input and output operations?', 'java.io', 'java.util', 'java.stream', 'java.inputoutput', 'A', ''),
(53, 22, 'What is the main difference between InputStream and Reader?', 'InputStream reads characters, Reader reads bytes', 'InputStream writes characters, Reader writes bytes', 'InputStream reads bytes, Reader reads characters', 'No difference, they are aliases', 'C', ''),
(54, 22, 'Which class is used to read data from a file using a byte stream?', 'FileWriter', 'BufferedReader', 'FileInputStream', 'Scanner', 'C', ''),
(55, 22, 'Which of the following is used to write character data to a file in Java?', 'InputStream', 'FileOutputStream', 'FileWriter', 'ObjectInputStream', 'C', ''),
(56, 22, 'What does the read() method of InputStream return when the end of the stream is reached?', '-1', '0', 'null', 'Exception is thrown', 'A', ''),
(57, 22, 'Which stream should you use for efficient reading of characters from a file?\r\n\r\n', 'BufferedInputStream', 'BufferedReader', 'FileReader only', 'PrintStream', 'B', ''),
(58, 22, 'What is the correct way to close an input stream in Java?', 'stream.stop();', 'stream.end();', 'stream.close();', 'stream.shutdown();', 'C', ''),
(59, 22, 'Which class allows you to format output easily in Java (e.g., printing to console or file)?', 'FormatterStream', 'PrintWriter', 'InputStreamReader', 'ObjectOutputStream', 'B', ''),
(60, 24, 'Which SQL statement correctly inserts a new row into the employees table with the name \'John\', age 30, and department \'HR\'?', 'INSERT INTO employees VALUES (\'John\', 30, \'HR\');', 'ADD INTO employees (\'John\', 30, \'HR\');', 'INSERT employees INTO VALUES (\'John\', 30, \'HR\');', 'INSERT INTO employees SET name=\'John\', age=30, department=\'HR\';', 'A', ''),
(61, 24, 'Which SQL statement correctly inserts a new row into the employees table with the name \'John\', age 30, and department \'HR\'?', 'INSERT INTO employees VALUES (\'John\', 30, \'HR\');', 'ADD INTO employees (\'John\', 30, \'HR\');', 'INSERT employees INTO VALUES (\'John\', 30, \'HR\');', 'INSERT INTO employees SET name=\'John\', age=30, department=\'HR\';', 'A', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_level`
--

CREATE TABLE `student_level` (
  `preference_id` int(11) NOT NULL,
  `student_username` varchar(50) NOT NULL,
  `student_level` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_level`
--

INSERT INTO `student_level` (`preference_id`, `student_username`, `student_level`, `created_at`) VALUES
(43, 'KhaiLe', 'Beginner', '2025-05-01 06:11:02'),
(45, 'YuHong', 'Beginner', '2025-05-04 16:18:42'),
(46, 'YY', 'Beginner', '2025-05-04 16:20:45'),
(47, 'Emjay', 'Pro', '2025-05-04 16:21:31');

-- --------------------------------------------------------

--
-- Table structure for table `student_material`
--

CREATE TABLE `student_material` (
  `student_material_id` int(11) NOT NULL,
  `student_username` varchar(50) NOT NULL,
  `material_preferred` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_material`
--

INSERT INTO `student_material` (`student_material_id`, `student_username`, `material_preferred`, `created_at`) VALUES
(4, 'KhaiLe', 'Lesson Slides', '2025-05-01 06:11:17'),
(7, 'YuHong', 'Interactive Video', '2025-05-04 16:18:59'),
(8, 'YY', 'Interactive Video', '2025-05-04 16:20:55'),
(9, 'Emjay', 'Interactive Video', '2025-05-04 16:21:36');

-- --------------------------------------------------------

--
-- Table structure for table `student_preference`
--

CREATE TABLE `student_preference` (
  `student_preference_id` int(11) NOT NULL,
  `student_username` varchar(50) NOT NULL,
  `subject_interested` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_preference`
--

INSERT INTO `student_preference` (`student_preference_id`, `student_username`, `subject_interested`, `created_at`) VALUES
(49, 'KhaiLe', 'Snap!', '2025-05-01 06:11:09'),
(52, 'YuHong', 'SQL', '2025-05-04 16:18:55'),
(53, 'YY', 'SQL', '2025-05-04 16:20:48'),
(54, 'YY', 'SQL', '2025-05-04 16:20:51'),
(55, 'Emjay', 'SQL', '2025-05-04 16:21:33');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `name`) VALUES
(1, 'Snap!'),
(2, 'SQL'),
(3, 'Python'),
(4, 'Java'),
(5, 'VS Code');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `reply` text DEFAULT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`ticket_id`, `username`, `description`, `text`, `reply`, `status`) VALUES
(7, 'KhaiLe', 'Slow Page Loading', 'Pages may take a long time to load, especially on the dashboard or report sections with many records. This could be due to poor optimization of data retrieval or large uncompressed images.', 'This problem already solved. Please reload your pages again.', 'Resolved'),
(8, 'KhaiLe', 'Missing Input Validation', 'Some forms (e.g., quiz or lab creation) might allow submission with incomplete fields or incorrect formats, which can result in incomplete or invalid entries being stored in the system.', 'This problem already solved. ', 'Resolved'),
(11, 'YuHong', 'No Confirmation for Deletion', 'If a user accidentally deletes a quiz or lab without a confirmation prompt, it could lead to permanent loss of content without warning.', NULL, 'pending'),
(12, 'YuHong', 'Poor Accessibility Features', 'The platform may not support screen readers or keyboard navigation, making it difficult for users with disabilities to use the system effectively.', NULL, 'pending'),
(13, 'YuHong', 'Password Change Process Not Intuitive', 'Users may get confused during the password change process if there\'s no clear guidance (e.g., password requirements) or if error messages aren’t contextually placed near the fields.', NULL, 'pending'),
(14, 'YY', 'Limited Filtering Options in Reports', 'In the \"My Created Content Report\" section, filtering by only one criterion (e.g., content type) may not be enough for users with a large number of entries, making navigation inefficient.', NULL, 'pending'),
(15, 'Emjay', 'Slow Page Loading', 'Pages may take a long time to load, especially on the dashboard or report sections with many records. This could be due to poor optimization of data retrieval or large uncompressed images.', NULL, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `topic`
--

CREATE TABLE `topic` (
  `topic_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `topic`
--

INSERT INTO `topic` (`topic_id`, `subject_id`, `title`) VALUES
(1, 1, 'Data and Variable'),
(2, 1, 'Control Structure'),
(3, 1, 'List'),
(4, 1, 'Procedure and Functions'),
(5, 1, 'Object-Oriented Programming'),
(6, 2, 'CREATE Function'),
(7, 2, 'INSERT Function'),
(8, 2, 'UPDATE Function'),
(9, 2, 'DELETE Function'),
(10, 2, 'SELECT Function'),
(11, 2, 'Operators'),
(12, 2, 'ALTER Function'),
(13, 2, 'MODIFY Function'),
(14, 2, 'DROP Function'),
(15, 2, 'GROUP BY and ORDER BY Function'),
(16, 2, 'JOIN Function'),
(17, 3, 'Variable, Expression, and Statement'),
(18, 3, 'Control Structure'),
(19, 3, 'Function'),
(20, 3, 'Strings'),
(21, 3, 'List'),
(22, 3, 'Data Collection'),
(23, 3, 'File and Exception Handling'),
(24, 4, 'Data Types, Operators, and Expressions'),
(25, 4, 'Conditional Constructs'),
(26, 4, 'Java Iterative Construct'),
(27, 4, 'Arrays'),
(28, 4, 'Input and Output Streams'),
(29, 4, 'Exceptions'),
(30, 4, 'Java API and Class Libraries'),
(31, 5, 'HTML Code'),
(32, 5, 'CSS Code'),
(33, 5, 'JavaScript Code'),
(34, 5, 'Responsive Web Design'),
(35, 5, 'PHP Code'),
(36, 5, 'PHP Functions'),
(37, 5, 'PHP Cookies and PHP Sessions'),
(38, 5, 'PHP Error Handling');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `name`, `password`, `email`, `role`, `created_at`) VALUES
('Emjay', 'Loo Mun Jeng', '123', 'emjay@gmail.com', 'student', '2025-05-01 07:14:53'),
('Jaywen', 'Lim Jaywen', '5353', 'linjaywen12@gmail.com', 'admin', '2025-05-01 06:08:42'),
('JiaYi', 'CHOONG JIA YI', '333', 'choongjiayi@gmail.com', 'teacher', '2025-05-01 06:06:34'),
('KhaiLe', 'Tan Khai Le', '3333', 'khailele221@gmail.com', 'student', '2025-05-01 06:10:41'),
('Tzy', 'Tan Zhi Ying', '333', 'zhiying0831@gmail.com', 'teacher', '2025-05-01 07:12:57'),
('WeiYang', 'Low Wei Yang', '111', 'weiyang@gmail.com', 'student', '2025-05-01 07:10:34'),
('YuHong', 'Chen Yu Hong', '888', 'yuhong111@gmail.com', 'student', '2025-05-01 07:10:09'),
('YY', 'Loy Yong Yeow', '222', 'yy@gmail.com', 'student', '2025-05-01 07:12:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `interactive_video`
--
ALTER TABLE `interactive_video`
  ADD PRIMARY KEY (`video_id`),
  ADD KEY `teacher_username` (`teacher_username`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `topic_id` (`topic_id`);

--
-- Indexes for table `interactive_video_view`
--
ALTER TABLE `interactive_video_view`
  ADD PRIMARY KEY (`video_view_id`),
  ADD KEY `video_id` (`video_id`),
  ADD KEY `student_username` (`student_username`);

--
-- Indexes for table `lab`
--
ALTER TABLE `lab`
  ADD PRIMARY KEY (`lab_id`),
  ADD KEY `teacher_username` (`teacher_username`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `topic_id` (`topic_id`);

--
-- Indexes for table `lab_attempt`
--
ALTER TABLE `lab_attempt`
  ADD PRIMARY KEY (`lab_attempt_id`),
  ADD KEY `lab_id` (`lab_id`),
  ADD KEY `student_username` (`student_username`);

--
-- Indexes for table `lab_question`
--
ALTER TABLE `lab_question`
  ADD PRIMARY KEY (`question_id`),
  ADD KEY `lab_id` (`lab_id`);

--
-- Indexes for table `lesson_slide`
--
ALTER TABLE `lesson_slide`
  ADD PRIMARY KEY (`slide_id`),
  ADD KEY `teacher_username` (`teacher_username`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `topic_id` (`topic_id`);

--
-- Indexes for table `lesson_slide_view`
--
ALTER TABLE `lesson_slide_view`
  ADD PRIMARY KEY (`slide_view_id`),
  ADD KEY `slide_id` (`slide_id`),
  ADD KEY `student_username` (`student_username`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`quiz_id`),
  ADD KEY `teacher_username` (`teacher_username`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `topic_id` (`topic_id`);

--
-- Indexes for table `quiz_attempt`
--
ALTER TABLE `quiz_attempt`
  ADD PRIMARY KEY (`quiz_attempt_id`),
  ADD KEY `quiz_id` (`quiz_id`),
  ADD KEY `student_username` (`student_username`);

--
-- Indexes for table `quiz_question`
--
ALTER TABLE `quiz_question`
  ADD PRIMARY KEY (`question_id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Indexes for table `student_level`
--
ALTER TABLE `student_level`
  ADD PRIMARY KEY (`preference_id`),
  ADD UNIQUE KEY `student_username` (`student_username`) USING BTREE;

--
-- Indexes for table `student_material`
--
ALTER TABLE `student_material`
  ADD PRIMARY KEY (`student_material_id`),
  ADD KEY `student_username` (`student_username`);

--
-- Indexes for table `student_preference`
--
ALTER TABLE `student_preference`
  ADD PRIMARY KEY (`student_preference_id`),
  ADD KEY `student_username` (`student_username`) USING BTREE;

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `topic`
--
ALTER TABLE `topic`
  ADD PRIMARY KEY (`topic_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `interactive_video`
--
ALTER TABLE `interactive_video`
  MODIFY `video_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `interactive_video_view`
--
ALTER TABLE `interactive_video_view`
  MODIFY `video_view_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lab`
--
ALTER TABLE `lab`
  MODIFY `lab_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `lab_attempt`
--
ALTER TABLE `lab_attempt`
  MODIFY `lab_attempt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lab_question`
--
ALTER TABLE `lab_question`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `lesson_slide`
--
ALTER TABLE `lesson_slide`
  MODIFY `slide_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `lesson_slide_view`
--
ALTER TABLE `lesson_slide_view`
  MODIFY `slide_view_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `quiz_attempt`
--
ALTER TABLE `quiz_attempt`
  MODIFY `quiz_attempt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `quiz_question`
--
ALTER TABLE `quiz_question`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `student_level`
--
ALTER TABLE `student_level`
  MODIFY `preference_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `student_material`
--
ALTER TABLE `student_material`
  MODIFY `student_material_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `student_preference`
--
ALTER TABLE `student_preference`
  MODIFY `student_preference_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `topic`
--
ALTER TABLE `topic`
  MODIFY `topic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `interactive_video`
--
ALTER TABLE `interactive_video`
  ADD CONSTRAINT `interactive_video_ibfk_1` FOREIGN KEY (`teacher_username`) REFERENCES `users` (`username`) ON DELETE CASCADE,
  ADD CONSTRAINT `interactive_video_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `interactive_video_ibfk_3` FOREIGN KEY (`topic_id`) REFERENCES `topic` (`topic_id`) ON DELETE CASCADE;

--
-- Constraints for table `interactive_video_view`
--
ALTER TABLE `interactive_video_view`
  ADD CONSTRAINT `student_username` FOREIGN KEY (`student_username`) REFERENCES `users` (`username`),
  ADD CONSTRAINT `video_id` FOREIGN KEY (`video_id`) REFERENCES `interactive_video` (`video_id`);

--
-- Constraints for table `lab`
--
ALTER TABLE `lab`
  ADD CONSTRAINT `lab_ibfk_1` FOREIGN KEY (`teacher_username`) REFERENCES `users` (`username`) ON DELETE CASCADE,
  ADD CONSTRAINT `lab_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lab_ibfk_3` FOREIGN KEY (`topic_id`) REFERENCES `topic` (`topic_id`) ON DELETE CASCADE;

--
-- Constraints for table `lab_attempt`
--
ALTER TABLE `lab_attempt`
  ADD CONSTRAINT `lab_attempt_ibfk_1` FOREIGN KEY (`lab_id`) REFERENCES `lab` (`lab_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lab_attempt_ibfk_2` FOREIGN KEY (`student_username`) REFERENCES `users` (`username`) ON DELETE CASCADE;

--
-- Constraints for table `lab_question`
--
ALTER TABLE `lab_question`
  ADD CONSTRAINT `lab_question_ibfk_1` FOREIGN KEY (`lab_id`) REFERENCES `lab` (`lab_id`) ON DELETE CASCADE;

--
-- Constraints for table `lesson_slide`
--
ALTER TABLE `lesson_slide`
  ADD CONSTRAINT `lesson_slide_ibfk_1` FOREIGN KEY (`teacher_username`) REFERENCES `users` (`username`) ON DELETE CASCADE,
  ADD CONSTRAINT `lesson_slide_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lesson_slide_ibfk_3` FOREIGN KEY (`topic_id`) REFERENCES `topic` (`topic_id`) ON DELETE CASCADE;

--
-- Constraints for table `lesson_slide_view`
--
ALTER TABLE `lesson_slide_view`
  ADD CONSTRAINT `lesson_slide_view_ibfk_1` FOREIGN KEY (`student_username`) REFERENCES `users` (`username`) ON DELETE CASCADE;

--
-- Constraints for table `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`teacher_username`) REFERENCES `users` (`username`) ON DELETE CASCADE,
  ADD CONSTRAINT `quiz_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `quiz_ibfk_3` FOREIGN KEY (`topic_id`) REFERENCES `topic` (`topic_id`) ON DELETE CASCADE;

--
-- Constraints for table `quiz_attempt`
--
ALTER TABLE `quiz_attempt`
  ADD CONSTRAINT `quiz_attempt_ibfk_1` FOREIGN KEY (`student_username`) REFERENCES `users` (`username`) ON DELETE CASCADE;

--
-- Constraints for table `quiz_question`
--
ALTER TABLE `quiz_question`
  ADD CONSTRAINT `quiz_question_ibfk_1` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`quiz_id`) ON DELETE CASCADE;

--
-- Constraints for table `student_level`
--
ALTER TABLE `student_level`
  ADD CONSTRAINT `student_level_ibfk_1` FOREIGN KEY (`student_username`) REFERENCES `users` (`username`) ON DELETE CASCADE;

--
-- Constraints for table `student_material`
--
ALTER TABLE `student_material`
  ADD CONSTRAINT `student_material_ibfk_1` FOREIGN KEY (`student_username`) REFERENCES `users` (`username`) ON DELETE CASCADE;

--
-- Constraints for table `student_preference`
--
ALTER TABLE `student_preference`
  ADD CONSTRAINT `student_preference_ibfk_1` FOREIGN KEY (`student_username`) REFERENCES `users` (`username`) ON DELETE CASCADE;

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`username`) REFERENCES `users` (`username`) ON DELETE CASCADE;

--
-- Constraints for table `topic`
--
ALTER TABLE `topic`
  ADD CONSTRAINT `topic_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
