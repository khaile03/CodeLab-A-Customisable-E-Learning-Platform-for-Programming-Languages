<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "codelab";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}