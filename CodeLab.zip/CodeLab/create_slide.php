<?php
session_start();
include("config/config.php");

$teacherUsername = $_SESSION['username'];

// Handle AJAX topic request
if (isset($_POST['subject_id'])) {
    $subject_id = $_POST['subject_id'];
    $stmt = $conn->prepare("SELECT topic_id, title FROM topic WHERE subject_id = ?");
    $stmt->bind_param("i", $subject_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $topics = array();
    while ($row = $result->fetch_assoc()) {
        $topics[] = $row;
    }
    echo json_encode($topics);
    exit;
}

// Get subjects
$subjects = $conn->query("SELECT subject_id, name FROM subject");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Slide</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            font-size: 20px;
        }

        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            background: white;
            padding: 50px;
            border-radius: 12px;
            box-shadow: 0px 3px 8px rgba(0,0,0,0.1);
        }

        h2 { text-align: center; color: #1565c0; font-size: 32px; }

        label {
            display: block;
            margin-top: 25px;
            font-weight: bold;
            font-size: 22px;
        }

        input[type="text"], select, textarea, input[type="file"] {
            width: 100%;
            padding: 16px;
            margin-top: 10px;
            font-size: 20px;
            border-radius: 8px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        input::placeholder, textarea::placeholder {
            color: #aaa;
            font-size: 18px;
        }

        .button-group {
            margin-top: 35px;
            text-align: center;
        }

        .button-group button {
            padding: 16px 30px;
            font-size: 20px;
            border: none;
            border-radius: 10px;
            margin: 0 20px;
            cursor: pointer;
        }

        .create-btn { background-color: #27ae60; color: white; }
        .cancel-btn { background-color: #e74c3c; color: white; }

        .popup {
            display: none;
            position: fixed;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -30%);
            background: white;
            border: 2px solid #1565c0;
            padding: 20px;
            z-index: 99;
            box-shadow: 0px 5px 15px rgba(0,0,0,0.3);
            text-align: center;
        }

        .popup .close {
            float: right;
            font-size: 22px;
            cursor: pointer;
            color: red;
        }

        .popup button {
            margin-top: 15px;
            padding: 10px 20px;
            background-color: #1565c0;
            color: white;
            border: none;
            border-radius: 5px;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }


    </style>
</head>
<body>

<div class="header">CodeLab</div>

<div class="container">
    <h2>Upload a New Slide</h2>
    <form action="create_slide_action.php" method="POST" enctype="multipart/form-data">
        <label for="slide_title">Slide Title</label>
        <input type="text" name="slide_title" placeholder="e.g. Introduction to Variables" required>

        <label for="subject">Subject</label>
        <select name="subject" id="subject" required>
            <option value="">-- Select Subject --</option>
            <?php while ($row = $subjects->fetch_assoc()) {
                echo "<option value='{$row['subject_id']}'>{$row['name']}</option>";
            } ?>
        </select>

        <label for="topic">Topic</label>
        <select name="topic" id="topic" required>
            <option value="">-- Select Topic --</option>
        </select>

        <label for="description">Description</label>
        <textarea name="description" rows="5" placeholder="Write a short description of the slide..." required></textarea>

        <label for="file">Upload Slide File</label>
        <input type="file" id="slideFile" name="file" accept=".pdf" required>
        <p style="color: #e74c3c; font-size: 16px;">Only PDF files below within 1000KB are allowed.</p>


        <div class="button-group">
            <button type="submit" name="create_slide" class="create-btn" onclick="return confirm('Are you sure you want to publish this slide?');">Upload</button>
            <button type="button" class="cancel-btn" onclick="document.getElementById('cancelPopup').style.display='block'">Cancel</button>
        </div>
    </form>
</div>

<div class="popup" id="cancelPopup">
    <span class="close" onclick="document.getElementById('cancelPopup').style.display='none'">&times;</span>
    <p>Do you want to cancel and stop uploading the slide?</p>
    <button onclick="window.location.href='dashboard.php'">OK</button>
</div>

<div class="popup" id="invalidFilePopup">
    <span class="close" onclick="document.getElementById('invalidFilePopup').style.display='none'">&times;</span>
    <p>Invalid file type. Only PDF files are accepted.</p>
    <button onclick="document.getElementById('invalidFilePopup').style.display='none'">OK</button>
</div>


<div class="footer" id="footer">
    &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
</div>

<script>
    document.getElementById('subject').addEventListener('change', function() {
        var subject_id = this.value;
        var topicSelect = document.getElementById('topic');
        topicSelect.innerHTML = '<option value="">Loading...</option>';

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'create_slide.php', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.onload = function () {
            var data = JSON.parse(this.responseText);
            topicSelect.innerHTML = '<option value="">-- Select Topic --</option>';
            data.forEach(function(item) {
                var opt = document.createElement("option");
                opt.value = item.topic_id;
                opt.innerHTML = item.title;
                topicSelect.appendChild(opt);
            });
        };
        xhr.send('subject_id=' + subject_id);
    });

    document.getElementById("slideFile").addEventListener("change", function () {
        var fileInput = this;
        var filePath = fileInput.value;
        var allowedExtension = /\.pdf$/i;

        if (!allowedExtension.exec(filePath)) {
            fileInput.value = "";
            document.getElementById("invalidFilePopup").style.display = "block";
        }
    });

</script>

</body>
</html>




