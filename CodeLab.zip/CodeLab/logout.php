<?php
// logout.php

session_start();

// Check if user confirmed logout via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_logout'])) {
    session_destroy();
    header("Location: index.html");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Logout</title>
    <style>
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0,0,0,0.7);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-content {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 500px;
            width: 90%;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        .modal-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        .modal-button {
            padding: 10px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        .modal-button.yes {
            background-color: #1565c0;
            color: white;
        }
        .modal-button.no {
            background-color: #f44336;
            color: white;
        }
        .modal-button:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="modal-overlay">
        <div class="modal-content">
            <h2>Are you sure you want to log out?</h2>
            <div class="modal-buttons">
                <form method="POST" action="logout.php">
                    <button type="submit" name="confirm_logout" class="modal-button yes">Yes, Logout</button>
                    <button type="button" onclick="window.history.back()" class="modal-button no">No, Go Back</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>