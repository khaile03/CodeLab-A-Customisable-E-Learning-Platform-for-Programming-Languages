<?php
include 'config/config.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_GET['id'])) {
    echo "Quiz ID is missing.";
    exit;
}

$quizId = $_GET['id'];

// Fetch quiz info
$sql = "SELECT * FROM quiz WHERE quiz_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $quizId);
$stmt->execute();
$quizResult = $stmt->get_result();

if ($quizResult->num_rows === 0) {
    echo "Quiz not found.";
    exit;
}
$quiz = $quizResult->fetch_assoc();

// Fetch quiz questions
$questionSql = "SELECT * FROM quiz_question WHERE quiz_id = ?";
$qstmt = $conn->prepare($questionSql);
$qstmt->bind_param("i", $quizId);
$qstmt->execute();
$questionResult = $qstmt->get_result();
$questions = [];
while ($row = $questionResult->fetch_assoc()) {
    $questions[] = $row;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $grading = $_POST['grading'];

    $updateQuiz = "UPDATE quiz SET title = ?, description = ?, grading = ? WHERE quiz_id = ?";
    $quizStmt = $conn->prepare($updateQuiz);
    $quizStmt->bind_param("ssii", $title, $description, $grading, $quizId);
    $quizStmt->execute();

    if (isset($_POST['question_id'])) {
        for ($i = 0; $i < count($_POST['question_id']); $i++) {
            $qid = $_POST['question_id'][$i];
            $question = $_POST['question'][$i];
            $optionA = $_POST['option_a'][$i];
            $optionB = $_POST['option_b'][$i];
            $optionC = $_POST['option_c'][$i];
            $optionD = $_POST['option_d'][$i];
            $correct = $_POST['correct_option'][$i];
            $hint = $_POST['hint'][$i];

            $updateQ = "UPDATE quiz_question 
                        SET question = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, correct_option = ?, hint = ? 
                        WHERE question_id = ?";
            $qStmt = $conn->prepare($updateQ);
            $qStmt->bind_param("sssssssi", $question, $optionA, $optionB, $optionC, $optionD, $correct, $hint, $qid);
            $qStmt->execute();
        }
    }

    echo "<script>alert('Quiz and questions updated successfully.'); window.location.href='view_quiz.php?id=$quizId';</script>";
    exit;
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Edit Quiz</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

            .header-left .logo {
                font-size: 40px;
                font-weight: bold;
                text-decoration: none;
                color: white;
            }

            .nav {
                display: flex;
                gap: 5px;
                align-items: center;
                justify-content: flex-start; /* Align breadcrumbs to the left */
                margin-right: auto; /* Ensures it sticks to the left */
                white-space: nowrap;     
                padding: 8px 12px;      
                display: inline-block; 
            }

            .nav a {
                color: white;
                text-decoration: none;
                font-size: 18px;
                font-weight: bold;
                padding: 8px 12px;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }

            .nav a:hover {
                background-color: #0d47a1;
            }
        
        .nav-buttons {
            display: flex;
            gap: 8px; /* Small space between buttons */
        }

        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a[href="create_quiz.php"] {
            background-color: #42a5f5; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a[href="create_lab.php"] {
            background-color: #0b3c91; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }

        #createLessonBtn {
            background-color: #3f51b5; 
            padding: 8px 15px;
            border-radius: 5px;
            color: white;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: opacity 0.3s ease;
        }

        #createLessonBtn:hover {
            opacity: 0.9;
        }

        .modal {
        display: none;
        position: fixed;
        z-index: 999;
        left: 0; top: 0;
        width: 100%; height: 100%;
        background-color: rgba(0,0,0,0.5);
        }

        /* Modal Content Box */
        .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 30px;
        border-radius: 12px;
        width: 400px;
        text-align: center;
        box-shadow: 0 0 20px rgba(0,0,0,0.3);
        }

        /* Modal Title */
        .modal-content h2 {
        margin-bottom: 20px;
        font-size: 20px;
        }

        /* Option Buttons */
        .lesson-options button {
        display: block;
        margin: 10px auto;
        padding: 12px 20px;
        font-size: 16px;
        width: 80%;
        border-radius: 8px;
        border: none;
        background-color: #2d89ef;
        color: white;
        transition: background-color 0.3s ease;
        cursor: pointer;
        }

        .lesson-options button:hover {
        background-color: #1b61c1;
        }

        /* Close Button */
        .close {
        color: #aaa;
        float: right;
        font-size: 24px;
        font-weight: bold;
        cursor: pointer;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }

        .container {
            max-width: 900px;
            margin: auto;
            margin-top: 20px;
            margin-bottom: 20px;
            background: #fff;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 25px;
        }

        label {
            font-weight: 600;
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        textarea {
            width: 100%;
            padding: 10px 12px;
            font-size: 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
        }

        .question-box {
            background: #f8f9fa;
            border: 1px solid #ccc;
            padding: 20px;
            margin-top: 20px;
            border-radius: 10px;
        }

        .question-box h4 {
            margin-top: 0;
            color: #34495e;
        }

        .grading-select {
                font-size: 16px;
                padding: 10px;
                width: 150px;
                border-radius: 5px;
        }

        .option-select {
                font-size: 16px;
                padding: 10px;
                width: 150px;
                border-radius: 5px;
        }

        #saveButton {
            display: block;
            background: #007bff;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            margin-top: 30px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        #saveButton:hover {
            background: #0056b3;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive adjustments for tablets */
        @media (max-width: 1024px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }

        /* Responsive adjustments for phones */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: 100%;
                text-align: center;
                margin-left: 0;
            }

            .hero-text {
                font-size: 36px;
                padding: 0 10px;
            }

            .teacher-button-container {
                flex-direction: column;
                gap: 10px;
            }

            .teacher-button, .admin-button {
                width: 90%;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            /* Show all header buttons on small screens */
            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 20px;
            }

            /* Adjust the size of the create lab, quiz, and lesson buttons */
            .nav-buttons a {
                width: 93%;
                font-size: 16px; /* Ensures consistent button text size */
                padding: 12px 0; /* Adjusts the button padding for better alignment */
            }

            /* Center the dropdown menu */
            .dropdown {
                position: relative;
                width: 100%; /* Ensures dropdown menu takes full width */
                text-align: center;
            }

            .dropdown-content {
                left: 50%;
                transform: translateX(-50%);
            }
        }

    </style>
</head>
<body>
    <div class="header">
    <div class="header-left">CodeLab</div>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="material.php">Learning Material</a>
            <a href="quiz.php">Quiz</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>
        <div class="nav-buttons">
            <a href="create_quiz.php">Create a Quiz</a>
            <a href="create_lab.php">Create a Lab</a>
            <button id="createLessonBtn" class="create-lesson-btn">Create a Lesson</button>
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <a href="view_report.php">Report</a>
                    <a href="teacher_profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Lesson Type Modal -->
    <div id="lessonModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>What type of lesson would you like to create?</h2>
            <div class="lesson-options">
            <button onclick="window.location.href='create_slide.php'">Lesson Slides</button>
            <button onclick="window.location.href='create_video.php'">Interactive Videos</button>
            </div>
        </div>
    </div>


    <div class="container">
        <h2>Edit Quiz</h2>
        <form method="post">
            <label>Title:</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($quiz['title']); ?>" required>

            <label>Description:</label>
            <textarea name="description" rows="4" required><?php echo htmlspecialchars($quiz['description']); ?></textarea>

            <label>Grading Score to Pass:</label>
            <select name="grading" class="grading-select" required>
                <?php
                for ($i = 10; $i <= 100; $i += 10) {
                    $selected = ($i == $quiz['grading']) ? 'selected' : '';
                    echo "<option value=\"$i\" $selected>$i</option>";
                }
                ?>
            </select>

            <h3 style="margin-top: 30px; color: #2c3e50;">Questions:</h3>
            <?php foreach ($questions as $index => $q): ?>
                <div class="question-box">
                    <h4>Question <?php echo $index + 1; ?></h4>
                    <input type="hidden" name="question_id[]" value="<?php echo $q['question_id']; ?>">

                    <label>Question:</label>
                    <textarea name="question[]" rows="3" required><?php echo htmlspecialchars($q['question']); ?></textarea>


                    <label>Option A:</label>
                    <input type="text" name="option_a[]" value="<?php echo htmlspecialchars($q['option_a']); ?>" required><br>

                    <label>Option B:</label>
                    <input type="text" name="option_b[]" value="<?php echo htmlspecialchars($q['option_b']); ?>" required><br>

                    <label>Option C:</label>
                    <input type="text" name="option_c[]" value="<?php echo htmlspecialchars($q['option_c']); ?>" required><br>

                    <label>Option D:</label>
                    <input type="text" name="option_d[]" value="<?php echo htmlspecialchars($q['option_d']); ?>" required><br>

                    <label>Correct Option:</label>
                    <select name="correct_option[]" class="option-select" required>
                        <option value="A" <?php if ($q['correct_option'] == 'A') echo 'selected'; ?>>A</option>
                        <option value="B" <?php if ($q['correct_option'] == 'B') echo 'selected'; ?>>B</option>
                        <option value="C" <?php if ($q['correct_option'] == 'C') echo 'selected'; ?>>C</option>
                        <option value="D" <?php if ($q['correct_option'] == 'D') echo 'selected'; ?>>D</option>
                    </select><br>

                    <label>Hint:</label>
                    <input type="text" name="hint[]" value="<?php echo htmlspecialchars($q['hint']); ?>">
                </div>
            <?php endforeach; ?>

            <button id="saveButton" class="save-button">Save Changes</button>



        </form>
        <a href="view_quiz.php?id=<?php echo $quizId; ?>" class="back-link">← Back to Quiz View</a>
    </div>

    <div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
    </div>

    <script>

        const modal = document.getElementById("lessonModal");
        const btn = document.getElementById("createLessonBtn");
        const closeBtn = document.getElementsByClassName("close")[0];

        btn.onclick = function () {
            modal.style.display = "block";
        }

        closeBtn.onclick = function () {
            modal.style.display = "none";
        }

        window.onclick = function (event) {
            if (event.target === modal) {
            modal.style.display = "none";
            }
        }
    </script>
</body>
</html>