<?php
// Ensure the quiz_id is available in the query parameters
$quizId = isset($_GET['quiz_id']) ? $_GET['quiz_id'] : null;
if (!$quizId) {
    // If quiz_id is not available, redirect to quiz creation page
    header("Location: create_quiz.php");
    exit();
}

// Include the database configuration and other necessary files
include("config/config.php");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Quiz Questions</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            font-size: 20px;
        }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .nav-buttons a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
            font-size: 18px;
        }
        .nav-buttons a[href="create_quiz.php"] {
            background-color: #f39c12;
            padding: 8px 15px;
            border-radius: 5px;
        }
        .nav-buttons a[href="create_lesson.php"] {
            background-color: #8e44ad;
            padding: 8px 15px;
            border-radius: 5px;
        }
        .container {
            max-width: 900px;
            margin: 50px auto;
            background: white;
            padding: 50px;
            border-radius: 12px;
            box-shadow: 0px 3px 8px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; color: #1565c0; font-size: 32px; }
        label { display: block; margin-top: 25px; font-weight: bold; font-size: 22px;}
        input[type="text"], select, textarea {
            width: 100%;
            padding: 16px;
            margin-top: 10px;
            font-size: 20px;
            border-radius: 8px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        input::placeholder, textarea::placeholder {
            color: #aaa;
            font-size: 18px;
        }
        textarea {
            resize: vertical;
            min-height: 150px;
        }
        .button-group {
            margin-top: 35px;
            text-align: center;
        }
        .button-group button {
            padding: 16px 30px;
            font-size: 20px;
            border: none;
            border-radius: 10px;
            margin: 0 20px;
            cursor: pointer;
        }
        .create-btn { background-color: #27ae60; color: white; }
        .cancel-btn { background-color: #e74c3c; color: white; }
        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            text-align: center;
        }
        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover { text-decoration: underline; }
        .question-container {
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 20px;
            position: relative;
            border-radius: 10px;
        }
        .remove-question {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            width: 24px;
            height: 24px;
        }
        .hint-icon {
            width: 24px;
            height: 24px;
            cursor: pointer;
            margin-left: 10px;
        }
        .hint-textarea {
            display: none;
            margin-top: 10px;
        }
        #add-question-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #2980b9;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            margin: 20px auto;
        }
        #add-question-btn img {
            width: 24px;
            height: 24px;
            margin-left: 10px;
        }
        .popup {
            display: none;
            position: fixed;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -30%);
            background: white;
            border: 2px solid #1565c0;
            padding: 20px;
            z-index: 99;
            box-shadow: 0px 5px 15px rgba(0,0,0,0.3);
            text-align: center;
        }
        .popup .close {
            float: right;
            font-size: 22px;
            cursor: pointer;
            color: red;
        }
        .popup button {
            margin-top: 15px;
            padding: 10px 20px;
            background-color: #1565c0;
            color: white;
            border: none;
            border-radius: 5px;
        }
        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>

<div class="header">CodeLab</div>

<div class="container">
    <h2>Add Questions to Quiz</h2>
    <form action="create_question_action.php?quiz_id=<?php echo $quizId; ?>" method="POST">
        <div id="question-list">
            <!-- Question Blocks  -->
        </div>
        <button type="button" id="add-question-btn">
            Add Question <img src="icons/plus-icon.png" alt="Add">
        </button>
        <div class="button-group">
            <button type="submit" name="publish" class="create-btn" onclick="return confirm('Are you sure you want to publish this quiz?');">Publish Quiz</button>
            <button type="button" class="cancel-btn" onclick="document.getElementById('cancelPopup').style.display='block'">Cancel</button>
        </div>
    </form>
</div>

<div class="popup" id="cancelPopup">
    <span class="close" onclick="document.getElementById('cancelPopup').style.display='none'">&times;</span>
    <p>Do you want to cancel and stop creating the quiz?</p>
    <button onclick="cancelQuiz(<?php echo $quizId; ?>)">OK</button>
</div>

<div class="footer">
    &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
</div>

<script>
// Create question template
function createQuestionBlock(index) {
    return `
    <div class="question-container">
        <img src="icons/remove-icon.png" class="remove-question" onclick="removeQuestion(this)" alt="Remove">
        
        <label>Question</label>
        <textarea name="questions[${index}][question]" placeholder="Enter question..." required></textarea>
        
        <label>Option A</label>
        <input type="text" name="questions[${index}][option_a]" placeholder="Enter option A" required>
        
        <label>Option B</label>
        <input type="text" name="questions[${index}][option_b]" placeholder="Enter option B" required>
        
        <label>Option C</label>
        <input type="text" name="questions[${index}][option_c]" placeholder="Enter option C" required>
        
        <label>Option D</label>
        <input type="text" name="questions[${index}][option_d]" placeholder="Enter option D" required>
        
        <label>Correct Option</label>
        <select name="questions[${index}][correct_option]" required>
            <option value="">-- Select Correct Option --</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
            <option value="D">D</option>
        </select>

        <label>
            Hint (optional)
            <img src="icons/hint-icon.png" class="hint-icon" onclick="showHintPopup(this.parentElement.nextElementSibling)" alt="Hint Info">
        </label>
        <textarea name="questions[${index}][hint]" class="hint-textarea" placeholder="Provide a hint (optional)..."></textarea>
    </div>
    `;
}

let questionIndex = 0;

function addQuestion() {
    const list = document.getElementById('question-list');
    list.insertAdjacentHTML('beforeend', createQuestionBlock(questionIndex));
    questionIndex++;
}

function removeQuestion(element) {
    const container = element.closest('.question-container');
    container.remove();
}

let currentHintTextarea = null;

function showHintPopup(hintTextarea) {
    if (hintTextarea.style.display === 'block') {
        hintTextarea.style.display = 'none';
    } else {
        hintTextarea.style.display = 'block';
    }
}

function closeHintPopup() {
    document.getElementById('hint-popup').style.display = 'none';
    if (currentHintTextarea) {
        currentHintTextarea.style.display = 'block'; // reveal the textarea
        currentHintTextarea.focus();
        currentHintTextarea = null;
    }
}

function confirmCancel() {
    const confirmAction = confirm("Are you sure you want to cancel quiz creation? All unsaved data will be lost.");
    if (confirmAction) {
        window.location.href = 'dashboard.php';
    }
}

function cancelQuiz(quizId) {
    window.location.href = 'cancel_quiz.php?quiz_id=' + quizId;
}

// Initial question load
window.onload = function() {
    addQuestion();
};

document.getElementById('add-question-btn').addEventListener('click', addQuestion);

document.querySelector('form').addEventListener('submit', function (e) {
    if (document.querySelectorAll('.question-container').length === 0) {
        alert('Please add at least one question before publishing.');
        e.preventDefault();
    }
});

window.onload = addQuestion;
</script>
</body>
</html>

 
