<?php
include 'config/config.php';

if (!isset($_GET['id'])) {
    echo "Slide ID is missing.";
    exit;
}

$slideId = $_GET['id'];


// Delete the quiz
$deleteSlideSql = "DELETE FROM lesson_slide WHERE slide_id = ?";
$slideStmt = $conn->prepare($deleteSlideSql);
$slideStmt->bind_param("i", $slideId);

if ($slideStmt->execute()) {
    echo "<script>alert('Slide deleted successfully.'); window.location.href='dashboard.php';</script>";
} else {
    echo "Failed to delete slide.";
}
?>