<?php
$error = "";
$fullname = '';
$email = '';
$username = '';
$password = '';
$confirm_password = '';
$user_type = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $user_type = $_POST['user_type'];

    if ($password !== $confirm_password) {
        $error = "❌ Password and Confirm Password do not match!";
        $password = '';
        $confirm_password = '';
    } else {
        $conn = new mysqli("localhost", "root", "", "codelab");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Check for existing username
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "❌ Username already exists. Please choose a different one.";
            $username = ""; // Clear username
        } else {
            // Check for existing email
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $error = "❌ Email already registered. Please use a different email address.";
                $email = ""; // Clear email
            } else {
                // Save password as plain text — NOT RECOMMENDED! Use password_hash in production
                $stmt = $conn->prepare("INSERT INTO users (username, name, password, email, role, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                $stmt->bind_param("sssss", $username, $fullname, $password, $email, $user_type);

                if ($stmt->execute()) {
                    $successMessage = "You have successfully registered as a " . htmlspecialchars($user_type) . ". You can now sign in with an existing account.";
                    echo "<script>
                        alert('✅ $successMessage');
                        window.location.href = 'index.html';
                    </script>";
                    exit();
                } else {
                    $error = "❌ Error during registration. Please try again.";
            }
            }
        }

        $stmt->close();
        $conn->close();
    }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CodeLab - Register</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e3f2fd;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #0d47a1;
        }

        .header {
                background-color: #1565c0;
                color: white;
                padding: 20px 50px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .header-left .logo {
                font-size: 40px;
                font-weight: bold;
                text-decoration: none;
                color: white;
                margin-right: 20px;
            }

            .nav {
                display: flex;
                gap: 15px;
                align-items: center;
                justify-content: flex-start; /* Align breadcrumbs to the left */
                margin-right: auto; /* Ensures it sticks to the left */
            }

            .nav a {
                color: white;
                text-decoration: none;
                font-size: 18px;
                font-weight: bold;
                padding: 10px 16px;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }

            .nav a:hover {
                background-color: #0d47a1;
            }

        .container {
            padding: 20px;
            max-width: 600px;
            margin: auto;
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .registration-form {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            margin: 20px 0;
        }
        .form-title {
            font-size: 28px;
            margin-bottom: 20px;
            text-align: center;
            color: #0d47a1;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #bbdefb;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        .form-group input:focus {
            outline: none;
            border-color: #1565c0;
            box-shadow: 0 0 5px rgba(21, 101, 192, 0.5);
        }
        .user-type {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .user-type label {
            display: flex;
            align-items: center;
            cursor: pointer;
        }
        .user-type input {
            margin-right: 8px;
        }
        .submit-button {
            background-color: #1565c0;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }
        .submit-button:hover {
            background-color: #0d47a1;
        }
        .login-link {
            text-align: center;
            margin-top: 20px;
        }
        .login-link a {
            color: #1565c0;
            text-decoration: none;
            font-weight: bold;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive adjustments for tablets */
        @media (max-width: 1024px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }

        /* Responsive adjustments for phones */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: 100%;
                text-align: center;
                margin-left: 0;
            }

            .hero-text {
                font-size: 36px;
                padding: 0 10px;
            }

            .teacher-button-container {
                flex-direction: column;
                gap: 10px;
            }

            .teacher-button, .admin-button {
                width: 90%;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }
        }

        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }

        .alert.error {
            background-color: #ffcdd2;
            color: #b71c1c;
        }

        .alert.success {
            background-color: #c8e6c9;
            color: #1b5e20;
        }
    </style>
</head>
<body>
<div class="header">
        <div class="header-left">
            <a href="index.html" class="logo">CodeLab</a>
        </div>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="material.php">Learning Material</a>
            <a href="quiz.php">Quiz</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>
    </div>
    
    <div class="container">
        <div class="registration-form">
            <h1 class="form-title">Create Your Account</h1>

            <?php if (!empty($error)): ?>
                <div class="alert error"><?php echo $error; ?></div>
            <?php elseif (!empty($success)): ?>
                <div class="alert success"><?php echo $success; ?></div>
            <?php endif; ?>

            <form action="" method="POST">
                <div class="form-group">
                    <label for="fullname">Full Name</label>
                    <input type="text" id="fullname" name="fullname" required value="<?= htmlspecialchars($fullname) ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" required value="<?= htmlspecialchars($email) ?>">
                </div>
                
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required value="<?= htmlspecialchars($username) ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required value="<?= htmlspecialchars($password) ?>">
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required value="<?= htmlspecialchars($confirm_password) ?>">
                </div>
                
                <div class="user-type">
                    <label>
                    <input type="radio" name="user_type" value="student" <?= $user_type === 'student' ? 'checked' : '' ?>> Student
                    </label>
                    <label>
                    <input type="radio" name="user_type" value="teacher" <?= $user_type === 'teacher' ? 'checked' : '' ?>> Teacher
                    </label>
                </div>
                
                <button type="submit" class="submit-button">Register</button>
            </form>
            
            <div class="login-link">
                Already have an account? <a href="login.php">Log in here</a>
            </div>
        </div>
    </div>
    
    <div class="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
    </div>
</body>
</html>