<?php
// Start the session to retrieve the username (if logged in)
session_start();

// Assuming the username is stored in the session after the user logs in
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';  // Default to empty if not logged in
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - CodeLab</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #0d47a1;
        }

        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

            .header-left .logo {
                font-size: 40px;
                font-weight: bold;
                text-decoration: none;
                color: white;
                margin-right: 20px;
            }

            .nav {
                display: flex;
                gap: 5px;
                align-items: center;
                justify-content: flex-start; /* Align breadcrumbs to the left */
                margin-right: auto; /* Ensures it sticks to the left */
                white-space: nowrap;     
                padding: 8px 12px;      
                display: inline-block; 
            }

            .nav a {
                color: white;
                text-decoration: none;
                font-size: 17px;
                font-weight: bold;
                padding: 8px 12px;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }

            .nav a:hover {
                background-color: #0d47a1;
            }
        
        .nav-buttons {
            display: flex;
            gap: 8px; /* Small space between buttons */
        }

        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a[href="create_quiz.php"] {
            background-color: #42a5f5; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a[href="create_lab.php"] {
            background-color: #0b3c91; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }

        #createLessonBtn {
            background-color: #3f51b5; 
            padding: 8px 15px;
            border-radius: 5px;
            color: white;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: opacity 0.3s ease;
        }

        #createLessonBtn:hover {
            opacity: 0.9;
        }

        .modal {
        display: none;
        position: fixed;
        z-index: 999;
        left: 0; top: 0;
        width: 100%; height: 100%;
        background-color: rgba(0,0,0,0.5);
        }

        /* Modal Content Box */
        .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 30px;
        border-radius: 12px;
        width: 400px;
        text-align: center;
        box-shadow: 0 0 20px rgba(0,0,0,0.3);
        }

        /* Modal Title */
        .modal-content h2 {
        margin-bottom: 20px;
        font-size: 20px;
        }

        /* Option Buttons */
        .lesson-options button {
        display: block;
        margin: 10px auto;
        padding: 12px 20px;
        font-size: 16px;
        width: 80%;
        border-radius: 8px;
        border: none;
        background-color: #2d89ef;
        color: white;
        transition: background-color 0.3s ease;
        cursor: pointer;
        }

        .lesson-options button:hover {
        background-color: #1b61c1;
        }

        /* Close Button */
        .close {
        color: #aaa;
        float: right;
        font-size: 24px;
        font-weight: bold;
        cursor: pointer;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }


        .container {
            padding: 40px 20px;
            max-width: 900px;
            margin: auto;
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .contact-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .contact-header h2 {
            font-size: 36px;
            color: #1565c0;
        }

        .contact-header p {
            font-size: 20px;
            line-height: 1.8;
            color: #0d47a1;
        }

        .info-box {
            background-color: white;
            display: flex;
            align-items: center;
            gap: 20px;
            width: 100%;
            max-width: 600px;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .info-box img {
            width: 60px;
            height: 60px;
        }

        .info-box .text {
            font-size: 20px;
            line-height: 1.5;
            color: #0d47a1;
        }

            /* Troubleshooting section */
            .troubleshooting-section {
                width: 100%;
                max-width: 800px;
                background-color: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                margin-top: 40px;
            }

            .troubleshooting-header {
                text-align: center;
                margin-bottom: 30px;
            }

            .troubleshooting-header h3 {
                font-size: 30px;
                color: #1565c0;
            }

            .form-group {
                margin-bottom: 20px;
            }

            .form-group label {
                font-size: 18px;
                color: #0d47a1;
                font-weight: bold;
                margin-bottom: 8px;
                display: block;
            }

            .form-group input, .form-group textarea {
                width: 100%;
                padding: 12px;
                font-size: 16px;
                border-radius: 5px;
                border: 1px solid #ccc;
                box-sizing: border-box;
                margin-top: 8px;
            }

            .form-group textarea {
                resize: vertical;
                min-height: 120px;
            }

            .submit-btn {
                background-color: #1565c0;
                color: white;
                padding: 15px 25px;
                font-size: 18px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                transition: background-color 0.3s ease;
                width: 100%;
                max-width: 200px;
                margin: auto;
            }

            .submit-btn:hover {
                background-color: #0d47a1;
            }

            .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive adjustments for tablets */
        @media (max-width: 1024px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }

        /* Responsive adjustments for phones */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: 100%;
                text-align: center;
                margin-left: 0;
            }

            .hero-text {
                font-size: 36px;
                padding: 0 10px;
            }

            .teacher-button-container {
                flex-direction: column;
                gap: 10px;
            }

            .teacher-button, .admin-button {
                width: 90%;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="header">
    <div class="header-left">CodeLab</div>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="material.php">Learning Material</a>
            <a href="quiz.php">Quiz</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>
        <div class="nav-buttons">
            <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'teacher'): ?>
                <a href="create_quiz.php">Create a Quiz</a>
                <a href="create_lab.php">Create a Lab</a>
                <button id="createLessonBtn" class="create-lesson-btn">Create a Lesson</button>
            <?php endif; ?>
            <?php if (isset($_SESSION['user_role']) && ($_SESSION['user_role'] == 'teacher' || $_SESSION['user_role'] == 'student')): ?>
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'teacher'): ?>
                        <a href="view_report.php">Report</a>
                        <a href="teacher_profile.php">My Profile</a>
                        <a href="troubleshoot_review.php">Troubleshooting Review</a>
                        <a href="logout.php">Logout</a>
                    <?php elseif (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'student'): ?>
                        <a href="view_result.php">Results</a>
                        <a href="teacher_profile.php">My Profile</a>
                        <a href="troubleshoot_review.php">Troubleshooting Review</a>
                        <a href="logout.php">Logout</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="container">
        <div class="contact-header">
            <h2>Contact Us</h2>
            <p>Need help? Reach out to us through the details below.</p>
        </div>

        <div class="info-box">
            <img src="https://cdn-icons-png.flaticon.com/512/46/46854.png" alt="Phone Icon">
            <div class="text">
                <strong>Call Us:</strong><br>
                +6012-345-6789<br>
                Monday - Friday, 9AM - 6PM
            </div>
        </div>

        <div class="info-box">
            <img src="https://img.favpng.com/6/6/7/email-computer-icons-icon-design-message-png-favpng-fJdYjvbftz3UA0nfMyFpYYj0Y.jpg" alt="Email Icon">
            <div class="text">
                <strong>Email Us:</strong><br>
                support@codelab.com<br>
                We respond within 24 hours
            </div>
        </div>

        <!-- Troubleshooting Form -->
        <div class="troubleshooting-section">
            <div class="troubleshooting-header">
                <h3>Troubleshooting</h3>
                <p>If you face any issues, please let us know by filling out the form below.</p>
            </div>

            <form action="submit_ticket.php" method="POST">
                <div class="form-group">
                    <label for="problem">What is the problem you're facing?</label>
                    <input type="text" id="problem" name="problem" placeholder="Enter a brief description of your problem" required>
                </div>

                <div class="form-group">
                    <label for="description">Describe your problem:</label>
                    <textarea id="description" name="description" placeholder="Provide detailed information about the issue" required></textarea>
                </div>

                <button type="submit" class="submit-btn">Submit</button>
            </form>
        </div>
    </div>

    <div class="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
    </div>

</body>
</html>


