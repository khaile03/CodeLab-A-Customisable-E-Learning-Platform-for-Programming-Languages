<?php
session_start();
require_once "config/config.php";

// Initialize variables
$error = '';
$success = '';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['next'])) {
    if (!isset($_POST['student_level'])) {
        $error = 'Please select your skill level before proceeding';
    } else {
        $student_name = $_SESSION['username'];
        $student_level = $_POST['student_level'];

        try {
            // Check if level exists
            $check_stmt = $conn->prepare("SELECT * FROM student_level WHERE student_username = ?");
            $check_stmt->bind_param("s", $student_name);
            $check_stmt->execute();
            $result = $check_stmt->get_result();
            
            if ($result->num_rows === 0) {
                // Insert new record
                $stmt = $conn->prepare("INSERT INTO student_level (student_username, student_level, created_at) VALUES (?, ?, NOW())");
                $stmt->bind_param("ss", $student_name, $student_level);
                $stmt->execute();

            } else {
                //Update record
                $stmt = $conn->prepare("UPDATE student_level SET student_level = ? WHERE student_username = ?");
                $stmt->bind_param("ss", $student_level, $student_name);
                $stmt->execute();

            }

            // Commit transaction
            $conn->commit();
            
            // Check subject preference after successful update
            $check_stmt = $conn->prepare("SELECT subject_interested FROM student_preference WHERE student_username = ?");
            $check_stmt->bind_param("s", $student_name);
            $check_stmt->execute();
            $subject_result = $check_stmt->get_result();
            $subject_data = $subject_result->fetch_assoc();

            // Check if subject_interested exists and is not empty
            if (empty($subject_data['subject_interested'])) {
                header("Location: student_survey.php");
                exit();
            } else {
                header("Location: dashboard.php");
                exit();
            }
            
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        } finally {
            // Close all statements
            if (isset($user_check)) $user_check->close();
            if (isset($check_stmt)) $check_stmt->close();
            if (isset($stmt)) $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CodeLab - Student Level</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #e3f2fd;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #0d47a1;
        }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-left .logo {
            font-size: 40px;
            font-weight: bold;
            text-decoration: none;
            color: white;
            margin-right: 20px;
        }
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 40px 20px;
            position: relative;
            font-size: 40px;
            font-weight: bold;
        }
        .button-container {
            display: flex;
            justify-content: center;
            gap: 40px;
            flex-wrap: wrap;
            margin-top: 20px;
            margin-bottom: 40px;
            width: 100%;
            max-width: 900px;
        }

        .selection_button {
            display: flex;
            flex-direction: column; /* Stack image above text */
            justify-content: center;
            align-items: center;
            gap: 20px; /* Space between image and text */
            
            width: 400px;
            height: 400px;
            border: 5px solid #bbdefb;
            border-radius: 25px;
            
            font-size: 40px;
            cursor: pointer;
            background-color: white;
            color: #1565c0;
            transition: all 0.3s ease;
        }

        .selection_button:hover {
            border-color: #0d47a1;
            background-color: #e3f2fd;
            transform: scale(1.03);
        }

        .selection_button.selected {
            border-color: #0d47a1;
            background-color: #bbdefb;
            transform: scale(1.03);
        }

        .button-icon {
            width: 120px;
            height: 120px;
            object-fit: contain;
        }

        .next-button-container {
            width: 100%;
            max-width: 900px;
            display: flex;
            justify-content: flex-end;
        }

        .next-button {
            padding: 15px 40px;
            background-color: #1565c0;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 20px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .next-button:hover {
            background-color: #0d47a1;
            transform: translateY(-2px);
        }
        .next-button:active {
            transform: translateY(0);
        }
        .error-message {
            color: #d32f2f;
            margin: 15px 0;
            font-size: 16px;
        }
        .success-message {
            color: #388e3c;
            margin: 15px 0;
            font-size: 16px;
        }
        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            text-align: center;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <a>CodeLab</a>
        </div>
    </div>
    <div class="main-content">
        You are _______ in Programming
        <form method="POST" action="">
            <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <div class="button-container">
                <label>
                    <input type="radio" name="student_level" value="Pro" style="display: none;">
                    <div class="selection_button" type="button" onclick="selectButton(this, 'Pro')">
                        <img src="https://static.vecteezy.com/system/resources/previews/002/212/374/non_2x/line-icon-for-beginner-vector.jpg" class="button-icon">
                        <span>Pro</span>
                    </div>
                </label>

                <label>
                    <input type="radio" name="student_level" value="Beginner" style="display: none;">
                    <div class="selection_button" type="button" onclick="selectButton(this, 'Beginner')">
                        <img src="https://static.vecteezy.com/system/resources/previews/002/212/399/non_2x/line-icon-for-beginner-vector.jpg" class="button-icon">
                        <span>Beginner</span>
                    </div>
                </label>
            </div>

            
            <div class="next-button-container">
                <button type="submit" name="next" class="next-button">Next →</button>
            </div>
        </form>
    </div>

    <div class="footer">
        &copy; 2025 CodeLab. All rights reserved.
    </div>

    <script>
        function selectButton(button, value) {
            // Remove selected class from all buttons
            document.querySelectorAll('.selection_button').forEach(btn => {
                btn.classList.remove('selected');
            });
            
            // Add selected class to clicked button
            button.classList.add('selected');
            
            // Set the radio button value
            document.querySelector(`input[value="${value}"]`).checked = true;
        }
    </script>
</body>
</html>