<?php
include 'config/config.php';

if (!isset($_GET['id'])) {
    echo "Lab ID is missing.";
    exit;
}

$labId = $_GET['id'];

// Delete lab questions first (to maintain referential integrity)
$deleteQuestionsSql = "DELETE FROM lab_question WHERE lab_id = ?";
$questionStmt = $conn->prepare($deleteQuestionsSql);
$questionStmt->bind_param("i", $labId);
$questionStmt->execute();

// Delete the lab
$deleteLabSql = "DELETE FROM lab WHERE lab_id = ?";
$labStmt = $conn->prepare($deleteLabSql);
$labStmt->bind_param("i", $labId);

if ($labStmt->execute()) {
    echo "<script>alert('Lab deleted successfully.'); window.location.href='dashboard.php';</script>";
} else {
    echo "Failed to delete lab.";
}
?>
