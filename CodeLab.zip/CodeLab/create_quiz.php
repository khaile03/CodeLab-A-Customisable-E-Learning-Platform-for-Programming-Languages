<?php
//Start session
session_start();

// Connect to the database
include("config/config.php");

// Get the current logged-in teacher_username
$teacherUsername = $_SESSION['username'];

// Handle AJAX request to load topics based on selected subject
if (isset($_POST['subject_id'])) {
    $subject_id = $_POST['subject_id'];
    // Prepare and execute SQL statement to get topics for the subject
    $stmt = $conn->prepare("SELECT topic_id, title FROM topic WHERE subject_id = ?"); 
    $stmt->bind_param("i", $subject_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $topics = array(); // Fetch topics into an array
    while ($row = $result->fetch_assoc()) {
        $topics[] = $row;
    }
    // Return topics as JSON
    echo json_encode($topics);
    exit;
}

// Get all subjects for the dropdown menu
$subjects = $conn->query("SELECT subject_id, name FROM subject");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Quiz</title>
    <style>
        /* page styling */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            font-size: 20px;
        }

        /* Header styling */
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* Navigation buttons in header */
        .nav-buttons a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
            font-size: 18px;
        }
        .nav-buttons a[href="create_quiz.php"] {
            background-color: #1e88e5;
            padding: 8px 15px;
            border-radius: 5px;
        }
        .nav-buttons a[href="create_lesson.php"] {
            background-color: #0d47a1;
            padding: 8px 15px;
            border-radius: 5px;
        }
        .dropdown { position: relative; display: inline-block; } /* Dropdown menu styling */
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content { display: block; }

        /* Main container styling */
        .container {
            max-width: 900px;
            margin: 50px auto;
            background: white;
            padding: 50px;
            border-radius: 12px;
            box-shadow: 0px 3px 8px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; color: #1565c0; font-size: 32px; }
        label { display: block; margin-top: 25px; font-weight: bold; font-size: 22px;}

        /* Form fields */
        input[type="text"], select, textarea {
            width: 100%;
            padding: 16px;
            margin-top: 10px;
            font-size: 20px;
            border-radius: 8px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        input::placeholder, textarea::placeholder {
            color: #aaa;
            font-size: 18px;
        }

        textarea {
            resize: vertical;
            min-height: 150px;
        }

        /* Button styling */
        .button-group {
            margin-top: 35px;
            text-align: center;
        }
        .button-group button {
            padding: 16px 30px;
            font-size: 20px;
            border: none;
            border-radius: 10px;
            margin: 0 20px;
            cursor: pointer;
        }
        .create-btn { background-color: #27ae60; color: white; }
        .cancel-btn { background-color: #e74c3c; color: white; }

        /* Popup modal for cancel confirmation */
        .popup {
            display: none;
            position: fixed;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -30%);
            background: white;
            border: 2px solid #1565c0;
            padding: 20px;
            z-index: 99;
            box-shadow: 0px 5px 15px rgba(0,0,0,0.3);
            text-align: center;
        }
        .popup .close {
            float: right;
            font-size: 22px;
            cursor: pointer;
            color: red;
        }
        .popup button {
            margin-top: 15px;
            padding: 10px 20px;
            background-color: #1565c0;
            color: white;
            border: none;
            border-radius: 5px;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<!-- Header section -->
<div class="header">CodeLab</div>

<!-- Main container for the form -->
<div class="container">
    <h2>Create a New Quiz</h2>
    <!-- Quiz creation form -->
    <form action="create_quiz_action.php" method="POST">
        <label for="quiz_title">Quiz Title</label>
        <input type="text" name="quiz_title" placeholder="e.g. Practice Quiz on Data Types" required>

        <label for="subject">Subject</label> <!-- Subject dropdown selection -->
        <select name="subject" id="subject" required>
            <option value="">-- Select Subject --</option>
            <?php while ($row = $subjects->fetch_assoc()) {
                echo "<option value='{$row['subject_id']}'>{$row['name']}</option>";
            } ?>
        </select>

        <label for="topic">Topic</label> <!-- Topic dropdown selection -->
        <select name="topic" id="topic" required>
            <option value="">-- Select Topic --</option>
        </select>

        <label for="grading">Grading</label> <!-- Grading selection -->
        <select name="grading" id="grading" required>
            <option value="">-- Select Grading --</option>
            <option value="10">10</option> <!--generate grading options (10 to 100) -->
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="40">40</option>
            <option value="50">50</option>
            <option value="60">60</option>
            <option value="70">70</option>
            <option value="80">80</option>
            <option value="90">90</option>
            <option value="100">100</option>
        </select>
        <small>How much should student score to pass this assessment?</small>

        <label for="description">Description</label>
        <textarea name="description" rows="5" placeholder="Write a short description of the quiz..." required></textarea>

        <!-- Submit and cancel buttons -->
        <div class="button-group">
            <button type="submit" name="create_quiz" class="create-btn">Create</button>
            <button type="button" class="cancel-btn" onclick="document.getElementById('cancelPopup').style.display='block'">Cancel</button>
        </div>
    </form>
</div>

<!-- Cancel confirmation popup -->
<div class="popup" id="cancelPopup">
    <span class="close" onclick="document.getElementById('cancelPopup').style.display='none'">&times;</span>
    <p>Do you want to cancel and stop creating the quiz?</p>
    <button onclick="window.location.href='dashboard.php'">OK</button>
</div>

<!-- Footer section -->
<div class="footer" id="footer">
    &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
</div>

<script>
    // JavaScript to load topics dynamically when a subject is selected
    document.getElementById('subject').addEventListener('change', function() {
        var subject_id = this.value; // Get the selected subject id
        var topicSelect = document.getElementById('topic'); // Reference to the "topic" dropdown menu
        topicSelect.innerHTML = '<option value="">Loading...</option>';

        var xhr = new XMLHttpRequest(); // Create a new XMLHttpRequest object to send a request to the server
        xhr.open('POST', 'create_quiz.php', true); // Set to POST method and target the same file (create_quiz.php)
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.onload = function () {
            var data = JSON.parse(this.responseText); // Parse the JSON response from the server
            topicSelect.innerHTML = '<option value="">-- Select Topic --</option>'; // Clear the topic dropdown and add the default option
            // Loop through the list of topics received
            data.forEach(function(item) {
                var opt = document.createElement("option");
                opt.value = item.topic_id; // Set the option value as the topic ID
                opt.innerHTML = item.title; // Set the option text as the topic title
                topicSelect.appendChild(opt); // Append the new option to the topic dropdown
            });
        };
        // Send the selected subject ID to the server
        xhr.send('subject_id=' + subject_id);
    });

</script>

</body>
</html>
