<?php
include 'config/config.php';
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check for slide ID
if (!isset($_GET['id'])) {
    echo "Slide ID is missing.";
    exit;
}

$slideId = $_GET['id'];

// Fetch current slide info
$sql = "SELECT * FROM lesson_slide WHERE slide_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $slideId);
$stmt->execute();
$slideResult = $stmt->get_result();

if ($slideResult->num_rows === 0) {
    echo "Slide not found.";
    exit;
}
$slide = $slideResult->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];

    // Check if file is uploaded
    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['file'];

        // Check file size (limit: 1000 KB)
        if ($file['size'] > 1024000) {
            echo "<script>
                    alert('Error: File size exceeds 1000 KB limit.');
                    window.location.href = 'edit_slide.php?id=$slideId';
                </script>";
            exit;
        }

        $fileTmpPath = $file['tmp_name'];
        $fileName = basename($file['name']);
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $fileContent = file_get_contents($fileTmpPath);

        // Update title, description, file_name, file_type, file_data
        $update = "UPDATE lesson_slide 
                   SET title = ?, description = ?, file_name = ?, file_type = ?, file_data = ?
                   WHERE slide_id = ?";

        $stmt = $conn->prepare($update);

        $null = NULL; // Placeholder for BLOB
        $stmt->bind_param("ssssbi", $title, $description, $fileName, $fileType, $null, $slideId);
        $stmt->send_long_data(4, $fileContent); // Index 4 is for 'file_data'

    } else {
        // No file uploaded – only update title and description
        $update = "UPDATE lesson_slide 
                   SET title = ?, description = ?
                   WHERE slide_id = ?";

        $stmt = $conn->prepare($update);
        $stmt->bind_param("ssi", $title, $description, $slideId);
    }

    if ($stmt->execute()) {
        echo "<script>alert('Lesson slide updated successfully.'); window.location.href='view_slide.php?id=$slideId';</script>";
        exit;
    } else {
        echo "Update failed: " . $stmt->error;
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Slide</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

            .header-left .logo {
                font-size: 40px;
                font-weight: bold;
                text-decoration: none;
                color: white;
            }

            .nav {
                display: flex;
                gap: 5px;
                align-items: center;
                justify-content: flex-start; /* Align breadcrumbs to the left */
                margin-right: auto; /* Ensures it sticks to the left */
                white-space: nowrap;     
                padding: 8px 12px;      
                display: inline-block; 
            }

            .nav a {
                color: white;
                text-decoration: none;
                font-size: 18px;
                font-weight: bold;
                padding: 8px 12px;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }

            .nav a:hover {
                background-color: #0d47a1;
            }
        
        .nav-buttons {
            display: flex;
            gap: 8px; /* Small space between buttons */
        }

        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a[href="create_quiz.php"] {
            background-color: #42a5f5; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a[href="create_lab.php"] {
            background-color: #0b3c91; 
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }

        #createLessonBtn {
            background-color: #3f51b5; 
            padding: 8px 15px;
            border-radius: 5px;
            color: white;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: opacity 0.3s ease;
        }

        #createLessonBtn:hover {
            opacity: 0.9;
        }

        .modal {
        display: none;
        position: fixed;
        z-index: 999;
        left: 0; top: 0;
        width: 100%; height: 100%;
        background-color: rgba(0,0,0,0.5);
        }

        /* Modal Content Box */
        .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 30px;
        border-radius: 12px;
        width: 400px;
        text-align: center;
        box-shadow: 0 0 20px rgba(0,0,0,0.3);
        }

        /* Modal Title */
        .modal-content h2 {
        margin-bottom: 20px;
        font-size: 20px;
        }

        /* Option Buttons */
        .lesson-options button {
        display: block;
        margin: 10px auto;
        padding: 12px 20px;
        font-size: 16px;
        width: 80%;
        border-radius: 8px;
        border: none;
        background-color: #2d89ef;
        color: white;
        transition: background-color 0.3s ease;
        cursor: pointer;
        }

        .lesson-options button:hover {
        background-color: #1b61c1;
        }

        /* Close Button */
        .close {
        color: #aaa;
        float: right;
        font-size: 24px;
        font-weight: bold;
        cursor: pointer;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }

        .container {
            max-width: 900px;
            margin: auto;
            margin-top: 20px;
            margin-bottom: 20px;
            background: #fff;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 25px;
        }

        label {
            font-weight: 600;
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        textarea {
            width: 100%;
            padding: 10px 12px;
            font-size: 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
        }

        .question-box {
            background: #f8f9fa;
            border: 1px solid #ccc;
            padding: 20px;
            margin-top: 20px;
            border-radius: 10px;
        }

        .question-box h4 {
            margin-top: 0;
            color: #34495e;
        }

        .grading-select {
                font-size: 16px;
                padding: 10px;
                width: 150px;
                border-radius: 5px;
        }

        .option-select {
                font-size: 16px;
                padding: 10px;
                width: 150px;
                border-radius: 5px;
        }

        #saveButton {
            display: block;
            background: #007bff;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            margin-top: 30px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        #saveButton:hover {
            background: #0056b3;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive adjustments for tablets */
        @media (max-width: 1024px) {
            .section {
                flex-direction: column;
                align-items: center;
            }
            .section img, .text-box {
                width: 90%;
            }
            .hero-text {
                font-size: 48px;
            }
            .nav {
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin: 10px 0;
            }
        }

        /* Responsive adjustments for phones */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: 100%;
                text-align: center;
                margin-left: 0;
            }

            .hero-text {
                font-size: 36px;
                padding: 0 10px;
            }

            .teacher-button-container {
                flex-direction: column;
                gap: 10px;
            }

            .teacher-button, .admin-button {
                width: 90%;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            /* Show all header buttons on small screens */
            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 20px;
            }

            /* Adjust the size of the create lab, quiz, and lesson buttons */
            .nav-buttons a {
                width: 93%;
                font-size: 16px; /* Ensures consistent button text size */
                padding: 12px 0; /* Adjusts the button padding for better alignment */
            }

            /* Center the dropdown menu */
            .dropdown {
                position: relative;
                width: 100%; /* Ensures dropdown menu takes full width */
                text-align: center;
            }

            .dropdown-content {
                left: 50%;
                transform: translateX(-50%);
            }
        }

    </style>
</head>
<body>
    <div class="header">
    <div class="header-left">CodeLab</div>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="material.php">Learning Material</a>
            <a href="quiz.php">Quiz</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>
        <div class="nav-buttons">
            <a href="create_quiz.php">Create a Quiz</a>
            <a href="create_lab.php">Create a Lab</a>
            <button id="createLessonBtn" class="create-lesson-btn">Create a Lesson</button>
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <a href="view_report.php">Report</a>
                    <a href="teacher_profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Lesson Type Modal -->
    <div id="lessonModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>What type of lesson would you like to create?</h2>
            <div class="lesson-options">
            <button onclick="window.location.href='create_slide.php'">Lesson Slides</button>
            <button onclick="window.location.href='create_video.php'">Interactive Videos</button>
            </div>
        </div>
    </div>


    <div class="container">
    <h2>Edit Lesson Slide</h2>
    <form method="post" enctype="multipart/form-data">
        <label>Title:</label>
        <input type="text" name="title" value="<?php echo htmlspecialchars($slide['title']); ?>" required>

        <label>Description:</label>
        <textarea name="description" rows="4" required><?php echo htmlspecialchars($slide['description']); ?></textarea>

        <label>Upload New File (Please upload a PDF File with maximum of 1000KB only):</label>
        <input type="file" name="file" accept=".pdf">

        <button id="saveButton" class="save-button">Save Changes</button>
    </form>

    <a href="view_slide.php?id=<?php echo $slideId; ?>" class="back-link">← Back to Slide View</a>
</div>



    <div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. <a href="about.php">About</a>
    </div>

    <script>

        const modal = document.getElementById("lessonModal");
        const btn = document.getElementById("createLessonBtn");
        const closeBtn = document.getElementsByClassName("close")[0];

        btn.onclick = function () {
            modal.style.display = "block";
        }

        closeBtn.onclick = function () {
            modal.style.display = "none";
        }

        window.onclick = function (event) {
            if (event.target === modal) {
            modal.style.display = "none";
            }
        }
    </script>
</body>
</html>