<?php
include('config/config.php');
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['username'])) {
    echo "Unauthorized access.";
    exit();
}

$username = $_SESSION['username'];
$message = "";

// Fetch current teacher profile
$query = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($conn, $query);
$teacher = mysqli_fetch_assoc($result);

// Update name and email
if (isset($_POST['update_profile'])) {
    $newName = mysqli_real_escape_string($conn, $_POST['name']);
    $newEmail = mysqli_real_escape_string($conn, $_POST['email']);

    // Check if the new email is already used by another user
    $checkEmailQuery = "SELECT * FROM users WHERE email = '$newEmail' AND username != '$username'";
    $checkResult = mysqli_query($conn, $checkEmailQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        $message = "Email is already in use by another account.";
    } else {
        $updateQuery = "UPDATE users SET name='$newName', email='$newEmail' WHERE username='$username'";
        if (mysqli_query($conn, $updateQuery)) {
            $message = "Profile updated successfully.";
            // Refresh teacher data
            $result = mysqli_query($conn, $query);
            $teacher = mysqli_fetch_assoc($result);
        } else {
            $message = "Failed to update profile.";
        }
    }
}

// Change password logic
if (isset($_POST['change_password'])) {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    if ($new !== $confirm) {
        $message = "New password and confirmation do not match.";
    } else {
        // Check current password
        if ($current !== $teacher['password']) {
            $message = "Current password is incorrect.";
        } else {
            $updatePasswordQuery = "UPDATE users SET password='$new' WHERE username='$username'";
            if (mysqli_query($conn, $updatePasswordQuery)) {
                $message = "Password changed successfully.";
            } else {
                $message = "Failed to change password.";
            }
        }
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Teacher Profile</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f2f5; }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-left .logo {
            font-size: 40px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav {
            display: flex;
            gap: 15px;
            align-items: center;
            justify-content: flex-start;
            margin-right: auto;
            padding-left: 30px;
        }
        .nav a {
            color: white;
            text-decoration: none;
            font-size: 17px;
            font-weight: bold;
            padding: 8px 12px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .nav a:hover {
            background-color: #0d47a1;
        }
        .nav-buttons {
            display: flex;
            gap: 8px;
        }

        .nav-buttons a {
            display: flex;/* Flex for centering */
            align-items: center;/* Vertical centering */
            justify-content: center;/* Horizontal centering */
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px; /* ensures consistent button width */
            height: 32px;  /* ensures consistent height */
        }

        .nav-buttons a:hover {
            opacity: 0.9;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            margin-top: 80px;
            margin-bottom: 80px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        img.profile {
            width: 80px;
            display: block;
            margin: 0 auto 20px;
        }
        label {
            display: block;
            margin-top: 12px;
            color: #444;
        }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            margin-top: 5px;
        }
        input[readonly] {
            background-color: #f2f2f2;
        }
        .btn {
            margin-top: 20px;
            padding: 12px 24px;
            background: #007BFF;
            border: none;
            color: white;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background: #0056b3;
        }
        .message {
            color: green;
            margin-top: 15px;
        }
        .error {
            color: red;
        }
        .password-link {
            color: #007BFF;
            cursor: pointer;
            margin-top: 10px;
            display: inline-block;
            margin-right: 20px;
        }
        #passwordModal {
            display: none;
            position: fixed;
            z-index: 999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.6);
        }
        .modal-content {
            background-color: white;
            padding: 20px;
            margin: 10% auto;
            border-radius: 10px;
            width: 400px;
            position: relative;
        }
        .modal-content input[type="password"] {
            width: 90%;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            margin-top: 8px;
        }
        .close {
            position: absolute;
            right: 15px;
            top: 10px;
            font-size: 22px;
            color: #aaa;
            cursor: pointer;
        }
        .close:hover {
            color: #000;
        }

        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive for tablets (landscape, <= 1024px) */
        @media (max-width: 1024px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px 30px;
            }

            .nav {
                flex-wrap: wrap;
                justify-content: flex-start;
                padding-left: 0;
                margin-top: 10px;
                gap: 10px;
            }

            .nav a {
                font-size: 15px;
                padding: 8px 10px;
            }

            .nav-buttons {
                align-self: flex-end;
                margin-top: 10px;
            }

            .nav-buttons a {
                font-size: 14px;
                padding: 6px 12px;
            }

            .container-title {
                font-size: 26px;
            }

            .small-title {
                font-size: 22px;
            }

            .content-box {
                width: 220px;
            }
        }

        /* Responsive for phones (portrait, <= 768px) */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: stretch;
                padding: 20px;
            }

            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-start;
                gap: 10px;
                padding-left: 0;
                margin-top: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 16px;
                font-size: 14px;
            }

            .nav-buttons {
                display: flex;
                justify-content: flex-end;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: auto;
                font-size: 14px;
                padding: 10px 14px;
            }

            .dropdown {
                width: auto;
            }

            .dropdown-content {
                min-width: 140px;
                left: auto;
                right: 0;
                transform: none;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            .hero-text {
                font-size: 28px;
                padding: 0 10px;
            }
        }

    </style>
</head>
<body>

<div class="header">
<div class="header-left">CodeLab</div>
        <div class="nav">
            <a href="admin_dashboard.php">Homepage</a>
            <a href="user_management.php">User Management</a>
            <a href="material_approval.php">Learning Material Approval</a>
            <a href="quiz_approval.php">Quiz Approval</a>
            <a href="lab_approval.php">Lab Approval</a>
            <a href="troubleshooting.php">Troubleshooting</a>
        </div>
        <div class="nav-buttons">
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <a href="admin_profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

<div class="container">
    <h2>My Profile</h2>
    <img src="https://cdn-icons-png.flaticon.com/512/9815/9815472.png" class="profile" alt="Profile Picture">

    <?php if ($message != ""): ?>
        <p class="<?php echo strpos($message, 'successfully') !== false ? 'message' : 'error'; ?>"><?php echo $message; ?></p>
    <?php endif; ?>

    <form method="POST">
        <label>Username:</label>
        <input type="text" name="username" value="<?php echo $teacher['username']; ?>" readonly>

        <label>Full Name:</label>
        <input type="text" name="name" value="<?php echo $teacher['name']; ?>" required>

        <label>Email Address:</label>
        <input type="email" name="email" value="<?php echo $teacher['email']; ?>" required>

        <label class="password-link" onclick="document.getElementById('passwordModal').style.display='block'">Change Password</label>

        <button type="submit" name="update_profile" class="btn">Update Profile</button>
    </form>
</div>

<!-- Password Modal -->
<div id="passwordModal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('passwordModal').style.display='none'">&times;</span>
        <h3>Change Password</h3>
        <form method="POST">
            <label>Current Password:</label>
            <input type="password" name="current_password" required>

            <label>New Password:</label>
            <input type="password" name="new_password" required>

            <label>Confirm New Password:</label>
            <input type="password" name="confirm_password" required>

            <button type="submit" name="change_password" class="btn" style="margin-top: 15px;">Change Password</button>
        </form>
    </div>
</div>

<div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. 
</div>


<script>

        const modal = document.getElementById("lessonModal");
        const btn = document.getElementById("createLessonBtn");
        const closeBtn = document.getElementsByClassName("close")[0];

        btn.onclick = function () {
            modal.style.display = "block";
        }

        closeBtn.onclick = function () {
            modal.style.display = "none";
        }

        window.onclick = function (event) {
            if (event.target === modal) {
            modal.style.display = "none";
            }
        }
    </script>

</body>
</html>