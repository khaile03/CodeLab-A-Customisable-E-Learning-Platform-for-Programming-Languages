<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("config/config.php");

// Check admin permissions
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Check if username is provided
if (!isset($_GET['username']) || empty(trim($_GET['username']))) {
    die("Error: Please provide a username!");
}
$username = trim($_GET['username']);

// Check database connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Fetch user data
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
if (!$stmt) {
    die("SQL query error: " . $conn->error);
}

$stmt->bind_param("s", $username);
if (!$stmt->execute()) {
    die("Query execution failed: " . $stmt->error);
}

$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Check if user exists
if (!$user) {
    die("Error: User '$username' not found!");
}

// Initialize message variables
$success_message = '';
$error_message = '';

// Handle form submission (update user info)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle delete action
    if (isset($_POST['delete_user'])) {
        $deleteStmt = $conn->prepare("DELETE FROM users WHERE username = ?");
        $deleteStmt->bind_param("s", $username);
        
        if ($deleteStmt->execute()) {
            header("Location: user_management.php");
            exit();
        } else {
            $error_message = "Error: Failed to delete user! " . $deleteStmt->error;
        }
    }
    // Handle update action
    else {
        $new_username = trim($_POST['username']);
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $role = $user['role']; // Role is read-only, use existing value

        // Validate input
        if (empty($new_username) || empty($name) || empty($email)) {
            $error_message = "Error: All fields are required!";
        } else {
            // Check if email already exists for another user
            $checkEmail = $conn->prepare("SELECT username FROM users WHERE email = ? AND username != ?");
            $checkEmail->bind_param("ss", $email, $username);
            $checkEmail->execute();
            $emailResult = $checkEmail->get_result();
            
            if ($emailResult->num_rows > 0) {
                $error_message = "Error: This email is already registered to another user!";
            } else {
                $updateStmt = $conn->prepare("UPDATE users SET username = ?, name = ?, email = ? WHERE username = ?");
                $updateStmt->bind_param("ssss", $new_username, $name, $email, $username);

                if ($updateStmt->execute()) {
                    $success_message = "Profile updated successfully!";
                    // Update the displayed username if it was changed
                    $user['username'] = $new_username;
                    $user['name'] = $name;
                    $user['email'] = $email;
                } else {
                    $error_message = "Error: Failed to update user! " . $updateStmt->error;
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Edit User</title>
    <style>
        body { 
            margin: 0; 
            font-family: Arial, sans-serif; 
            background-color: #f0f2f5; 
        }
        .header {
            background-color: #1565c0;
            color: white;
            padding: 20px 50px;
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-left .logo {
            font-size: 40px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav {
            display: flex;
            gap: 15px;
            align-items: center;
            justify-content: flex-start;
            margin-right: auto;
            padding-left: 30px;
        }
        .nav a {
            color: white;
            text-decoration: none;
            font-size: 17px;
            font-weight: bold;
            padding: 8px 12px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .nav a:hover {
            background-color: #0d47a1;
        }
        .nav-buttons {
            display: flex;
            gap: 8px;
        }
        .nav-buttons a {
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 5px;
            min-width: 90px;
            height: 32px;
        }
        .nav-buttons a:hover {
            opacity: 0.9;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }   
        .profile-card {
            max-width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        }
        .profile-card h2 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: 600;
        }
        .profile-img {
            width: 60px;
            margin: 0 auto 20px;
            display: block;
        }
        .form-control {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 16px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s ease;
        }
        .btn-primary {
            background-color: #0066cc;
            color: white;
        }
        .btn-primary:hover {
            background-color: #004a99;
        }
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        .btn-danger:hover {
            background-color: #bb2d3b;
        }
        .btn-outline-secondary {
            background-color: white;
            color: #333;
            border: 1px solid #ddd;
        }
        .btn-outline-secondary:hover {
            background-color: #f5f5f5;
        }
        .role-display {
            background-color: #e9ecef;
            padding: 8px 12px;
            border-radius: 8px;
            display: inline-block;
            width: 100%;
        }
        .button-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .confirmation-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        .confirmation-box {
            background: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 500px;
            width: 90%;
            text-align: center;
        }
        .confirmation-buttons {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin-top: 20px;
        }
        .confirmation-buttons .btn {
            width: 120px; 
            padding: 8px 0;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        .readonly-field {
            background-color: #f5f5f5;
            color: #555;
            cursor: not-allowed;
        }
        .footer {
            background-color: #1565c0;
            color: white;
            padding: 20px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            transition: opacity 0.5s ease;
            box-sizing: border-box;
        }

        .footer a {
            color: #f1c40f;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Responsive for tablets (landscape, <= 1024px) */
        @media (max-width: 1024px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                padding: 20px 30px;
            }

            .nav {
                flex-wrap: wrap;
                justify-content: flex-start;
                padding-left: 0;
                margin-top: 10px;
                gap: 10px;
            }

            .nav a {
                font-size: 15px;
                padding: 8px 10px;
            }

            .nav-buttons {
                align-self: flex-end;
                margin-top: 10px;
            }

            .nav-buttons a {
                font-size: 14px;
                padding: 6px 12px;
            }

            .container-title {
                font-size: 26px;
            }

            .small-title {
                font-size: 22px;
            }

            .content-box {
                width: 220px;
            }
        }

        /* Responsive for phones (portrait, <= 768px) */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: stretch;
                padding: 20px;
            }

            .nav {
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-start;
                gap: 10px;
                padding-left: 0;
                margin-top: 10px;
            }

            .nav a {
                width: auto;
                padding: 10px 16px;
                font-size: 14px;
            }

            .nav-buttons {
                display: flex;
                justify-content: flex-end;
                width: 100%;
                margin-top: 10px;
            }

            .nav-buttons a {
                width: auto;
                font-size: 14px;
                padding: 10px 14px;
            }

            .dropdown {
                width: auto;
            }

            .dropdown-content {
                min-width: 140px;
                left: auto;
                right: 0;
                transform: none;
            }

            .footer {
                font-size: 16px;
                text-align: center;
            }

            .hero-text {
                font-size: 28px;
                padding: 0 10px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <a>CodeLab</a>
        </div>
        <div class="nav">
            <a href="admin_dashboard.php">Homepage</a>
            <a href="user_management.php">User Management</a>
            <a href="material_approval.php">Learning Material Approval</a>
            <a href="quiz_approval.php">Quiz Approval</a>
            <a href="lab_approval.php">Lab Approval</a>
            <a href="troubleshooting.php">Troubleshooting</a>
        </div>
        <div class="nav-buttons">
            <div class="dropdown">
                <a href="#">More &#9662;</a>
                <div class="dropdown-content">
                    <a href="admin_profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="profile-card">
        <img src="https://cdn-icons-png.flaticon.com/512/847/847969.png" alt="User Icon" class="profile-img">
        <h2>Edit User Profile</h2>

        <?php if (!empty($success_message)): ?>
            <div class="alert-success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <form method="POST" id="userForm">
            <div>
                <label>Username:</label>
                <input type="text" name="username" class="form-control readonly-field" 
                    value="<?php echo htmlspecialchars($user['username']); ?>" 
                    readonly>
            </div>
            <div>
                <label class="form-label">Full Name:</label>
                <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" required>
            </div>
            <div>
                <label class="form-label">Email Address:</label>
                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div>
                <label>Role:</label>
                <input type="text" class="form-control readonly-field" 
                    value="<?php echo htmlspecialchars(ucfirst($user['role'])); ?>" 
                    readonly>
                <input type="hidden" name="role" value="<?php echo htmlspecialchars($user['role']); ?>">
            </div>

            <div>
                <h2>
        </h2>
            </div>

            <div class="button-group">
                <button type="submit" class="btn btn-primary">Update Profile</button>
                <button type="button" class="btn btn-danger" id="deleteBtn">Delete User</button>
            </div>
        </form>
    </div>

    <!-- Confirmation Modal -->
    <div class="confirmation-modal" id="confirmationModal">
        <div class="confirmation-box">
            <h3 class="confirmation-title">Confirm Deletion</h3>
            <p class="confirmation-message">Are you sure you want to permanently delete this user? This action cannot be undone!</p>
            <div class="confirmation-buttons">
                <button type="button" class="btn btn-outline-secondary" id="cancelDelete">Cancel</button>
                <form method="POST" style="display: inline;">
                    <button type="submit" name="delete_user" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>

    <div class="footer" id="footer">
        &copy; 2025 CodeLab. All rights reserved. 
    </div>

    <script>
        document.getElementById('deleteBtn').addEventListener('click', function() {
            document.getElementById('confirmationModal').style.display = 'flex';
        });

        document.getElementById('cancelDelete').addEventListener('click', function() {
            document.getElementById('confirmationModal').style.display = 'none';
        });
    </script>
</body>
</html>