<?php
// Include the database connection file
include('config/config.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session to retrieve the username
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the values from the form and sanitize them
    $problem = mysqli_real_escape_string($conn, trim($_POST["problem"]));
    $description = mysqli_real_escape_string($conn, trim($_POST["description"]));

    // Get the username from the session (assuming the user is logged in)
    $username = $_SESSION['username'];

    // Validate input (check for empty fields)
    if (empty($problem) || empty($description)) {
        echo "<script>alert('Please fill out all fields.'); window.location.href='contact.php';</script>";
        exit();
    }

    if (empty($username)) {
        echo "<script>alert('Please log in to submit a troubleshooting ticket.'); window.location.href='contact.php';</script>";
        exit();
    }

    // Set the default status to 'Pending'
    $status = 'pending';

    // Prepare the SQL query to insert the troubleshooting ticket into the database
    $query = "INSERT INTO tickets (description, text, username, status) VALUES ('$problem', '$description', '$username', '$status')";

    // Execute the query
    if (mysqli_query($conn, $query)) {
        // If successful, redirect to a thank you page or display a success message
        echo "<script>alert('Your ticket has been submitted successfully!'); window.location.href='contact.php';</script>";
    } else {
        // If there's an error, display an error message
        echo "<script>alert('Error submitting your ticket: " . mysqli_error($conn) . "'); window.location.href='contact.php';</script>";
    }

    // Close the database connection
    mysqli_close($conn);
}
?>


